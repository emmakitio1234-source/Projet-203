const express = require('express');
const userController = require('../controllers/userController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/', auth, roleCheck(['admin']), userController.getAllUsers);
router.post('/', auth, roleCheck(['admin']), userController.createUser);
router.post('/bulk-import', auth, roleCheck(['admin']), userController.bulkImportUsers);
router.get('/:id', auth, userController.getUserById);
router.put('/:id', auth, userController.updateUser);
router.delete('/:id', auth, roleCheck(['admin']), userController.deleteUser);
router.patch('/:id/change-password', auth, userController.changePassword);
router.patch('/:id/deactivate', auth, roleCheck(['admin']), userController.deactivateUser);
router.patch('/:id/activate', auth, roleCheck(['admin']), userController.activateUser);
router.get('/:id/statistics', auth, userController.getUserStatistics);

module.exports = router;