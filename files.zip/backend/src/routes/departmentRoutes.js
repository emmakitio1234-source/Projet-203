const express = require('express');
const departmentController = require('../controllers/departmentController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');
const { cacheMiddleware } = require('../middleware/cache');

const router = express.Router();

router.get('/', auth, cacheMiddleware(3600), departmentController.getAllDepartments);
router.post('/', auth, roleCheck(['admin']), departmentController.createDepartment);
router.put('/:id', auth, roleCheck(['admin']), departmentController.updateDepartment);
router.delete('/:id', auth, roleCheck(['admin']), departmentController.deleteDepartment);

module.exports = router;