const express = require('express');
const timetableController = require('../controllers/timetableController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/', auth, timetableController.getTimetableEntries);
router.post('/', auth, roleCheck(['admin']), timetableController.createTimetableEntry);
router.post('/detect-conflicts', auth, timetableController.detectConflicts);
router.get('/overview', auth, timetableController.getTimetableOverview);
router.get('/:id', auth, timetableController.getTimetableEntry);
router.put('/:id', auth, roleCheck(['admin']), timetableController.updateTimetableEntry);
router.delete('/:id', auth, roleCheck(['admin']), timetableController.deleteTimetableEntry);
router.patch('/:id/confirm', auth, roleCheck(['admin']), timetableController.confirmTimetableEntry);
router.patch('/:id/cancel', auth, roleCheck(['admin']), timetableController.cancelTimetableEntry);

module.exports = router;