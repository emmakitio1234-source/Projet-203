const express = require('express');
const roomController = require('../controllers/roomController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/', auth, roomController.getAllRooms);
router.post('/', auth, roleCheck(['admin']), roomController.createRoom);
router.get('/statistics', auth, roleCheck(['admin']), roomController.getRoomStatistics);
router.get('/available', auth, roomController.getAvailableRooms);
router.get('/:id', auth, roomController.getRoomById);
router.put('/:id', auth, roleCheck(['admin']), roomController.updateRoom);
router.delete('/:id', auth, roleCheck(['admin']), roomController.deleteRoom);
router.get('/:id/availability', auth, roomController.checkRoomAvailability);
router.get('/:id/schedule', auth, roomController.getRoomSchedule);
router.get('/:id/utilization', auth, roomController.getRoomUtilization);

module.exports = router;