const express = require('express');
const ueController = require('../controllers/ueController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/', auth, ueController.getAllUEs);
router.post('/', auth, roleCheck(['admin']), ueController.createUE);
router.get('/:id', auth, ueController. getUEById);
router.put('/:id', auth, roleCheck(['admin']), ueController.updateUE);
router.delete('/:id', auth, roleCheck(['admin']), ueController.deleteUE);

module.exports = router;