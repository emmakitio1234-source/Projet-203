const express = require('express');
const conflictController = require('../controllers/conflictController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/', auth, conflictController.getAllConflicts);
router.post('/detect', auth, roleCheck(['admin']), conflictController.detectConflicts);
router.patch('/:id/resolve', auth, roleCheck(['admin']), conflictController.resolveConflict);
router.delete('/:id', auth, roleCheck(['admin']), conflictController.deleteConflict);

module.exports = router;