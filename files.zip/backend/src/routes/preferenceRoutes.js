const express = require('express');
const preferenceController = require('../controllers/preferenceController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express. Router();

router.post('/', auth, roleCheck(['teacher']), preferenceController.submitPreference);
router.get('/', auth, preferenceController.getPreference);
router.patch('/:id/approve', auth, roleCheck(['admin']), preferenceController.approvePreference);
router.patch('/:id/reject', auth, roleCheck(['admin']), preferenceController.rejectPreference);

module.exports = router;