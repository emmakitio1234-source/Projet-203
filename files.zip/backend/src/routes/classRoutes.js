const express = require('express');
const classController = require('../controllers/classController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/', auth, classController.getAllClasses);
router.post('/', auth, roleCheck(['admin']), classController.createClass);
router.get('/:id', auth, classController.getClassById);
router.put('/:id', auth, roleCheck(['admin']), classController.updateClass);
router.delete('/:id', auth, roleCheck(['admin']), classController.deleteClass);
router.get('/:id/timetable', auth, classController. getClassTimetable);
router.get('/:id/statistics', auth, classController.getClassStatistics);
router.patch('/:id/size', auth, roleCheck(['admin']), classController.updateClassSize);
router.get('/:id/conflicts', auth, classController.getClassConflicts);
router.get('/:id/ues', auth, classController.getClassUEs);
router.get('/:id/teachers', auth, classController.getClassTeachers);
router.get('/:id/schedule-overview', auth, classController.getClassScheduleOverview);
router.get('/:id/capacity-issues', auth, classController.checkCapacityIssues);

module.exports = router;