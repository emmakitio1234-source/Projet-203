const express = require('express');
const academicYearController = require('../controllers/academicYearController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/', auth, academicYearController.getAllAcademicYears);
router.post('/', auth, roleCheck(['admin']), academicYearController.createAcademicYear);
router.patch('/:id/activate', auth, roleCheck(['admin']), academicYearController.activateAcademicYear);
router.delete('/:id', auth, roleCheck(['admin']), academicYearController.deleteAcademicYear);

module.exports = router;