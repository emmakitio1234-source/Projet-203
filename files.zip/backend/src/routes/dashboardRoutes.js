const express = require('express');
const dashboardController = require('../controllers/dashboardController');
const { auth } = require('../middleware/auth');
const { roleCheck } = require('../middleware/roleCheck');

const router = express.Router();

router.get('/stats', auth, roleCheck(['admin']), dashboardController.getDashboardStats);
router.get('/activity', auth, roleCheck(['admin']), dashboardController.getActivityFeed);

module.exports = router;