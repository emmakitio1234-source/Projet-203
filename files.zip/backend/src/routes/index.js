const express = require('express');

// Import all route modules
const authRoutes = require('./authRoutes');
const userRoutes = require('./userRoutes');
const departmentRoutes = require('./departmentRoutes');
const filiereRoutes = require('./filiereRoutes');
const classRoutes = require('./classRoutes');
const ueRoutes = require('./ueRoutes');
const roomRoutes = require('./roomRoutes');
const timeSlotRoutes = require('./timeSlotRoutes');
const timetableRoutes = require('./timetableRoutes');
const preferenceRoutes = require('./preferenceRoutes');
const conflictRoutes = require('./conflictRoutes');
const notificationRoutes = require('./notificationRoutes');
const messageRoutes = require('./messageRoutes');
const dashboardRoutes = require('./dashboardRoutes');
const settingsRoutes = require('./settingsRoutes');
const reportRoutes = require('./reportRoutes');
const analyticsRoutes = require('./analyticsRoutes');
const academicYearRoutes = require('./academicYearRoutes');
const semesterRoutes = require('./semesterRoutes');

const router = express.Router();

// API Routes
router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/departments', departmentRoutes);
router.use('/filieres', filiereRoutes);
router.use('/classes', classRoutes);
router.use('/ues', ueRoutes);
router.use('/rooms', roomRoutes);
router.use('/time-slots', timeSlotRoutes);
router.use('/timetable', timetableRoutes);
router.use('/preferences', preferenceRoutes);
router.use('/conflicts', conflictRoutes);
router.use('/notifications', notificationRoutes);
router.use('/messages', messageRoutes);
router.use('/dashboard', dashboardRoutes);
router.use('/settings', settingsRoutes);
router.use('/reports', reportRoutes);
router.use('/analytics', analyticsRoutes);
router.use('/academic-years', academicYearRoutes);
router.use('/semesters', semesterRoutes);

module.exports = router;