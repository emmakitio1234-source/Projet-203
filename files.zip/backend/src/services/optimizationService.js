class OptimizationService {
  async optimizeRoomAllocation(classData, timetableEntries) {
    const { Room } = require('../models');

    const optimizedAssignments = [];

    for (const entry of timetableEntries) {
      const availableRooms = await this.getAvailableRooms(
        entry.timeSlotId,
        entry.date,
        classData.studentCount,
      );

      if (availableRooms.length > 0) {
        // Select optimal room (smallest that fits)
        const optimalRoom = availableRooms.reduce((prev, curr) => (
          prev.capacity < curr.capacity ? prev : curr
        ));

        optimizedAssignments.push({
          entry,
          assignedRoom: optimalRoom,
          utilizationRate: (classData.studentCount / optimalRoom.capacity) * 100,
        });
      }
    }

    return optimizedAssignments;
  }

  async getAvailableRooms(timeSlotId, date, requiredCapacity) {
    const { Room, TimetableEntry } = require('../models');

    const allRooms = await Room.findAll({
      where: { isAvailable: true },
      raw: true,
    });

    const availableRooms = [];

    for (const room of allRooms) {
      if (room.capacity < requiredCapacity) continue;

      const isOccupied = await TimetableEntry.findOne({
        where: {
          roomId: room.id,
          timeSlotId,
          date,
        },
      });

      if (!isOccupied) {
        availableRooms.push(room);
      }
    }

    return availableRooms;
  }

  async generateOptimalSchedule(classId, semesterId) {
    const { TimetableEntry, Class, UE, TimeSlot } = require('../models');

    const classData = await Class.findByPk(classId);
    const ues = await UE.findAll();
    const timeSlots = await TimeSlot.findAll();

    const schedule = [];

    for (const ue of ues) {
      const sessions = Math.ceil(ue.hoursDuration / 2); // 2-hour sessions

      for (let i = 0; i < sessions; i++) {
        const availableSlot = timeSlots.find((slot) => !this.isSlotBooked(slot, classData));

        if (availableSlot) {
          schedule.push({
            ue,
            timeSlot: availableSlot,
            duration: Math.min(2, ue.hoursDuration - i * 2),
          });
        }
      }
    }

    return schedule;
  }

  isSlotBooked(slot, classData) {
    // Check if slot is already booked for this class
    // This is a simplified version
    return false;
  }

  async calculateRoomUtilization() {
    const { Room, TimetableEntry } = require('../models');

    const rooms = await Room.findAll();
    const utilization = [];

    for (const room of rooms) {
      const bookedSessions = await TimetableEntry. count({
        where: { roomId: room.id },
      });

      const totalPossibleSessions = 5 * 8; // 5 days * 8 hours/day
      const utilizationRate = (bookedSessions / totalPossibleSessions) * 100;

      utilization.push({
        room,
        bookedSessions,
        totalPossibleSessions,
        utilizationRate:  utilizationRate.toFixed(2),
      });
    }

    return utilization. sort((a, b) => b.utilizationRate - a.utilizationRate);
  }

  async suggestBestTimeSlots(teacherId) {
    const { TimetableEntry, TimeSlot } = require('../models');

    const teacherSessions = await TimetableEntry. findAll({
      where: { teacherId },
      include: [{ model: TimeSlot }],
    });

    const slotCounts = {};

    teacherSessions.forEach((session) => {
      const slotKey = session.timeSlot.dayOfWeek + session.timeSlot.startTime;
      slotCounts[slotKey] = (slotCounts[slotKey] || 0) + 1;
    });

    const suggestedSlots = Object.entries(slotCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);

    return suggestedSlots;
  }
}

module.exports = new OptimizationService();