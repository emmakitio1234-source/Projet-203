const { TimetableEntry, Class, User, Room, UE, Conflict } = require('../models');
const pdfService = require('./pdfService');
const excelService = require('./excelService');

class ReportService {
  async generateComprehensiveReport(filters = {}) {
    const {
      classId,
      teacherId,
      startDate,
      endDate,
      format = 'pdf',
    } = filters;

    const where = {};
    if (classId) where.classId = classId;
    if (teacherId) where.teacherId = teacherId;
    if (startDate && endDate) {
      where.date = {
        [Op.between]: [new Date(startDate), new Date(endDate)],
      };
    }

    const entries = await TimetableEntry.findAll({
      where,
      include: [Class, UE, User, Room],
    });

    const reportData = {
      title: 'Comprehensive Timetable Report',
      generatedAt: new Date(),
      totalEntries: entries.length,
      entries,
      summary: this.generateSummary(entries),
    };

    if (format === 'pdf') {
      return await pdfService. generateComprehensivePDF(reportData);
    } else if (format === 'excel') {
      return await excelService.generateComprehensiveExcel(reportData);
    }
  }

  async generateTeacherReport(teacherId, semesterId) {
    const entries = await TimetableEntry.findAll({
      where: { teacherId, semesterId },
      include: [Class, UE, Room, { model: TimeSlot }],
    });

    const workload = this.calculateWorkload(entries);
    const schedule = this.organizeByDay(entries);

    return {
      teacher: await User.findByPk(teacherId),
      workload,
      schedule,
      entries,
    };
  }

  async generateRoomUtilizationReport() {
    const rooms = await Room.findAll();
    const utilization = [];

    for (const room of rooms) {
      const bookings = await TimetableEntry.count({
        where: { roomId: room.id },
      });

      const totalSlots = 5 * 8; // 5 days * 8 hours
      const rate = (bookings / totalSlots) * 100;

      utilization.push({
        room,
        bookings,
        totalSlots,
        utilizationRate: rate. toFixed(2),
        status: this.getUtilizationStatus(rate),
      });
    }

    return utilization. sort((a, b) => b.utilizationRate - a.utilizationRate);
  }

  async generateConflictAnalysis() {
    const conflicts = await Conflict.findAll({
      include: [
        { model: TimetableEntry, as:  'timetableEntry1' },
        { model: TimetableEntry, as: 'timetableEntry2' },
      ],
    });

    const analysis = {
      total: conflicts.length,
      byType: {},
      bySeverity: {},
      resolved: 0,
      pending: 0,
    };

    conflicts.forEach((conflict) => {
      // By type
      if (! analysis.byType[conflict.type]) {
        analysis.byType[conflict.type] = 0;
      }
      analysis.byType[conflict.type]++;

      // By severity
      if (!analysis.bySeverity[conflict.severity]) {
        analysis.bySeverity[conflict.severity] = 0;
      }
      analysis.bySeverity[conflict.severity]++;

      // Status
      if (conflict.isResolved) {
        analysis.resolved++;
      } else {
        analysis.pending++;
      }
    });

    return analysis;
  }

  generateSummary(entries) {
    return {
      totalSessions: entries.length,
      totalHours: entries.reduce((sum, e) => sum + (e. ue?.hoursDuration || 0), 0),
      uniqueTeachers: new Set(entries. map(e => e.teacherId)).size,
      uniqueRooms: new Set(entries. map(e => e.roomId)).size,
      uniqueUEs: new Set(entries.map(e => e.ueId)).size,
    };
  }

  calculateWorkload(entries) {
    return {
      totalSessions: entries. length,
      totalHours:  entries.reduce((sum, e) => sum + (e.ue?.hoursDuration || 0), 0),
      averageHoursPerDay: this.getAverageHoursPerDay(entries),
      hoursPerUE: this.getHoursPerUE(entries),
    };
  }

  organizeByDay(entries) {
    const schedule = {};
    entries.forEach((entry) => {
      const day = entry.timeSlot?. dayOfWeek;
      if (!schedule[day]) {
        schedule[day] = [];
      }
      schedule[day].push(entry);
    });
    return schedule;
  }

  getAverageHoursPerDay(entries) {
    const daysMap = {};
    entries.forEach((entry) => {
      const day = entry.timeSlot?.dayOfWeek;
      if (! daysMap[day]) {
        daysMap[day] = 0;
      }
      daysMap[day] += entry.ue?.hoursDuration || 0;
    });
    const values = Object.values(daysMap);
    return values.length > 0 ? (values.reduce((a, b) => a + b, 0) / values.length).toFixed(2) : 0;
  }

  getHoursPerUE(entries) {
    const ueMap = {};
    entries.forEach((entry) => {
      const ueCode = entry.ue?.code;
      if (!ueMap[ueCode]) {
        ueMap[ueCode] = 0;
      }
      ueMap[ueCode] += entry.ue?.hoursDuration || 0;
    });
    return ueMap;
  }

  getUtilizationStatus(rate) {
    if (rate >= 80) return 'Excellent';
    if (rate >= 60) return 'Good';
    if (rate >= 40) return 'Fair';
    if (rate >= 20) return 'Poor';
    return 'Very Poor';
  }
}

module.exports = new ReportService();