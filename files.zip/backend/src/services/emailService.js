const nodemailer = require('nodemailer');
const transporter = require('../config/email');

class EmailService {
  async sendReminder(to, classEntry) {
    const mailOptions = {
      from:  process.env.EMAIL_USER,
      to,
      subject: `Reminder: Class on ${classEntry.date}`,
      html: `
        <h2>Class Reminder</h2>
        <p>You have a class scheduled for: </p>
        <ul>
          <li><strong>Date:</strong> ${classEntry.date}</li>
          <li><strong>Time:</strong> ${classEntry.timeSlot.startTime} - ${classEntry.timeSlot.endTime}</li>
          <li><strong>Room:</strong> ${classEntry.room. name}</li>
          <li><strong>UE:</strong> ${classEntry. ue.name}</li>
        </ul>
      `,
    };

    return transporter.sendMail(mailOptions);
  }

  async sendPreferenceApproval(to, teacher, semester) {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to,
      subject: 'Your preferences have been approved',
      html: `
        <h2>Preferences Approved</h2>
        <p>Dear ${teacher.firstName},</p>
        <p>Your teaching preferences for semester ${semester} have been approved by the administrator.</p>
        <p>You can now view your assigned schedule in the system.</p>
      `,
    };

    return transporter. sendMail(mailOptions);
  }

  async sendTimetableAlert(to, classInfo, message) {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to,
      subject: `Timetable Alert for ${classInfo.code}`,
      html: `
        <h2>Timetable Alert</h2>
        <p>Alert for class <strong>${classInfo.code}</strong>:</p>
        <p>${message}</p>
      `,
    };

    return transporter.sendMail(mailOptions);
  }
}

module. exports = new EmailService();