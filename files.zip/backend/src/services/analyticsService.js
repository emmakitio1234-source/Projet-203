class AnalyticsService {
  calculateOccupancyRate(timetableEntries, totalRooms) {
    const occupiedSlots = timetableEntries. length;
    const totalSlots = totalRooms * 5 * 8; // 5 days, 8 hours per day
    return ((occupiedSlots / totalSlots) * 100).toFixed(2);
  }

  calculateTeacherWorkload(teacherId, timetableEntries) {
    const teacherClasses = timetableEntries. filter((e) => e.teacherId === teacherId);
    const hours = teacherClasses.reduce((sum, e) => sum + e. ue.hoursDuration, 0);
    return {
      classCount: teacherClasses.length,
      totalHours: hours,
      averageHoursPerWeek: (hours / 16).toFixed(2), // Assuming 16-week semester
    };
  }

  calculateClassEfficiency(classId, timetableEntries, rooms) {
    const classEntries = timetableEntries.filter((e) => e.classId === classId);
    let totalCapacity = 0;

    classEntries.forEach((entry) => {
      const room = rooms.find((r) => r.id === entry.roomId);
      if (room) {
        totalCapacity += room.capacity;
      }
    });

    return {
      classCount: classEntries.length,
      averageRoomCapacity: (totalCapacity / classEntries.length).toFixed(2),
    };
  }

  getConflictStatistics(conflicts) {
    const statistics = {
      total: conflicts.length,
      byType: {},
      bySeverity: {},
      resolved: conflicts.filter((c) => c.isResolved).length,
    };

    conflicts.forEach((conflict) => {
      statistics.byType[conflict.type] = (statistics.byType[conflict.type] || 0) + 1;
      statistics.bySeverity[conflict.severity] = (statistics.bySeverity[conflict.severity] || 0) + 1;
    });

    return statistics;
  }
}

module.exports = new AnalyticsService();