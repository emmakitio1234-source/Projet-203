const { User, Department, Filiere, Class, AcademicYear, Semester, UE, Room, TimeSlot } = require('../models');
const bcrypt = require('bcryptjs');

class SeedService {
  async seedDatabase() {
    try {
      console.log('🌱 Starting database seeding...');

      // Create academic year
      const year = await AcademicYear. create({
        year: '2025/2026',
        startDate: new Date('2025-09-01'),
        endDate: new Date('2026-06-30'),
        isActive: true,
      });

      console.log('✅ Academic year created');

      // Create department
      const dept = await Department.create({
        code: 'ICT',
        name: 'Information and Communication Technologies',
        description: 'ICT Department',
      });

      console.log('✅ Department created');

      // Create filiere
      const filiere = await Filiere.create({
        code: 'L2',
        name: 'Licence 2',
        description: 'Second Year License',
        departmentId: dept.id,
      });

      console.log('✅ Filiere created');

      // Create semesters
      await Semester.create({
        number: '1',
        startDate: new Date('2025-09-01'),
        endDate: new Date('2026-01-31'),
        academicYearId: year.id,
      });

      await Semester.create({
        number: '2',
        startDate: new Date('2026-02-01'),
        endDate: new Date('2026-06-30'),
        academicYearId: year.id,
      });

      console.log('✅ Semesters created');

      // Create users
      const adminPassword = await bcrypt.hash('AdminPassword123', 10);
      const teacherPassword = await bcrypt.hash('TeacherPassword123', 10);
      const studentPassword = await bcrypt.hash('StudentPassword123', 10);

      await User.create({
        firstName: 'John',
        lastName: 'Admin',
        email: 'admin@example.com',
        password: adminPassword,
        role:  'admin',
      });

      for (let i = 1; i <= 5; i++) {
        await User.create({
          firstName: `Teacher${i}`,
          lastName: 'User',
          email: `teacher${i}@example.com`,
          password: teacherPassword,
          role: 'teacher',
        });
      }

      for (let i = 1; i <= 10; i++) {
        await User.create({
          firstName: `Student${i}`,
          lastName: 'User',
          email: `student${i}@example.com`,
          password: studentPassword,
          role: 'student',
        });
      }

      console.log('✅ Users created');

      // Create rooms
      const roomData = [
        { code: 'A101', name: 'Classroom A101', capacity: 40, building: 'A', floor: 1, roomType: 'classroom' },
        { code: 'A102', name: 'Classroom A102', capacity: 50, building: 'A', floor: 1, roomType: 'classroom' },
        { code: 'A201', name: 'Classroom A201', capacity: 35, building: 'A', floor: 2, roomType: 'classroom' },
        { code: 'B101', name: 'Lab B101', capacity: 30, building: 'B', floor:  1, roomType: 'lab' },
        { code: 'B102', name: 'Lab B102', capacity: 28, building: 'B', floor: 1, roomType: 'lab' },
        { code: 'C101', name: 'Amphitheater C101', capacity:  200, building: 'C', floor: 1, roomType: 'amphitheater' },
      ];

      for (const room of roomData) {
        await Room.create(room);
      }

      console. log('✅ Rooms created');

      // Create time slots
      const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
      const times = [
        { start: '08:00:00', end: '10:00:00' },
        { start: '10:00:00', end: '12:00:00' },
        { start: '14:00:00', end: '16:00:00' },
        { start: '16:00:00', end: '18:00:00' },
      ];

      for (const day of days) {
        for (const time of times) {
          await TimeSlot.create({
            startTime: time.start,
            endTime: time.end,
            dayOfWeek: day,
            isAvailable: true,
          });
        }
      }

      console.log('✅ Time slots created');

      // Create UEs
      const ueData = [
        { code:  'ICT-201', name: 'Web Development', credits: 3, hoursDuration: 24, filiereId: filiere.id },
        { code: 'ICT-202', name: 'Database Design', credits: 3, hoursDuration: 20, filiereId: filiere.id },
        { code: 'ICT-203', name: 'Mobile Development', credits: 3, hoursDuration: 22, filiereId: filiere.id },
        { code: 'ICT-204', name: 'Cloud Computing', credits: 3, hoursDuration: 18, filiereId: filiere.id },
        { code: 'ICT-205', name: 'AI & Machine Learning', credits: 3, hoursDuration: 26, filiereId: filiere.id },
      ];

      for (const ue of ueData) {
        await UE.create(ue);
      }

      console. log('✅ UEs created');

      // Create class
      await Class.create({
        code: 'ICT-L2-A',
        name: 'ICT Level 2 - Section A',
        filiereId: filiere.id,
        academicYearId: year.id,
        studentCount: 45,
      });

      console.log('✅ Class created');

      console.log('✅ Database seeding completed successfully! ');
      return true;
    } catch (error) {
      console.error('❌ Error seeding database:', error. message);
      throw error;
    }
  }
}

module.exports = new SeedService();