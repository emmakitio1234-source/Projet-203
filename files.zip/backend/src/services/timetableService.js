const { TimetableEntry, Class, UE, User, Room, TimeSlot, Semester, Conflict } = require('../models');
const logger = require('../utils/logger');
const cacheService = require('./cacheService');
const { Op } = require('sequelize');

class TimetableService {
  /**
   * Create timetable entry
   */
  async createTimetableEntry(entryData) {
    try {
      const { classId, ueId, teacherId, roomId, timeSlotId, date, semesterId } = entryData;

      // Validate all IDs exist
      const [classExists, ueExists, teacherExists, roomExists, timeSlotExists] = await Promise.all([
        Class.findByPk(classId),
        UE.findByPk(ueId),
        User.findByPk(teacherId),
        Room.findByPk(roomId),
        TimeSlot.findByPk(timeSlotId),
      ]);

      if (!classExists || !ueExists || !teacherExists || !roomExists || !timeSlotExists) {
        throw new Error('Invalid reference:  One or more entities not found');
      }

      // Check for conflicts
      const conflicts = await this.detectConflicts(classId, teacherId, roomId, timeSlotId, date);
      if (conflicts.length > 0) {
        throw new Error(`Scheduling conflicts detected: ${conflicts.map(c => c.type).join(', ')}`);
      }

      // Check room capacity
      if (classExists.studentCount > roomExists.capacity) {
        throw new Error(`Room capacity (${roomExists.capacity}) is less than class size (${classExists.studentCount})`);
      }

      const entry = await TimetableEntry.create({
        classId,
        ueId,
        teacherId,
        roomId,
        timeSlotId,
        date:  new Date(date),
        semesterId,
        status: 'scheduled',
      });

      // Invalidate caches
      await cacheService. invalidatePattern(`timetable:${classId}*`);

      logger.info({
        action: 'createTimetableEntry',
        entryId: entry.id,
        classId,
        teacherId,
      });

      return entry;
    } catch (error) {
      logger.error('Error creating timetable entry:', error);
      throw new Error(`Failed to create timetable entry: ${error.message}`);
    }
  }

  /**
   * Get timetable entries with filters
   */
  async getTimetableEntries(filters = {}) {
    try {
      const { classId, semesterId, teacherId, roomId, startDate, endDate, status, page = 1, limit = 10 } = filters;
      const where = {};

      if (classId) where.classId = classId;
      if (semesterId) where.semesterId = semesterId;
      if (teacherId) where.teacherId = teacherId;
      if (roomId) where.roomId = roomId;
      if (status) where.status = status;

      if (startDate && endDate) {
        where.date = {
          [Op. between]: [new Date(startDate), new Date(endDate)],
        };
      }

      const offset = (page - 1) * limit;

      const entries = await TimetableEntry.findAndCountAll({
        where,
        include: [
          { model: Class, attributes: ['id', 'code', 'name'] },
          { model: UE, attributes:  ['id', 'code', 'name'] },
          { model: User, attributes: ['id', 'firstName', 'lastName'], as: 'teacher' },
          { model: Room, attributes: ['id', 'code', 'name', 'capacity'] },
          { model: TimeSlot, attributes: ['id', 'startTime', 'endTime', 'dayOfWeek'] },
        ],
        offset,
        limit: parseInt(limit),
        order: [['date', 'ASC'], ['timeSlotId', 'ASC']],
      });

      logger.info({
        action: 'getTimetableEntries',
        total: entries.count,
        page,
      });

      return {
        data: entries.rows,
        total: entries.count,
        page:  parseInt(page),
        pages: Math.ceil(entries.count / limit),
      };
    } catch (error) {
      logger.error('Error getting timetable entries:', error);
      throw new Error(`Failed to get entries: ${error.message}`);
    }
  }

  /**
   * Update timetable entry
   */
  async updateTimetableEntry(entryId, updates) {
    try {
      const entry = await TimetableEntry.findByPk(entryId);
      if (!entry) {
        throw new Error('Timetable entry not found');
      }

      const { teacherId, roomId, timeSlotId, date, status } = updates;

      // If changing time/room/date, check for conflicts
      if (teacherId || roomId || timeSlotId || date) {
        const conflicts = await this.detectConflicts(
          entry.classId,
          teacherId || entry.teacherId,
          roomId || entry.roomId,
          timeSlotId || entry. timeSlotId,
          date || entry.date,
          entryId
        );

        if (conflicts.length > 0) {
          throw new Error(`Scheduling conflicts detected`);
        }
      }

      await entry.update({
        teacherId:  teacherId || entry.teacherId,
        roomId: roomId || entry.roomId,
        timeSlotId: timeSlotId || entry.timeSlotId,
        date: date ?  new Date(date) : entry.date,
        status: status || entry.status,
      });

      // Invalidate cache
      await cacheService.invalidatePattern(`timetable:${entry.classId}*`);

      logger.info({
        action: 'updateTimetableEntry',
        entryId,
      });

      return entry;
    } catch (error) {
      logger.error(`Error updating timetable entry ${entryId}: `, error);
      throw new Error(`Failed to update entry: ${error.message}`);
    }
  }

  /**
   * Delete timetable entry
   */
  async deleteTimetableEntry(entryId) {
    try {
      const entry = await TimetableEntry. findByPk(entryId);
      if (!entry) {
        throw new Error('Timetable entry not found');
      }

      const classId = entry.classId;
      await entry.destroy();

      // Invalidate cache
      await cacheService.invalidatePattern(`timetable:${classId}*`);

      logger.info({
        action: 'deleteTimetableEntry',
        entryId,
      });

      return { message: 'Timetable entry deleted' };
    } catch (error) {
      logger.error(`Error deleting timetable entry ${entryId}:`, error);
      throw new Error(`Failed to delete entry: ${error.message}`);
    }
  }

  /**
   * Detect scheduling conflicts
   */
  async detectConflicts(classId, teacherId, roomId, timeSlotId, date, excludeEntryId = null) {
    try {
      const conflicts = [];

      // Room overlap check
      const roomConflict = await TimetableEntry.findOne({
        where: {
          roomId,
          timeSlotId,
          date,
          id: { [Op.ne]: excludeEntryId || null },
        },
      });

      if (roomConflict) {
        conflicts.push({
          type: 'room_overlap',
          description: 'Room is already booked for this time',
          conflictingEntryId: roomConflict.id,
        });
      }

      // Teacher overlap check
      const teacherConflict = await TimetableEntry.findOne({
        where: {
          teacherId,
          timeSlotId,
          date,
          id: { [Op.ne]: excludeEntryId || null },
        },
      });

      if (teacherConflict) {
        conflicts. push({
          type: 'teacher_overlap',
          description:  'Teacher already has a class at this time',
          conflictingEntryId: teacherConflict.id,
        });
      }

      return conflicts;
    } catch (error) {
      logger.error('Error detecting conflicts:', error);
      throw new Error(`Failed to detect conflicts: ${error.message}`);
    }
  }

  /**
   * Confirm timetable entry
   */
  async confirmTimetableEntry(entryId) {
    try {
      const entry = await TimetableEntry.findByPk(entryId);
      if (!entry) {
        throw new Error('Timetable entry not found');
      }

      await entry.update({ status: 'confirmed' });

      logger.info({
        action: 'confirmTimetableEntry',
        entryId,
      });

      return entry;
    } catch (error) {
      logger.error(`Error confirming entry ${entryId}:`, error);
      throw new Error(`Failed to confirm entry: ${error.message}`);
    }
  }

  /**
   * Cancel timetable entry
   */
  async cancelTimetableEntry(entryId, reason = null) {
    try {
      const entry = await TimetableEntry.findByPk(entryId);
      if (!entry) {
        throw new Error('Timetable entry not found');
      }

      await entry.update({ status: 'cancelled' });

      logger.info({
        action: 'cancelTimetableEntry',
        entryId,
        reason,
      });

      return entry;
    } catch (error) {
      logger.error(`Error cancelling entry ${entryId}:`, error);
      throw new Error(`Failed to cancel entry: ${error.message}`);
    }
  }

  /**
   * Get timetable overview for semester
   */
  async getTimetableOverview(semesterId) {
    try {
      const entries = await TimetableEntry. findAll({
        where: { semesterId },
        attributes: ['status'],
      });

      const overview = {
        totalSessions: entries.length,
        scheduled: entries.filter(e => e.status === 'scheduled').length,
        confirmed: entries.filter(e => e.status === 'confirmed').length,
        cancelled: entries.filter(e => e.status === 'cancelled').length,
      };

      return overview;
    } catch (error) {
      logger.error(`Error getting overview for semester ${semesterId}: `, error);
      throw new Error(`Failed to get overview: ${error.message}`);
    }
  }
}

module.exports = new TimetableService();