const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User } = require('../models');
const jwtConfig = require('../config/jwt');
const emailService = require('./emailService');

class AuthService {
  async register(userData) {
    const { firstName, lastName, email, password, role } = userData;

    // Check if user exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      throw new Error('User already exists');
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = await User.create({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      role:  role || 'student',
    });

    // Send welcome email
    await emailService.sendWelcomeEmail(user);

    return this.generateTokens(user);
  }

  async login(email, password) {
    const user = await User.findOne({ where: { email } });
    
    if (!user) {
      throw new Error('Invalid credentials');
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      throw new Error('Invalid credentials');
    }

    // Update last login
    await user.update({ lastLogin: new Date() });

    return this.generateTokens(user);
  }

  async refreshToken(refreshToken) {
    try {
      const decoded = jwt.verify(refreshToken, jwtConfig.refreshSecret);
      const user = await User.findByPk(decoded.id);

      if (!user) {
        throw new Error('User not found');
      }

      return this.generateTokens(user);
    } catch (error) {
      throw new Error('Invalid refresh token');
    }
  }

  async requestPasswordReset(email) {
    const user = await User.findOne({ where: { email } });
    
    if (!user) {
      throw new Error('User not found');
    }

    // Generate reset token
    const resetToken = jwt.sign(
      { id: user.id, type: 'password-reset' },
      jwtConfig.secret,
      { expiresIn: '1h' }
    );

    // Send reset email
    await emailService.sendPasswordResetEmail(user, resetToken);

    return { message: 'Password reset email sent' };
  }

  async resetPassword(resetToken, newPassword) {
    try {
      const decoded = jwt.verify(resetToken, jwtConfig.secret);
      
      if (decoded.type !== 'password-reset') {
        throw new Error('Invalid token');
      }

      const user = await User.findByPk(decoded.id);
      if (!user) {
        throw new Error('User not found');
      }

      const hashedPassword = await bcrypt. hash(newPassword, 10);
      await user.update({ password: hashedPassword });

      return { message: 'Password reset successful' };
    } catch (error) {
      throw new Error('Invalid or expired reset token');
    }
  }

  async validateToken(token) {
    try {
      const decoded = jwt.verify(token, jwtConfig.secret);
      return decoded;
    } catch (error) {
      return null;
    }
  }

  generateTokens(user) {
    const accessToken = jwt.sign(
      { id: user.id, role: user.role },
      jwtConfig.secret,
      { expiresIn: jwtConfig.expiresIn }
    );

    const refreshToken = jwt.sign(
      { id: user. id },
      jwtConfig. refreshSecret,
      { expiresIn: jwtConfig.refreshExpiresIn }
    );

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        role: user.role,
        firstName: user.firstName,
        lastName: user.lastName,
      },
    };
  }

  async changePassword(userId, oldPassword, newPassword) {
    const user = await User.findByPk(userId);
    if (!user) {
      throw new Error('User not found');
    }

    const passwordMatch = await bcrypt.compare(oldPassword, user.password);
    if (!passwordMatch) {
      throw new Error('Current password is incorrect');
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await user.update({ password: hashedPassword });

    return { message: 'Password changed successfully' };
  }

  async verifyEmail(verificationToken) {
    try {
      const decoded = jwt.verify(verificationToken, jwtConfig.secret);
      
      const user = await User.findByPk(decoded.id);
      if (!user) {
        throw new Error('User not found');
      }

      // Mark as verified (add isVerified field to User model)
      return { message: 'Email verified successfully' };
    } catch (error) {
      throw new Error('Invalid verification token');
    }
  }
}

module.exports = new AuthService();