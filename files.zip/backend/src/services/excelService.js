const ExcelJS = require('exceljs');
const path = require('path');

class ExcelService {
  async generateTimetable(timetableData, classInfo) {
    const workbook = new ExcelJS. Workbook();
    const worksheet = workbook.addWorksheet('Timetable');

    // Set column widths
    worksheet.columns = [
      { header: 'Time', key: 'time', width: 12 },
      { header: 'Monday', key: 'monday', width: 25 },
      { header: 'Tuesday', key: 'tuesday', width: 25 },
      { header: 'Wednesday', key: 'wednesday', width:  25 },
      { header: 'Thursday', key: 'thursday', width: 25 },
      { header: 'Friday', key: 'friday', width: 25 },
    ];

    // Add title
    worksheet.mergeCells('A1:F1');
    worksheet.getCell('A1').value = `Timetable - ${classInfo.name}`;
    worksheet.getCell('A1').font = { bold: true, size: 14 };

    // Add metadata
    worksheet.mergeCells('A2:F2');
    worksheet.getCell('A2').value = `Class: ${classInfo.code} | Year: ${classInfo.academicYear}`;

    // Add headers
    const headerRow = worksheet.getRow(4);
    headerRow.font = { bold: true };
    headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD3D3D3' } };

    // Add data
    timetableData.forEach((entry, index) => {
      worksheet.addRow(entry);
    });

    // Save file
    const fileName = `timetable-${classInfo.code}-${Date.now()}.xlsx`;
    const filePath = path.join(__dirname, '../../exports', fileName);

    await workbook.xlsx.writeFile(filePath);
    return filePath;
  }
}

module.exports = new ExcelService();