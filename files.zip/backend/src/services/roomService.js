const { Room, TimetableEntry, TimeSlot } = require('../models');
const logger = require('../utils/logger');
const cacheService = require('./cacheService');
const { Op } = require('sequelize');

class RoomService {
  /**
   * Get all rooms with filters
   */
  async getAllRooms(filters = {}) {
    try {
      const { building, capacity, roomType, isAvailable, page = 1, limit = 10 } = filters;
      const where = {};

      if (building) where.building = building;
      if (roomType) where.roomType = roomType;
      if (isAvailable !== undefined) where.isAvailable = isAvailable;
      if (capacity) {
        where.capacity = { [Op.gte]: parseInt(capacity) };
      }

      const offset = (page - 1) * limit;

      const rooms = await Room.findAndCountAll({
        where,
        offset,
        limit: parseInt(limit),
        order: [['code', 'ASC']],
      });

      logger.info({
        action: 'getAllRooms',
        total: rooms. count,
        page,
      });

      return {
        data: rooms.rows,
        total: rooms.count,
        page: parseInt(page),
        pages: Math.ceil(rooms.count / limit),
      };
    } catch (error) {
      logger.error('Error getting rooms:', error);
      throw new Error(`Failed to get rooms: ${error. message}`);
    }
  }

  /**
   * Get room by ID
   */
  async getRoomById(roomId) {
    try {
      const cacheKey = `room:${roomId}`;
      const cached = await cacheService.get(cacheKey);
      if (cached) return cached;

      const room = await Room.findByPk(roomId);
      if (!room) {
        throw new Error('Room not found');
      }

      await cacheService. set(cacheKey, room, 3600);
      return room;
    } catch (error) {
      logger.error(`Error getting room ${roomId}:`, error);
      throw new Error(`Failed to get room: ${error. message}`);
    }
  }

  /**
   * Create new room
   */
  async createRoom(roomData) {
    try {
      const { code, name, capacity, building, floor, roomType, equipments } = roomData;

      // Check if code already exists
      const existingRoom = await Room.findOne({ where: { code } });
      if (existingRoom) {
        throw new Error('Room with this code already exists');
      }

      const room = await Room.create({
        code,
        name,
        capacity,
        building,
        floor,
        roomType:  roomType || 'classroom',
        equipments:  equipments || [],
        isAvailable: true,
      });

      // Invalidate cache
      await cacheService.invalidatePattern('room:*');

      logger.info({
        action: 'createRoom',
        roomId: room.id,
        code:  room.code,
      });

      return room;
    } catch (error) {
      logger.error('Error creating room:', error);
      throw new Error(`Failed to create room: ${error.message}`);
    }
  }

  /**
   * Update room
   */
  async updateRoom(roomId, updates) {
    try {
      const room = await Room.findByPk(roomId);
      if (!room) {
        throw new Error('Room not found');
      }

      const { code, name, capacity, building, floor, roomType, equipments, isAvailable } = updates;

      if (code && code !== room.code) {
        const existingRoom = await Room. findOne({ where: { code } });
        if (existingRoom) {
          throw new Error('Room with this code already exists');
        }
      }

      await room.update({
        code:  code || room.code,
        name: name || room.name,
        capacity: capacity !== undefined ? capacity : room.capacity,
        building: building || room. building,
        floor: floor !== undefined ? floor : room.floor,
        roomType: roomType || room.roomType,
        equipments: equipments || room.equipments,
        isAvailable:  isAvailable !== undefined ? isAvailable : room.isAvailable,
      });

      // Invalidate cache
      await cacheService.delete(`room:${roomId}`);

      logger.info({
        action: 'updateRoom',
        roomId,
      });

      return room;
    } catch (error) {
      logger.error(`Error updating room ${roomId}:`, error);
      throw new Error(`Failed to update room: ${error.message}`);
    }
  }

  /**
   * Delete room
   */
  async deleteRoom(roomId) {
    try {
      const room = await Room.findByPk(roomId);
      if (!room) {
        throw new Error('Room not found');
      }

      // Check if room has bookings
      const bookingCount = await TimetableEntry. count({
        where: { roomId },
      });

      if (bookingCount > 0) {
        throw new Error('Cannot delete room with existing bookings');
      }

      await room.destroy();

      // Invalidate cache
      await cacheService.delete(`room:${roomId}`);

      logger.info({
        action: 'deleteRoom',
        roomId,
      });

      return { message: 'Room deleted successfully' };
    } catch (error) {
      logger.error(`Error deleting room ${roomId}:`, error);
      throw new Error(`Failed to delete room: ${error. message}`);
    }
  }

  /**
   * Check room availability
   */
  async checkRoomAvailability(roomId, timeSlotId, date) {
    try {
      const booking = await TimetableEntry.findOne({
        where: {
          roomId,
          timeSlotId,
          date,
        },
      });

      return ! booking;
    } catch (error) {
      logger.error(`Error checking room availability: `, error);
      throw new Error(`Failed to check availability: ${error.message}`);
    }
  }

  /**
   * Get room schedule
   */
  async getRoomSchedule(roomId, startDate, endDate) {
    try {
      const entries = await TimetableEntry.findAll({
        where: {
          roomId,
          date:  {
            [Op.between]:  [new Date(startDate), new Date(endDate)],
          },
        },
        include: [
          { model: require('../models').Class },
          { model: require('../models').UE },
          { model: require('../models').TimeSlot },
        ],
        order: [['date', 'ASC']],
      });

      return entries;
    } catch (error) {
      logger.error(`Error getting room schedule for ${roomId}:`, error);
      throw new Error(`Failed to get schedule: ${error.message}`);
    }
  }

  /**
   * Get room utilization
   */
  async getRoomUtilization(roomId) {
    try {
      const room = await Room.findByPk(roomId);
      if (!room) {
        throw new Error('Room not found');
      }

      const bookings = await TimetableEntry.count({
        where: { roomId },
      });

      const totalSlots = 5 * 8; // 5 days * 8 hours
      const utilizationRate = (bookings / totalSlots) * 100;

      return {
        roomId,
        roomCode: room.code,
        bookings,
        totalSlots,
        utilizationRate:  parseFloat(utilizationRate.toFixed(2)),
        status: utilizationRate > 80 ? 'High' : utilizationRate > 60 ? 'Medium' : 'Low',
      };
    } catch (error) {
      logger.error(`Error getting room utilization for ${roomId}:`, error);
      throw new Error(`Failed to get utilization: ${error.message}`);
    }
  }

  /**
   * Get available rooms for specific time
   */
  async getAvailableRooms(timeSlotId, date, minCapacity = 0) {
    try {
      const bookedRoomIds = await TimetableEntry. findAll({
        where: {
          timeSlotId,
          date,
        },
        attributes: ['roomId'],
        raw: true,
      });

      const bookedIds = bookedRoomIds.map(r => r.roomId);

      const availableRooms = await Room. findAll({
        where: {
          isAvailable: true,
          capacity: { [Op. gte]: minCapacity },
          id: { [Op.notIn]: bookedIds. length > 0 ?  bookedIds : [null] },
        },
        order: [['capacity', 'ASC']],
      });

      return availableRooms;
    } catch (error) {
      logger.error('Error getting available rooms:', error);
      throw new Error(`Failed to get available rooms: ${error.message}`);
    }
  }

  /**
   * Get room statistics
   */
  async getRoomStatistics() {
    try {
      const totalRooms = await Room.count();
      const availableRooms = await Room.count({ where: { isAvailable: true } });

      const roomsByType = await Room.findAll({
        attributes: ['roomType', [require('sequelize').fn('COUNT', require('sequelize').col('id')), 'count']],
        group: ['roomType'],
        raw: true,
      });

      const totalCapacity = await Room.sum('capacity');

      return {
        totalRooms,
        availableRooms,
        unavailableRooms: totalRooms - availableRooms,
        totalCapacity,
        averageCapacity: Math.round(totalCapacity / totalRooms),
        byType: roomsByType,
      };
    } catch (error) {
      logger.error('Error getting room statistics:', error);
      throw new Error(`Failed to get statistics: ${error.message}`);
    }
  }
}

module.exports = new RoomService();