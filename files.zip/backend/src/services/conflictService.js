const { TimetableEntry } = require('../models');
const { CONFLICT_TYPES } = require('../config/constants');

class ConflictService {
  async checkConflicts(params) {
    const {
      roomId, teacherId, timeSlotId, date, classId,
    } = params;

    const conflicts = [];

    // Check room overlap
    const roomConflict = await TimetableEntry.findOne({
      where: {
        roomId,
        timeSlotId,
        date,
      },
    });

    if (roomConflict) {
      conflicts.push({
        type: CONFLICT_TYPES.ROOM_OVERLAP,
        conflictingEntryId: roomConflict.id,
        message: 'Room is already booked for this time slot',
      });
    }

    // Check teacher overlap
    const teacherConflict = await TimetableEntry.findOne({
      where: {
        teacherId,
        timeSlotId,
        date,
      },
    });

    if (teacherConflict) {
      conflicts.push({
        type: CONFLICT_TYPES. TEACHER_OVERLAP,
        conflictingEntryId: teacherConflict.id,
        message: 'Teacher is already scheduled for this time slot',
      });
    }

    return conflicts;
  }

  async detectAllConflicts() {
    const entries = await TimetableEntry.findAll();
    const conflicts = [];

    for (let i = 0; i < entries.length; i++) {
      for (let j = i + 1; j < entries.length; j++) {
        const conflict = this.compareEntries(entries[i], entries[j]);
        if (conflict) {
          conflicts.push(conflict);
        }
      }
    }

    return conflicts;
  }

  compareEntries(entry1, entry2) {
    if (entry1.timeSlotId === entry2.timeSlotId && entry1.date === entry2.date) {
      if (entry1.roomId === entry2.roomId) {
        return {
          type: CONFLICT_TYPES.ROOM_OVERLAP,
          entry1Id: entry1.id,
          entry2Id: entry2.id,
        };
      }

      if (entry1.teacherId === entry2.teacherId) {
        return {
          type: CONFLICT_TYPES.TEACHER_OVERLAP,
          entry1Id: entry1.id,
          entry2Id: entry2.id,
        };
      }
    }

    return null;
  }
}

module.exports = new ConflictService();