const PDFDocument = require('pdfkit');
const fs = require('fs');
const path = require('path');

class PDFService {
  async generateTimetable(timetableData, classInfo) {
    return new Promise((resolve, reject) => {
      try {
        const fileName = `timetable-${classInfo.code}-${Date.now()}.pdf`;
        const filePath = path.join(__dirname, '../../exports', fileName);

        const doc = new PDFDocument();
        const stream = fs.createWriteStream(filePath);

        doc.pipe(stream);

        // Title
        doc.fontSize(20).text(`Timetable - ${classInfo.name}`, 100, 50);
        doc.fontSize(12).text(`Class: ${classInfo.code}`, 100, 80);
        doc.fontSize(12).text(`Academic Year: ${classInfo.academicYear}`, 100, 100);

        // Table header
        let y = 140;
        doc.fontSize(10).font('Helvetica-Bold');
        doc.text('Time', 50, y);
        doc.text('Monday', 120, y);
        doc.text('Tuesday', 180, y);
        doc.text('Wednesday', 240, y);
        doc.text('Thursday', 310, y);
        doc.text('Friday', 370, y);

        y += 20;
        doc.font('Helvetica');

        // Fill data
        timetableData.forEach((entry) => {
          doc.text(entry.time, 50, y);
          doc.text(entry.monday || '', 120, y);
          doc.text(entry.tuesday || '', 180, y);
          doc.text(entry.wednesday || '', 240, y);
          doc.text(entry.thursday || '', 310, y);
          doc.text(entry.friday || '', 370, y);
          y += 20;
        });

        doc.end();

        stream.on('finish', () => {
          resolve(filePath);
        });
      } catch (error) {
        reject(error);
      }
    });
  }
}

module.exports = new PDFService();