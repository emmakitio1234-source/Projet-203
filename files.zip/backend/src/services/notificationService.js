const { Notification, User } = require('../models');

class NotificationService {
  async createNotification(userId, notificationType) {
    const {
      type, title, message, relatedEntityId, relatedEntityType,
    } = notificationType;

    return Notification.create({
      userId,
      type,
      title,
      message,
      relatedEntityId,
      relatedEntityType,
    });
  }

  async getUserNotifications(userId, limit = 20) {
    return Notification. findAll({
      where: { userId },
      order: [['createdAt', 'DESC']],
      limit,
    });
  }

  async markAsRead(notificationId) {
    const notification = await Notification.findByPk(notificationId);
    if (notification) {
      await notification.update({ isRead: true });
    }
    return notification;
  }

  async markAllAsRead(userId) {
    return Notification.update(
      { isRead: true },
      { where: { userId, isRead: false } },
    );
  }
}

module.exports = new NotificationService();