const { Class, Filiere, AcademicYear, TimetableEntry, User, UE, Room, TimeSlot, Conflict } = require('../models');
const { Op } = require('sequelize');
const logger = require('../utils/logger');
const cacheService = require('./cacheService');

class ClassService {
  /**
   * Get all classes with optional filters
   */
  async getAllClasses(filters = {}) {
    try {
      const { filiereId, academicYearId, isActive, page = 1, limit = 10 } = filters;
      const where = {};

      if (filiereId) where.filiereId = filiereId;
      if (academicYearId) where.academicYearId = academicYearId;
      if (isActive !== undefined) where.isActive = isActive;

      const offset = (page - 1) * limit;

      const classes = await Class.findAndCountAll({
        where,
        include: [
          { model: Filiere, attributes: ['id', 'code', 'name'] },
          { model: AcademicYear, attributes: ['id', 'year', 'isActive'] },
        ],
        offset,
        limit: parseInt(limit),
        order: [['code', 'ASC']],
      });

      logger.info({
        action: 'getAllClasses',
        total: classes.count,
        page,
        limit,
      });

      return {
        data: classes.rows,
        total: classes.count,
        page:  parseInt(page),
        pages: Math.ceil(classes.count / limit),
      };
    } catch (error) {
      logger.error('Error getting all classes:', error);
      throw new Error(`Failed to get classes: ${error. message}`);
    }
  }

  /**
   * Get class by ID with all related data
   */
  async getClassById(classId) {
    try {
      // Check cache first
      const cacheKey = `class:${classId}`;
      const cachedClass = await cacheService.get(cacheKey);
      if (cachedClass) {
        logger.debug(`Class ${classId} retrieved from cache`);
        return cachedClass;
      }

      const classData = await Class.findByPk(classId, {
        include: [
          { model: Filiere, include: [{ model: require('../models').Department }] },
          { model: AcademicYear },
        ],
      });

      if (!classData) {
        throw new Error(`Class ${classId} not found`);
      }

      // Cache the result
      await cacheService.set(cacheKey, classData, 3600);

      return classData;
    } catch (error) {
      logger.error(`Error getting class ${classId}:`, error);
      throw new Error(`Failed to get class:  ${error.message}`);
    }
  }

  /**
   * Create a new class
   */
  async createClass(classData) {
    try {
      const { code, name, filiereId, academicYearId, studentCount, description } = classData;

      // Validate filiere exists
      const filiere = await Filiere.findByPk(filiereId);
      if (!filiere) {
        throw new Error('Filiere not found');
      }

      // Validate academic year exists
      const academicYear = await AcademicYear.findByPk(academicYearId);
      if (!academicYear) {
        throw new Error('Academic year not found');
      }

      // Check if class code already exists
      const existingClass = await Class.findOne({ where: { code } });
      if (existingClass) {
        throw new Error('Class with this code already exists');
      }

      const newClass = await Class.create({
        code,
        name,
        filiereId,
        academicYearId,
        studentCount,
        description,
        isActive: true,
      });

      // Invalidate related caches
      await cacheService.invalidatePattern('class:*');

      logger.info({
        action: 'createClass',
        classId: newClass.id,
        code:  newClass.code,
      });

      return newClass;
    } catch (error) {
      logger.error('Error creating class:', error);
      throw new Error(`Failed to create class: ${error.message}`);
    }
  }

  /**
   * Update class details
   */
  async updateClass(classId, updates) {
    try {
      const classData = await Class.findByPk(classId);
      if (!classData) {
        throw new Error('Class not found');
      }

      const { code, name, studentCount, description, isActive } = updates;

      // If code is being updated, check if it's unique
      if (code && code !== classData.code) {
        const existingClass = await Class.findOne({ where: { code } });
        if (existingClass) {
          throw new Error('Class with this code already exists');
        }
      }

      await classData.update({
        code:  code || classData.code,
        name: name || classData. name,
        studentCount: studentCount !== undefined ? studentCount : classData. studentCount,
        description: description || classData.description,
        isActive: isActive !== undefined ?  isActive : classData.isActive,
      });

      // Invalidate cache
      await cacheService.invalidatePattern(`class:${classId}*`);

      logger.info({
        action: 'updateClass',
        classId,
        updates:  Object.keys(updates),
      });

      return classData;
    } catch (error) {
      logger.error(`Error updating class ${classId}: `, error);
      throw new Error(`Failed to update class: ${error.message}`);
    }
  }

  /**
   * Delete a class
   */
  async deleteClass(classId) {
    try {
      const classData = await Class.findByPk(classId);
      if (!classData) {
        throw new Error('Class not found');
      }

      // Check if class has timetable entries
      const entryCount = await TimetableEntry.count({
        where: { classId },
      });

      if (entryCount > 0) {
        throw new Error('Cannot delete class with existing timetable entries');
      }

      await classData.destroy();

      // Invalidate cache
      await cacheService.delete(`class:${classId}`);

      logger.info({
        action: 'deleteClass',
        classId,
      });

      return { message: 'Class deleted successfully' };
    } catch (error) {
      logger.error(`Error deleting class ${classId}:`, error);
      throw new Error(`Failed to delete class: ${error. message}`);
    }
  }

  /**
   * Get class timetable with all details
   */
  async getClassTimetable(classId, semesterId, options = {}) {
    try {
      const { startDate, endDate, sort = 'date' } = options;

      const where = { classId };
      if (semesterId) where.semesterId = semesterId;

      if (startDate && endDate) {
        where.date = {
          [Op.between]: [new Date(startDate), new Date(endDate)],
        };
      }

      const entries = await TimetableEntry.findAll({
        where,
        include: [
          { model: UE, attributes: ['id', 'code', 'name', 'hoursDuration'] },
          { model: User, attributes: ['id', 'firstName', 'lastName'], as: 'teacher' },
          { model: Room, attributes: ['id', 'code', 'name', 'capacity', 'building'] },
          { model: TimeSlot, attributes: ['id', 'startTime', 'endTime', 'dayOfWeek'] },
        ],
        order:  [[sort, 'ASC']],
      });

      logger.info({
        action: 'getClassTimetable',
        classId,
        semesterId,
        entriesCount: entries.length,
      });

      return entries;
    } catch (error) {
      logger.error(`Error getting timetable for class ${classId}:`, error);
      throw new Error(`Failed to get timetable: ${error.message}`);
    }
  }

  /**
   * Get class statistics
   */
  async getClassStatistics(classId) {
    try {
      const classData = await Class.findByPk(classId);
      if (!classData) {
        throw new Error('Class not found');
      }

      const entries = await TimetableEntry.findAll({
        where: { classId },
        include: [{ model: UE }],
      });

      const totalHours = entries.reduce(
        (sum, e) => sum + (e. ue?. hoursDuration || 0),
        0
      );

      const uniqueTeachers = new Set(entries.map(e => e. teacherId)).size;
      const uniqueRooms = new Set(entries.map(e => e. roomId)).size;
      const uniqueUEs = new Set(entries.map(e => e.ueId)).size;

      const stats = {
        classId,
        classCode: classData.code,
        className: classData.name,
        studentCount: classData.studentCount,
        totalSessions: entries.length,
        totalHours,
        uniqueTeachers,
        uniqueRooms,
        uniqueUEs,
        averageSessionDuration: totalHours / (entries.length || 1),
        hoursPerStudent: totalHours / classData. studentCount,
      };

      logger.info({
        action: 'getClassStatistics',
        classId,
        stats,
      });

      return stats;
    } catch (error) {
      logger.error(`Error getting statistics for class ${classId}:`, error);
      throw new Error(`Failed to get statistics: ${error. message}`);
    }
  }

  /**
   * Update class student count
   */
  async updateClassSize(classId, newSize) {
    try {
      if (newSize < 0 || newSize > 1000) {
        throw new Error('Student count must be between 0 and 1000');
      }

      const classData = await Class.findByPk(classId);
      if (!classData) {
        throw new Error('Class not found');
      }

      const oldSize = classData.studentCount;
      await classData.update({ studentCount: newSize });

      // Invalidate cache
      await cacheService.delete(`class:${classId}`);

      logger.info({
        action: 'updateClassSize',
        classId,
        oldSize,
        newSize,
      });

      return classData;
    } catch (error) {
      logger.error(`Error updating class size for ${classId}:`, error);
      throw new Error(`Failed to update class size: ${error.message}`);
    }
  }

  /**
   * Get class conflicts
   */
  async getClassConflicts(classId) {
    try {
      const entries = await TimetableEntry.findAll({
        where: { classId },
        attributes: ['id'],
      });

      const entryIds = entries.map(e => e.id);

      if (entryIds.length === 0) {
        return [];
      }

      const conflicts = await Conflict.findAll({
        where: {
          [Op.or]: [
            { timetableEntry1Id: { [Op.in]: entryIds } },
            { timetableEntry2Id: { [Op. in]: entryIds } },
          ],
        },
        include: [
          { model: TimetableEntry, as: 'timetableEntry1' },
          { model: TimetableEntry, as: 'timetableEntry2' },
        ],
      });

      logger.info({
        action: 'getClassConflicts',
        classId,
        conflictCount: conflicts.length,
      });

      return conflicts;
    } catch (error) {
      logger.error(`Error getting conflicts for class ${classId}:`, error);
      throw new Error(`Failed to get conflicts: ${error. message}`);
    }
  }

  /**
   * Get class UEs
   */
  async getClassUEs(classId) {
    try {
      const entries = await TimetableEntry.findAll({
        where: { classId },
        include: [{ model:  UE }],
        attributes: [],
        raw: true,
        subQuery: false,
      });

      const uesMap = new Map();
      entries.forEach(entry => {
        if (entry['UE. id'] && !uesMap.has(entry['UE.id'])) {
          uesMap.set(entry['UE.id'], {
            id: entry['UE.id'],
            code: entry['UE.code'],
            name: entry['UE.name'],
            credits: entry['UE.credits'],
            hoursDuration: entry['UE.hoursDuration'],
          });
        }
      });

      const ues = Array.from(uesMap.values());

      logger.info({
        action: 'getClassUEs',
        classId,
        uesCount: ues. length,
      });

      return ues;
    } catch (error) {
      logger.error(`Error getting UEs for class ${classId}:`, error);
      throw new Error(`Failed to get UEs: ${error.message}`);
    }
  }

  /**
   * Get class teachers
   */
  async getClassTeachers(classId) {
    try {
      const entries = await TimetableEntry.findAll({
        where: { classId },
        include: [
          { model: User, attributes:  ['id', 'firstName', 'lastName', 'email'], as: 'teacher' },
        ],
        attributes: [],
        raw: true,
        subQuery: false,
      });

      const teachersMap = new Map();
      entries.forEach(entry => {
        if (entry['teacher.id'] && !teachersMap.has(entry['teacher.id'])) {
          teachersMap.set(entry['teacher.id'], {
            id: entry['teacher.id'],
            firstName: entry['teacher.firstName'],
            lastName: entry['teacher. lastName'],
            email: entry['teacher.email'],
            fullName: `${entry['teacher.firstName']} ${entry['teacher. lastName']}`,
          });
        }
      });

      const teachers = Array.from(teachersMap.values());

      logger.info({
        action: 'getClassTeachers',
        classId,
        teachersCount: teachers.length,
      });

      return teachers;
    } catch (error) {
      logger.error(`Error getting teachers for class ${classId}:`, error);
      throw new Error(`Failed to get teachers: ${error.message}`);
    }
  }

  /**
   * Get class schedule overview
   */
  async getClassScheduleOverview(classId) {
    try {
      const entries = await TimetableEntry. findAll({
        where: { classId },
        include: [
          { model: TimeSlot },
          { model: Room },
        ],
      });

      const overview = {
        totalSessions: entries.length,
        byDay: {},
        byRoom: {},
        byStatus: {
          scheduled: 0,
          confirmed: 0,
          cancelled:  0,
        },
      };

      entries.forEach(entry => {
        // Count by day
        const day = entry.timeSlot?. dayOfWeek;
        if (day) {
          overview.byDay[day] = (overview.byDay[day] || 0) + 1;
        }

        // Count by room
        const roomCode = entry.room?.code;
        if (roomCode) {
          overview.byRoom[roomCode] = (overview.byRoom[roomCode] || 0) + 1;
        }

        // Count by status
        overview.byStatus[entry.status]++;
      });

      logger.info({
        action: 'getClassScheduleOverview',
        classId,
        overview,
      });

      return overview;
    } catch (error) {
      logger.error(`Error getting schedule overview for class ${classId}:`, error);
      throw new Error(`Failed to get schedule overview: ${error.message}`);
    }
  }

  /**
   * Check if class has capacity issues
   */
  async checkCapacityIssues(classId) {
    try {
      const classData = await Class.findByPk(classId);
      if (!classData) {
        throw new Error('Class not found');
      }

      const entries = await TimetableEntry.findAll({
        where: { classId },
        include: [{ model: Room }],
      });

      const issues = [];

      entries.forEach(entry => {
        if (entry.room && classData.studentCount > entry.room.capacity) {
          issues.push({
            entryId: entry.id,
            roomCode: entry.room.code,
            roomCapacity: entry.room.capacity,
            classSize: classData.studentCount,
            overage: classData.studentCount - entry.room.capacity,
          });
        }
      });

      logger.info({
        action: 'checkCapacityIssues',
        classId,
        issuesFound: issues.length,
      });

      return issues;
    } catch (error) {
      logger.error(`Error checking capacity issues for class ${classId}:`, error);
      throw new Error(`Failed to check capacity:  ${error.message}`);
    }
  }
}

module.exports = new ClassService();