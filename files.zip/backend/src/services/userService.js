const { User, Role } = require('../models');
const bcrypt = require('bcryptjs');
const logger = require('../utils/logger');
const cacheService = require('./cacheService');
const { Op } = require('sequelize');

class UserService {
  /**
   * Get all users with filters
   */
  async getAllUsers(filters = {}) {
    try {
      const { role, isActive, search, page = 1, limit = 10 } = filters;
      const where = {};

      if (role) where.role = role;
      if (isActive !== undefined) where.isActive = isActive;

      if (search) {
        where[Op.or] = [
          { firstName: { [Op.like]: `%${search}%` } },
          { lastName: { [Op.like]: `%${search}%` } },
          { email: { [Op.like]: `%${search}%` } },
        ];
      }

      const offset = (page - 1) * limit;

      const users = await User.findAndCountAll({
        where,
        offset,
        limit:  parseInt(limit),
        attributes: { exclude: ['password'] },
        order: [['createdAt', 'DESC']],
      });

      logger.info({
        action: 'getAllUsers',
        total: users.count,
        page,
      });

      return {
        data: users.rows,
        total: users.count,
        page:  parseInt(page),
        pages: Math.ceil(users.count / limit),
      };
    } catch (error) {
      logger.error('Error getting users:', error);
      throw new Error(`Failed to get users: ${error. message}`);
    }
  }

  /**
   * Get user by ID
   */
  async getUserById(userId) {
    try {
      const cacheKey = `user:${userId}`;
      const cached = await cacheService.get(cacheKey);
      if (cached) return cached;

      const user = await User.findByPk(userId, {
        attributes: { exclude: ['password'] },
      });

      if (!user) {
        throw new Error('User not found');
      }

      await cacheService.set(cacheKey, user, 3600);
      return user;
    } catch (error) {
      logger.error(`Error getting user ${userId}:`, error);
      throw new Error(`Failed to get user: ${error. message}`);
    }
  }

  /**
   * Get user by email
   */
  async getUserByEmail(email) {
    try {
      const user = await User.findOne({ where: { email } });
      if (!user) {
        throw new Error('User not found');
      }
      return user;
    } catch (error) {
      logger.error(`Error getting user by email ${email}:`, error);
      throw new Error(`Failed to get user: ${error.message}`);
    }
  }

  /**
   * Create new user
   */
  async createUser(userData) {
    try {
      const { firstName, lastName, email, password, role = 'student' } = userData;

      // Check if user exists
      const existingUser = await User.findOne({ where: { email } });
      if (existingUser) {
        throw new Error('User with this email already exists');
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      const user = await User.create({
        firstName,
        lastName,
        email,
        password: hashedPassword,
        role,
        isActive: true,
      });

      // Invalidate cache
      await cacheService.invalidatePattern('user:*');

      logger.info({
        action: 'createUser',
        userId:  user.id,
        email:  user.email,
        role: user.role,
      });

      return {
        id: user.id,
        firstName:  user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
      };
    } catch (error) {
      logger.error('Error creating user:', error);
      throw new Error(`Failed to create user: ${error.message}`);
    }
  }

  /**
   * Update user
   */
  async updateUser(userId, updates) {
    try {
      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      const { firstName, lastName, phone, avatar, role } = updates;

      await user.update({
        firstName:  firstName || user.firstName,
        lastName: lastName || user.lastName,
        phone: phone || user. phone,
        avatar: avatar || user.avatar,
        role: role || user.role,
      });

      // Invalidate cache
      await cacheService.delete(`user:${userId}`);

      logger.info({
        action: 'updateUser',
        userId,
        updatedFields: Object.keys(updates),
      });

      return {
        id: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
      };
    } catch (error) {
      logger.error(`Error updating user ${userId}:`, error);
      throw new Error(`Failed to update user: ${error. message}`);
    }
  }

  /**
   * Change user password
   */
  async changePassword(userId, oldPassword, newPassword) {
    try {
      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      const passwordMatch = await bcrypt.compare(oldPassword, user.password);
      if (!passwordMatch) {
        throw new Error('Current password is incorrect');
      }

      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await user.update({ password: hashedPassword });

      logger.info({
        action: 'changePassword',
        userId,
      });

      return { message: 'Password changed successfully' };
    } catch (error) {
      logger.error(`Error changing password for user ${userId}:`, error);
      throw new Error(`Failed to change password: ${error. message}`);
    }
  }

  /**
   * Deactivate user
   */
  async deactivateUser(userId) {
    try {
      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      await user.update({ isActive: false });

      // Invalidate cache
      await cacheService.delete(`user:${userId}`);

      logger.info({
        action: 'deactivateUser',
        userId,
      });

      return { message: 'User deactivated successfully' };
    } catch (error) {
      logger.error(`Error deactivating user ${userId}:`, error);
      throw new Error(`Failed to deactivate user: ${error. message}`);
    }
  }

  /**
   * Activate user
   */
  async activateUser(userId) {
    try {
      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      await user.update({ isActive: true });

      // Invalidate cache
      await cacheService. delete(`user:${userId}`);

      logger.info({
        action: 'activateUser',
        userId,
      });

      return { message: 'User activated successfully' };
    } catch (error) {
      logger.error(`Error activating user ${userId}:`, error);
      throw new Error(`Failed to activate user: ${error.message}`);
    }
  }

  /**
   * Get users by role
   */
  async getUsersByRole(role, limit = 50) {
    try {
      const users = await User.findAll({
        where: { role, isActive: true },
        attributes: { exclude: ['password'] },
        limit,
        order: [['firstName', 'ASC']],
      });

      return users;
    } catch (error) {
      logger.error(`Error getting users by role ${role}: `, error);
      throw new Error(`Failed to get users: ${error.message}`);
    }
  }

  /**
   * Delete user
   */
  async deleteUser(userId) {
    try {
      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      await user.destroy();

      // Invalidate cache
      await cacheService.delete(`user:${userId}`);

      logger.info({
        action: 'deleteUser',
        userId,
      });

      return { message: 'User deleted successfully' };
    } catch (error) {
      logger.error(`Error deleting user ${userId}:`, error);
      throw new Error(`Failed to delete user: ${error.message}`);
    }
  }

  /**
   * Get user statistics
   */
  async getUserStatistics(userId) {
    try {
      const { TimetableEntry } = require('../models');

      const user = await User.findByPk(userId);
      if (!user) {
        throw new Error('User not found');
      }

      const timetableCount = await TimetableEntry.count({
        where: { teacherId: userId },
      });

      const stats = {
        userId,
        role: user.role,
        totalTimetableEntries: timetableCount,
        joinDate: user.createdAt,
        lastLogin: user.lastLogin,
        isActive: user.isActive,
      };

      return stats;
    } catch (error) {
      logger.error(`Error getting statistics for user ${userId}:`, error);
      throw new Error(`Failed to get statistics: ${error.message}`);
    }
  }

  /**
   * Bulk import users
   */
  async bulkImportUsers(users) {
    try {
      const results = {
        successful: 0,
        failed: 0,
        errors: [],
      };

      for (const userData of users) {
        try {
          await this.createUser(userData);
          results.successful++;
        } catch (error) {
          results.failed++;
          results.errors.push({
            email: userData.email,
            error: error.message,
          });
        }
      }

      logger.info({
        action: 'bulkImportUsers',
        successful: results.successful,
        failed: results.failed,
      });

      return results;
    } catch (error) {
      logger.error('Error bulk importing users:', error);
      throw new Error(`Failed to import users: ${error.message}`);
    }
  }
}

module.exports = new UserService();