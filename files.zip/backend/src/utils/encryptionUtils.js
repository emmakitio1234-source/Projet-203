const crypto = require('crypto');

const algorithm = 'aes-256-gcm';
const key = crypto.scryptSync(process.env. ENCRYPTION_KEY || 'default-key', 'salt', 32);

exports.encrypt = (text) => {
  try {
    const iv = crypto. randomBytes(16);
    const cipher = crypto.createCipheriv(algorithm, key, iv);

    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');

    const authTag = cipher.getAuthTag();

    return {
      iv: iv.toString('hex'),
      encryptedData: encrypted,
      authTag: authTag.toString('hex'),
    };
  } catch (error) {
    console.error('Encryption error:', error);
    throw error;
  }
};

exports.decrypt = (encryptedObj) => {
  try {
    const decipher = crypto.createDecipheriv(
      algorithm,
      key,
      Buffer.from(encryptedObj.iv, 'hex'),
    );

    decipher.setAuthTag(Buffer.from(encryptedObj.authTag, 'hex'));

    let decrypted = decipher.update(encryptedObj.encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');

    return decrypted;
  } catch (error) {
    console.error('Decryption error:', error);
    throw error;
  }
};

exports.hashPassword = async (password) => {
  const bcrypt = require('bcryptjs');
  return bcrypt.hash(password, 10);
};

exports.comparePassword = async (password, hash) => {
  const bcrypt = require('bcryptjs');
  return bcrypt.compare(password, hash);
};