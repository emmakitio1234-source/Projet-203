const { responseFormatter } = require('../utils/responseFormatter');

const validateQuery = (schema) => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.query, {
      abortEarly: false,
      stripUnknown:  true,
    });

    if (error) {
      const details = error.details.map((detail) => ({
        path: detail.path.join('.'),
        message: detail.message,
      }));

      return res.status(400).json(
        responseFormatter(false, 'Query validation error', { details })
      );
    }

    req.query = value;
    next();
  };
};

module.exports = validateQuery;