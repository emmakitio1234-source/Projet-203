const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const redis = require('../config/redis');

// General rate limiter
const generalLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'rate-limit: ',
  }),
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

// Auth rate limiter (stricter)
const authLimiter = rateLimit({
  store: new RedisStore({
    client:  redis,
    prefix: 'auth-limit:',
  }),
  windowMs: 15 * 60 * 1000,
  max: 5, // limit each IP to 5 login attempts per windowMs
  message:  'Too many login attempts, please try again later.',
  skipSuccessfulRequests: true,
});

// API rate limiter
const apiLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix:  'api-limit:',
  }),
  windowMs: 60 * 1000, // 1 minute
  max: 30, // limit each IP to 30 requests per minute
  message: 'Too many API requests, please try again later.',
});

// File upload rate limiter
const uploadLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'upload-limit:',
  }),
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // limit each IP to 10 uploads per hour
  message: 'Too many file uploads, please try again later.',
});

module.exports = {
  generalLimiter,
  authLimiter,
  apiLimiter,
  uploadLimiter,
};