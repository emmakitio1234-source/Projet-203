module.exports = {
  ROLES: {
    ADMIN: 'admin',
    TEACHER: 'teacher',
    STUDENT: 'student',
  },
  SEMESTER: {
    FIRST: 'semester_1',
    SECOND: 'semester_2',
  },
  TIME_VIEW: {
    DAY: 'day',
    WEEK: 'week',
    MONTH: 'month',
  },
  PREFERENCE_STATUS: {
    PENDING: 'pending',
    APPROVED: 'approved',
    REJECTED: 'rejected',
    MODIFIED: 'modified',
  },
  CONFLICT_TYPES: {
    ROOM_OVERLAP: 'room_overlap',
    TEACHER_OVERLAP: 'teacher_overlap',
    STUDENT_OVERLAP: 'student_overlap',
    ROOM_CAPACITY: 'room_capacity',
  },
};