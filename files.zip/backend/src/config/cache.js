const redis = require('redis');

const cacheConfig = {
  // Cache TTL (Time To Live) in seconds
  ttl: {
    default: 3600, // 1 hour
    timetable: 1800, // 30 minutes
    user: 7200, // 2 hours
    room: 3600, // 1 hour
    notification: 600, // 10 minutes
  },

  // Cache key prefixes
  prefixes: {
    timetable: 'timetable:',
    user: 'user: ',
    room: 'room:',
    class: 'class:',
    preference: 'preference:',
    notification: 'notification:',
  },

  // Cache patterns for invalidation
  patterns: {
    classPattern: 'timetable:*',
    userPattern: 'user:*',
  },
};

module.exports = cacheConfig;