const logger = require('../utils/logger');

const loggingConfig = {
  // Log all SQL queries
  logging: (sql, timing) => {
    if (process.env.NODE_ENV === 'development') {
      logger.debug(`[${timing}ms] ${sql}`);
    }
  },

  // Benchmark queries
  benchmark: true,
};

module.exports = loggingConfig;