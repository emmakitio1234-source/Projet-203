module.exports = (socket, io) => {
  socket.on('subscribe-notifications', (userId) => {
    socket.join(`notifications-${userId}`);
    socket.emit('subscribed', { channel: `notifications-${userId}` });
  });

  socket.on('unsubscribe-notifications', (userId) => {
    socket.leave(`notifications-${userId}`);
  });

  // Function to send notification to user
  const sendNotification = (userId, notification) => {
    io.to(`notifications-${userId}`).emit('notification', notification);
  };

  socket.on('get-notifications', async (userId) => {
    try {
      // This would be called from the notification service
      socket.emit('notifications-list', []);
    } catch (error) {
      socket.emit('error', error. message);
    }
  });

  module.exports. sendNotification = sendNotification;
};