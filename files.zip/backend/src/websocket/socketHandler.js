const socketIO = require('socket.io');
const notificationSocket = require('./notificationSocket');
const chatSocket = require('./chatSocket');

module.exports = (server) => {
  const io = socketIO(server, {
    cors: {
      origin: process.env. FRONTEND_URL || 'http://localhost:3000',
      methods: ['GET', 'POST'],
    },
  });

  io.on('connection', (socket) => {
    console.log(`New client connected: ${socket.id}`);

    // Initialize notification socket
    notificationSocket(socket, io);

    // Initialize chat socket
    chatSocket(socket, io);

    socket.on('disconnect', () => {
      console. log(`Client disconnected: ${socket.id}`);
    });
  });

  return io;
};