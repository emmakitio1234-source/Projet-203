module.exports = (socket, io) => {
  socket.on('join-chat', (roomId) => {
    socket.join(`chat-${roomId}`);
    io.to(`chat-${roomId}`).emit('user-joined', { userId: socket. id });
  });

  socket.on('send-message', (data) => {
    const { roomId, message, userId, timestamp } = data;
    io. to(`chat-${roomId}`).emit('message', {
      userId,
      message,
      timestamp,
      socketId: socket.id,
    });
  });

  socket.on('typing', (data) => {
    const { roomId, userId } = data;
    io.to(`chat-${roomId}`).emit('user-typing', { userId });
  });

  socket.on('stop-typing', (data) => {
    const { roomId, userId } = data;
    io.to(`chat-${roomId}`).emit('user-stop-typing', { userId });
  });

  socket.on('leave-chat', (roomId) => {
    socket.leave(`chat-${roomId}`);
    io.to(`chat-${roomId}`).emit('user-left', { userId: socket.id });
  });
};