const socketIO = require('socket.io');
const { verify } = require('jsonwebtoken');
const jwtConfig = require('../config/jwt');
const logger = require('../utils/logger');

class SocketManager {
  constructor(server) {
    this.io = socketIO(server, {
      cors: {
        origin:  process.env.FRONTEND_URL,
        credentials: true,
      },
    });

    this.setupMiddleware();
    this.setupEvents();
  }

  setupMiddleware() {
    // Authentication middleware
    this.io.use((socket, next) => {
      const token = socket.handshake.auth.token;

      if (!token) {
        return next(new Error('Authentication error'));
      }

      try {
        const decoded = verify(token, jwtConfig.secret);
        socket.userId = decoded.id;
        socket.userRole = decoded.role;
        next();
      } catch (err) {
        next(new Error('Authentication error'));
      }
    });
  }

  setupEvents() {
    this.io.on('connection', (socket) => {
      logger.info({
        event: 'socket_connected',
        userId: socket.userId,
        socketId: socket.id,
      });

      // Join user room
      socket.join(`user: ${socket.userId}`);
      socket.join(`role:${socket.userRole}`);

      // Timetable events
      socket.on('timetable:update', (data) => {
        this.handleTimetableUpdate(socket, data);
      });

      socket.on('timetable:create', (data) => {
        this.handleTimetableCreate(socket, data);
      });

      socket.on('timetable:delete', (data) => {
        this.handleTimetableDelete(socket, data);
      });

      // Notification events
      socket.on('notification:read', (data) => {
        this.handleNotificationRead(socket, data);
      });

      // Chat events
      socket.on('message:send', (data) => {
        this.handleMessageSend(socket, data);
      });

      // Disconnect event
      socket.on('disconnect', () => {
        logger.info({
          event: 'socket_disconnected',
          userId:  socket.userId,
          socketId: socket.id,
        });
      });
    });
  }

  handleTimetableUpdate(socket, data) {
    // Broadcast to relevant users
    this.io.to(`class:${data.classId}`).emit('timetable: updated', data);
    logger.info({
      event: 'timetable_updated',
      userId: socket.userId,
      entryId: data.entryId,
    });
  }

  handleTimetableCreate(socket, data) {
    this.io.to(`class:${data.classId}`).emit('timetable:created', data);
    this.io.to(`user:${data.teacherId}`).emit('notification:new', {
      type: 'info',
      message: 'You have been assigned a new class',
    });
  }

  handleTimetableDelete(socket, data) {
    this.io.to(`class:${data.classId}`).emit('timetable:deleted', data);
  }

  handleNotificationRead(socket, data) {
    socket.emit('notification:marked_read', data);
  }

  handleMessageSend(socket, data) {
    this.io.to(`room:${data.roomId}`).emit('message:received', data);
  }

  // Helper methods
  notifyUser(userId, event, data) {
    this.io.to(`user:${userId}`).emit(event, data);
  }

  notifyRole(role, event, data) {
    this.io.to(`role:${role}`).emit(event, data);
  }

  notifyClass(classId, event, data) {
    this.io.to(`class:${classId}`).emit(event, data);
  }

  broadcast(event, data) {
    this.io.emit(event, data);
  }
}

module.exports = SocketManager;