const sequelize = require('../config/database');
const User = require('./User')(sequelize);
const Department = require('./Department')(sequelize);
const Filiere = require('./Filiere')(sequelize);
const Class = require('./Class')(sequelize);
const AcademicYear = require('./AcademicYear')(sequelize);
const Semester = require('./Semester')(sequelize);
const UE = require('./UE')(sequelize);
const Room = require('./Room')(sequelize);
const TimeSlot = require('./TimeSlot')(sequelize);
const TimetableEntry = require('./TimetableEntry')(sequelize);
const TeacherPreference = require('./TeacherPreference')(sequelize);
const Notification = require('./Notification')(sequelize);
const Conflict = require('./Conflict')(sequelize);

// Define associations
Department.hasMany(Filiere, { foreignKey: 'departmentId' });
Filiere.belongsTo(Department);

Filiere.hasMany(Class, { foreignKey: 'filiereId' });
Class.belongsTo(Filiere);

AcademicYear.hasMany(Semester, { foreignKey: 'academicYearId' });
Semester.belongsTo(AcademicYear);

AcademicYear.hasMany(Class, { foreignKey: 'academicYearId' });
Class.belongsTo(AcademicYear);

Filiere.hasMany(UE, { foreignKey: 'filiereId' });
UE.belongsTo(Filiere);

Class.hasMany(TimetableEntry, { foreignKey:  'classId' });
TimetableEntry.belongsTo(Class);

UE.hasMany(TimetableEntry, { foreignKey:  'ueId' });
TimetableEntry.belongsTo(UE);

User.hasMany(TimetableEntry, { foreignKey:  'teacherId', as: 'taughtClasses' });
TimetableEntry.belongsTo(User, { foreignKey: 'teacherId', as: 'teacher' });

Room.hasMany(TimetableEntry, { foreignKey:  'roomId' });
TimetableEntry.belongsTo(Room);

TimeSlot.hasMany(TimetableEntry, { foreignKey: 'timeSlotId' });
TimetableEntry.belongsTo(TimeSlot);

Semester.hasMany(TimetableEntry, { foreignKey:  'semesterId' });
TimetableEntry.belongsTo(Semester);

User.hasMany(TeacherPreference, { foreignKey: 'teacherId', as: 'preferences' });
TeacherPreference.belongsTo(User, { foreignKey:  'teacherId', as: 'teacher' });

Semester.hasMany(TeacherPreference, { foreignKey: 'semesterId' });
TeacherPreference.belongsTo(Semester);

User.hasMany(Notification, { foreignKey: 'userId' });
Notification.belongsTo(User);

module.exports = {
  sequelize,
  User,
  Department,
  Filiere,
  Class,
  AcademicYear,
  Semester,
  UE,
  Room,
  TimeSlot,
  TimetableEntry,
  TeacherPreference,
  Notification,
  Conflict,
};