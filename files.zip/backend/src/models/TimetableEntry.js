const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const TimetableEntry = sequelize.define('TimetableEntry', {
    id: {
      type:  DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey:  true,
    },
    classId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'classes',
        key: 'id',
      },
    },
    ueId: {
      type:  DataTypes.UUID,
      allowNull: false,
      references:  {
        model: 'ues',
        key: 'id',
      },
    },
    teacherId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
    },
    roomId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'rooms',
        key: 'id',
      },
    },
    timeSlotId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'time_slots',
        key:  'id',
      },
    },
    date: {
      type: DataTypes.DATE,
      allowNull: false,
    },
    semesterId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'semesters',
        key: 'id',
      },
    },
    status: {
      type: DataTypes. ENUM('scheduled', 'confirmed', 'cancelled'),
      defaultValue: 'scheduled',
    },
  }, {
    tableName: 'timetable_entries',
  });

  return TimetableEntry;
};