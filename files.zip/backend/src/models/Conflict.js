const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Conflict = sequelize.define('Conflict', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    type: {
      type: DataTypes.ENUM('room_overlap', 'teacher_overlap', 'student_overlap', 'room_capacity'),
      allowNull: false,
    },
    timetableEntry1Id: {
      type: DataTypes.UUID,
      references: {
        model: 'timetable_entries',
        key: 'id',
      },
    },
    timetableEntry2Id: {
      type: DataTypes.UUID,
      references: {
        model:  'timetable_entries',
        key: 'id',
      },
    },
    description: DataTypes.TEXT,
    severity: {
      type: DataTypes.ENUM('low', 'medium', 'high'),
      defaultValue: 'medium',
    },
    isResolved: {
      type:  DataTypes.BOOLEAN,
      defaultValue: false,
    },
  }, {
    tableName: 'conflicts',
  });

  return Conflict;
};