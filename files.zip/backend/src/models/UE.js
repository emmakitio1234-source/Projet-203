const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const UE = sequelize.define('UE', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    code: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    name:  {
      type: DataTypes. STRING,
      allowNull: false,
    },
    credits: {
      type: DataTypes.INTEGER,
      defaultValue: 3,
    },
    hoursDuration: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    description: DataTypes.TEXT,
    filiereId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'filieres',
        key:  'id',
      },
    },
  }, {
    tableName: 'ues',
  });

  return UE;
};