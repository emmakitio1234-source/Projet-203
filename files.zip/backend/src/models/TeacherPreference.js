const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const TeacherPreference = sequelize.define('TeacherPreference', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey:  true,
    },
    teacherId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'users',
        key: 'id',
      },
    },
    semesterId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'semesters',
        key: 'id',
      },
    },
    preferredTimeSlots: {
      type: DataTypes.JSON,
      defaultValue: [],
    },
    preferredRooms: {
      type:  DataTypes.JSON,
      defaultValue: [],
    },
    unavailableDates: {
      type: DataTypes.JSON,
      defaultValue: [],
    },
    status: {
      type: DataTypes. ENUM('pending', 'approved', 'rejected', 'modified'),
      defaultValue: 'pending',
    },
    comments: DataTypes.TEXT,
    submittedAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    approvedAt: DataTypes.DATE,
    approvedBy: DataTypes.UUID,
  }, {
    tableName: 'teacher_preferences',
    timestamps: true,
  });

  return TeacherPreference;
};