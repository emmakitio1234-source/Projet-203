const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const ClassUE = sequelize.define('ClassUE', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey:  true,
    },
    classId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'classes',
        key: 'id',
      },
    },
    ueId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'ues',
        key: 'id',
      },
    },
    semesterId: {
      type: DataTypes.UUID,
      allowNull: false,
      references: {
        model: 'semesters',
        key: 'id',
      },
    },
  }, {
    tableName: 'class_ues',
  });

  return ClassUE;
};