const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Room = sequelize.define('Room', {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    code: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    capacity: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    building: DataTypes.STRING,
    floor: DataTypes.INTEGER,
    roomType: {
      type: DataTypes. ENUM('classroom', 'lab', 'amphitheater', 'other'),
      defaultValue: 'classroom',
    },
    equipments: DataTypes.JSON,
    isAvailable: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  }, {
    tableName:  'rooms',
  });

  return Room;
};