const express = require('express');
const http = require('http');
const dotenv = require('dotenv');
const cors = require('./middleware/cors');
const helmet = require('./middleware/helmet');
const { generalLimiter, authLimiter, apiLimiter } = require('./middleware/rateLimiter');
const metricsMiddleware = require('./middleware/metricsMiddleware');
const errorHandler = require('./middleware/errorHandler');
const { sequelize } = require('./models');
const SocketManager = require('./websocket/socketManager');
const logger = require('./utils/logger');
const routes = require('./routes');

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();
const server = http.createServer(app);

// Initialize WebSocket
const socketManager = new SocketManager(server);

// Middleware
app.use(helmet);
app.use(cors);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use(metricsMiddleware);

// Rate limiting
app.use('/api/auth', authLimiter);
app.use('/api/', apiLimiter);
app.use(generalLimiter);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date(),
    uptime: process.uptime(),
  });
});

// Metrics endpoint
const { metricsEndpoint } = require('./utils/metrics');
app.get('/metrics', metricsEndpoint);

// API routes
app.use('/api', routes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found',
    path: req.originalUrl,
  });
});

// Error handler
app.use(errorHandler);

// Database connection and server startup
const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || 'localhost';

const startServer = async () => {
  try {
    // Test database connection
    await sequelize. authenticate();
    logger.info('✅ Database connected');

    // Sync database
    await sequelize.sync({ alter: process.env.NODE_ENV !== 'production' });
    logger.info('✅ Database synced');

    // Start server
    server.listen(PORT, HOST, () => {
      logger.info(`✅ Server running on http://${HOST}:${PORT}`);
      logger.info(`📊 Metrics available at http://${HOST}:${PORT}/metrics`);
      logger.info(`❤️  Health check at http://${HOST}:${PORT}/health`);
      logger.info(`🌍 API available at http://${HOST}:${PORT}/api`);
    });

    // Graceful shutdown
    process.on('SIGTERM', () => {
      logger.info('SIGTERM signal received:  closing HTTP server');
      server.close(async () => {
        await sequelize.close();
        logger.info('HTTP server closed');
        process.exit(0);
      });
    });

    process.on('SIGINT', () => {
      logger.info('SIGINT signal received: closing HTTP server');
      server.close(async () => {
        await sequelize.close();
        logger.info('HTTP server closed');
        process.exit(0);
      });
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();

module.exports = { app, server, socketManager };