const cron = require('node-cron');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Backup database daily at 2 AM
cron. schedule('0 2 * * *', async () => {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupFile = path.join(__dirname, '../../database/backup', `backup-${timestamp}.sql`);

    const command = `mysqldump -u ${process.env.DB_USER} -p${process.env.DB_PASSWORD} ${process.env.DB_NAME} > ${backupFile}`;

    exec(command, (error) => {
      if (error) {
        console.error('Backup failed:', error);
      } else {
        console.log(`Backup completed:  ${backupFile}`);
      }
    });
  } catch (error) {
    console.error('Error in backup job:', error);
  }
});

module.exports = {};