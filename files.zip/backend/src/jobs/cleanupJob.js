const cron = require('node-cron');
const fs = require('fs');
const path = require('path');

// Clean up old logs weekly
cron.schedule('0 0 * * 0', async () => {
  try {
    const logsDir = path.join(__dirname, '../../logs');
    const files = fs.readdirSync(logsDir);

    files.forEach((file) => {
      const filePath = path.join(logsDir, file);
      const stats = fs.statSync(filePath);
      const age = Date.now() - stats.mtime.getTime();

      // Delete files older than 30 days
      if (age > 30 * 24 * 60 * 60 * 1000) {
        fs.unlinkSync(filePath);
        console.log(`Deleted old log:  ${file}`);
      }
    });

    console.log('Log cleanup job completed');
  } catch (error) {
    console.error('Error in cleanup job:', error);
  }
});

module.exports = {};