const cron = require('node-cron');
const { TimetableEntry, User, Notification } = require('../models');
const notificationService = require('../services/notificationService');
const emailService = require('../services/emailService');

// Send reminders 1 day before class
cron.schedule('0 09 * * *', async () => {
  try {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);

    const upcomingClasses = await TimetableEntry.findAll({
      where: {
        date: tomorrow. toISOString().split('T')[0],
      },
      include: [{ model: User, as: 'teacher' }],
    });

    for (const classEntry of upcomingClasses) {
      // Create notification
      await notificationService.createNotification(classEntry. teacherId, {
        type: 'info',
        title: 'Reminder:  Class Tomorrow',
        message: `You have a class tomorrow at ${classEntry.timeSlot. startTime}`,
      });

      // Send email
      await emailService.sendReminder(classEntry.teacher.email, classEntry);
    }

    console.log('Reminder job executed successfully');
  } catch (error) {
    console.error('Error in reminder job:', error);
  }
});

module.exports = {};