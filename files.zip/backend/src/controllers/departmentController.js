const { Department, Filiere } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');
const logger = require('../utils/logger');

exports.getAllDepartments = async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const departments = await Department.findAndCountAll({
      include: [Filiere],
      offset,
      limit:  parseInt(limit),
      order: [['code', 'ASC']],
    });

    logger.info({
      action: 'getAllDepartments',
      total: departments.count,
    });

    res.json(responseFormatter(true, 'Departments retrieved', {
      data: departments.rows,
      total: departments.count,
      page: parseInt(page),
      pages: Math.ceil(departments.count / limit),
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. getDepartmentById = async (req, res) => {
  try {
    const { id } = req.params;

    const department = await Department.findByPk(id, {
      include: [Filiere],
    });

    if (!department) {
      return res.status(404).json(responseFormatter(false, 'Department not found'));
    }

    res.json(responseFormatter(true, 'Department retrieved', department));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.createDepartment = async (req, res) => {
  try {
    const { code, name, description } = req.body;

    const department = await Department.create({
      code,
      name,
      description,
    });

    logger.info({
      action: 'createDepartment',
      departmentId: department.id,
      code,
    });

    res.status(201).json(responseFormatter(true, 'Department created', department));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error. message));
  }
};

exports.updateDepartment = async (req, res) => {
  try {
    const { id } = req.params;
    const { code, name, description } = req.body;

    const department = await Department.findByPk(id);
    if (!department) {
      return res.status(404).json(responseFormatter(false, 'Department not found'));
    }

    await department.update({
      code:  code || department.code,
      name: name || department.name,
      description: description || department. description,
    });

    logger.info({
      action: 'updateDepartment',
      departmentId: id,
    });

    res.json(responseFormatter(true, 'Department updated', department));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.deleteDepartment = async (req, res) => {
  try {
    const { id } = req. params;

    const department = await Department.findByPk(id);
    if (!department) {
      return res.status(404).json(responseFormatter(false, 'Department not found'));
    }

    // Check if department has filieres
    const filiereCount = await Filiere.count({ where: { departmentId: id } });
    if (filiereCount > 0) {
      return res. status(400).json(responseFormatter(false, 'Cannot delete department with existing filieres'));
    }

    await department.destroy();

    logger.info({
      action: 'deleteDepartment',
      departmentId: id,
    });

    res.json(responseFormatter(true, 'Department deleted'));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};