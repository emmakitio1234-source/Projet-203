const { AcademicYear, Semester } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getAllAcademicYears = async (req, res) => {
  try {
    const { isActive } = req.query;
    const where = isActive !== undefined ? { isActive:  isActive === 'true' } : {};

    const years = await AcademicYear. findAll({
      where,
      include: [Semester],
      order: [['year', 'DESC']],
    });

    res.json(responseFormatter(true, 'Academic years retrieved', years));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.createAcademicYear = async (req, res) => {
  try {
    const { year, startDate, endDate } = req. body;

    const year_obj = await AcademicYear.create({
      year,
      startDate:  new Date(startDate),
      endDate: new Date(endDate),
      isActive: false,
    });

    res.status(201).json(responseFormatter(true, 'Academic year created', year_obj));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.activateAcademicYear = async (req, res) => {
  try {
    const { id } = req.params;

    // Deactivate all other years
    await AcademicYear.update(
      { isActive: false },
      { where: { isActive: true } }
    );

    // Activate this year
    const year_obj = await AcademicYear.findByPk(id);
    if (! year_obj) {
      return res.status(404).json(responseFormatter(false, 'Academic year not found'));
    }

    await year_obj.update({ isActive: true });
    res.json(responseFormatter(true, 'Academic year activated', year_obj));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.deleteAcademicYear = async (req, res) => {
  try {
    const { id } = req.params;

    const year_obj = await AcademicYear.findByPk(id);
    if (!year_obj) {
      return res.status(404).json(responseFormatter(false, 'Academic year not found'));
    }

    await year_obj.destroy();
    res.json(responseFormatter(true, 'Academic year deleted'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};