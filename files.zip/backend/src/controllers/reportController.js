const { TimetableEntry, Class, User, Room } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');
const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');

exports.generateTimetableReport = async (req, res) => {
  try {
    const { classId, format = 'pdf' } = req. body;

    const entries = await TimetableEntry.findAll({
      where: { classId },
      include: [
        { model: Class },
        { model: User, attributes: ['firstName', 'lastName'] },
        { model: Room, attributes: ['code', 'name'] },
      ],
    });

    if (format === 'pdf') {
      const pdf = new PDFDocument();
      const fileName = `timetable_${classId}_${Date.now()}.pdf`;
      const filePath = path.join(__dirname, '../../exports', fileName);

      pdf.pipe(fs.createWriteStream(filePath));
      pdf.fontSize(16).text('Timetable Report', 100, 100);
      pdf.fontSize(12).text(`Class: ${entries[0]?.class?.name || 'N/A'}`);

      entries.forEach((entry, index) => {
        pdf.text(`\n${index + 1}. ${entry. ue. code} - ${entry.teacher.lastName}`);
        pdf.text(`   Room: ${entry.room.code}, Time: ${entry.timeSlot. startTime}`);
      });

      pdf.end();
      res.download(filePath);
    } else if (format === 'excel') {
      const workbook = new ExcelJS. Workbook();
      const worksheet = workbook.addWorksheet('Timetable');

      worksheet.columns = [
        { header: 'UE Code', key: 'ueCode', width: 15 },
        { header: 'Teacher', key: 'teacher', width: 20 },
        { header: 'Room', key: 'room', width:  15 },
        { header: 'Time', key: 'time', width: 15 },
        { header: 'Date', key: 'date', width: 15 },
      ];

      entries.forEach((entry) => {
        worksheet.addRow({
          ueCode: entry.ue. code,
          teacher: `${entry.teacher.firstName} ${entry.teacher.lastName}`,
          room: entry.room.code,
          time: entry.timeSlot.startTime,
          date: entry.date,
        });
      });

      const fileName = `timetable_${classId}_${Date.now()}.xlsx`;
      const filePath = path.join(__dirname, '../../exports', fileName);
      await workbook.xlsx.writeFile(filePath);
      res.download(filePath);
    }
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.generateConflictReport = async (req, res) => {
  try {
    const { Conflict } = require('../models');
    const conflicts = await Conflict.findAll({
      where: { isResolved: false },
    });

    const workbook = new ExcelJS. Workbook();
    const worksheet = workbook.addWorksheet('Conflicts');

    worksheet.columns = [
      { header: 'Conflict ID', key: 'id', width: 15 },
      { header: 'Type', key: 'type', width: 20 },
      { header: 'Severity', key: 'severity', width: 15 },
      { header: 'Description', key: 'description', width: 30 },
    ];

    conflicts.forEach((conflict) => {
      worksheet.addRow({
        id: conflict. id,
        type: conflict. type,
        severity: conflict. severity,
        description: conflict. description,
      });
    });

    const fileName = `conflicts_${Date.now()}.xlsx`;
    const filePath = path. join(__dirname, '../../exports', fileName);
    await workbook. xlsx.writeFile(filePath);
    res.download(filePath);
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.generateTeacherWorkloadReport = async (req, res) => {
  try {
    const { TimetableEntry, User } = require('../models');

    const teachers = await User.findAll({
      where: { role: 'teacher' },
    });

    const workbook = new ExcelJS. Workbook();
    const worksheet = workbook.addWorksheet('Teacher Workload');

    worksheet.columns = [
      { header:  'Teacher Name', key: 'name', width: 20 },
      { header: 'Total Hours', key: 'hours', width: 15 },
      { header: 'Total Sessions', key: 'sessions', width: 15 },
      { header: 'Avg Hours/Session', key: 'avg', width: 15 },
    ];

    for (const teacher of teachers) {
      const entries = await TimetableEntry.findAll({
        where: { teacherId: teacher.id },
        include: [{ model: require('./UE') }],
      });

      const totalHours = entries.reduce((sum, e) => sum + (e. ue?. hoursDuration || 0), 0);
      worksheet.addRow({
        name: `${teacher.firstName} ${teacher. lastName}`,
        hours: totalHours,
        sessions: entries.length,
        avg: totalHours / entries.length || 0,
      });
    }

    const fileName = `teacher_workload_${Date.now()}.xlsx`;
    const filePath = path.join(__dirname, '../../exports', fileName);
    await workbook.xlsx.writeFile(filePath);
    res.download(filePath);
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};