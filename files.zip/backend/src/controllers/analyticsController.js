const analyticsService = require('../services/analyticsService');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getClassStatistics = async (req, res) => {
  try {
    const { classId } = req. params;

    const stats = await analyticsService.getClassStatistics(classId);
    res.json(responseFormatter(true, 'Statistics retrieved', stats));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getTeacherWorkload = async (req, res) => {
  try {
    const { teacherId } = req. params;

    const workload = await analyticsService.getTeacherWorkload(teacherId);
    res.json(responseFormatter(true, 'Workload retrieved', workload));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getRoomUtilization = async (req, res) => {
  try {
    const utilization = await analyticsService.getRoomUtilization();
    res.json(responseFormatter(true, 'Room utilization retrieved', utilization));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getSystemMetrics = async (req, res) => {
  try {
    const { TimetableEntry, Class, User, Room } = require('../models');

    const totalClasses = await Class.count();
    const totalTeachers = await User.count({ where: { role: 'teacher' } });
    const totalStudents = await User.count({ where: { role: 'student' } });
    const totalRooms = await Room.count();
    const scheduledSessions = await TimetableEntry. count({ where: { status: 'scheduled' } });
    const confirmedSessions = await TimetableEntry.count({ where: { status: 'confirmed' } });

    res.json(responseFormatter(true, 'Metrics retrieved', {
      totalClasses,
      totalTeachers,
      totalStudents,
      totalRooms,
      scheduledSessions,
      confirmedSessions,
      utilizationRate: (confirmedSessions / (scheduledSessions + confirmedSessions) * 100).toFixed(2),
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};