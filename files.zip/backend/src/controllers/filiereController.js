const { Filiere, Department } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getAllFilieres = async (req, res) => {
  try {
    const { departmentId } = req.query;
    const where = departmentId ? { departmentId } : {};

    const filieres = await Filiere. findAll({
      where,
      include: [Department],
    });

    res.json(responseFormatter(true, 'Filieres retrieved', filieres));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.createFiliere = async (req, res) => {
  try {
    const { code, name, description, departmentId } = req.body;

    const filiere = await Filiere.create({
      code,
      name,
      description,
      departmentId,
    });

    res.status(201).json(responseFormatter(true, 'Filiere created', filiere));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. updateFiliere = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const filiere = await Filiere. findByPk(id);
    if (!filiere) {
      return res.status(404).json(responseFormatter(false, 'Filiere not found'));
    }

    await filiere.update(updates);
    res.json(responseFormatter(true, 'Filiere updated', filiere));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.deleteFiliere = async (req, res) => {
  try {
    const { id } = req. params;

    const filiere = await Filiere. findByPk(id);
    if (!filiere) {
      return res.status(404).json(responseFormatter(false, 'Filiere not found'));
    }

    await filiere. destroy();
    res.json(responseFormatter(true, 'Filiere deleted'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};