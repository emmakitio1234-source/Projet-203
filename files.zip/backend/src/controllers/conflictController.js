const { Conflict } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');
const conflictService = require('../services/conflictService');

exports.getAllConflicts = async (req, res) => {
  try {
    const { isResolved } = req.query;
    const where = isResolved !== undefined ? { isResolved:  isResolved === 'true' } : {};

    const conflicts = await Conflict.findAll({ where });
    res.json(responseFormatter(true, 'Conflicts retrieved', conflicts));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. detectConflicts = async (req, res) => {
  try {
    const conflicts = await conflictService.detectAllConflicts();
    res.json(responseFormatter(true, 'Conflicts detected', conflicts));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error. message));
  }
};

exports.resolveConflict = async (req, res) => {
  try {
    const { id } = req.params;

    const conflict = await Conflict. findByPk(id);
    if (!conflict) {
      return res.status(404).json(responseFormatter(false, 'Conflict not found'));
    }

    await conflict.update({ isResolved: true });
    res.json(responseFormatter(true, 'Conflict resolved', conflict));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.deleteConflict = async (req, res) => {
  try {
    const { id } = req.params;

    const conflict = await Conflict.findByPk(id);
    if (!conflict) {
      return res.status(404).json(responseFormatter(false, 'Conflict not found'));
    }

    await conflict.destroy();
    res.json(responseFormatter(true, 'Conflict deleted'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};