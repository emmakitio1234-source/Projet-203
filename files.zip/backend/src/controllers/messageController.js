const { Message, User } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getMessages = async (req, res) => {
  try {
    const { roomId } = req.params;
    const { limit = 50, offset = 0 } = req.query;

    const messages = await Message.findAndCountAll({
      where: { roomId },
      include: [{ model: User, attributes: ['id', 'firstName', 'lastName', 'avatar'] }],
      order: [['createdAt', 'DESC']],
      limit:  parseInt(limit),
      offset: parseInt(offset),
    });

    res.json(responseFormatter(true, 'Messages retrieved', {
      messages:  messages.rows. reverse(),
      total: messages.count,
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. sendMessage = async (req, res) => {
  try {
    const { roomId, content } = req.body;
    const userId = req.user.id;

    const message = await Message.create({
      senderId: userId,
      roomId,
      content,
    });

    const populatedMessage = await Message.findByPk(message.id, {
      include: [{ model: User, attributes: ['id', 'firstName', 'lastName'] }],
    });

    res.status(201).json(responseFormatter(true, 'Message sent', populatedMessage));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.deleteMessage = async (req, res) => {
  try {
    const { id } = req.params;

    const message = await Message.findByPk(id);
    if (!message) {
      return res.status(404).json(responseFormatter(false, 'Message not found'));
    }

    if (message.senderId !== req. user.id && req.user.role !== 'admin') {
      return res. status(403).json(responseFormatter(false, 'Unauthorized'));
    }

    await message. destroy();
    res.json(responseFormatter(true, 'Message deleted'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};