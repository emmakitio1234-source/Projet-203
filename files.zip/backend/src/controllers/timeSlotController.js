const { TimeSlot } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getAllTimeSlots = async (req, res) => {
  try {
    const { dayOfWeek } = req.query;
    const where = dayOfWeek ? { dayOfWeek } : {};

    const slots = await TimeSlot.findAll({
      where,
      order: [['startTime', 'ASC']],
    });

    res.json(responseFormatter(true, 'Time slots retrieved', slots));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.createTimeSlot = async (req, res) => {
  try {
    const { startTime, endTime, dayOfWeek } = req.body;

    const slot = await TimeSlot.create({
      startTime,
      endTime,
      dayOfWeek,
    });

    res.status(201).json(responseFormatter(true, 'Time slot created', slot));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.updateTimeSlot = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const slot = await TimeSlot.findByPk(id);
    if (!slot) {
      return res.status(404).json(responseFormatter(false, 'Time slot not found'));
    }

    await slot.update(updates);
    res.json(responseFormatter(true, 'Time slot updated', slot));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.deleteTimeSlot = async (req, res) => {
  try {
    const { id } = req.params;

    const slot = await TimeSlot.findByPk(id);
    if (!slot) {
      return res.status(404).json(responseFormatter(false, 'Time slot not found'));
    }

    await slot. destroy();
    res.json(responseFormatter(false, 'Time slot deleted'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error. message));
  }
};