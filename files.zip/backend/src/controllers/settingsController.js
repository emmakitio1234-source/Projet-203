const { SystemSettings } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getSettings = async (req, res) => {
  try {
    const settings = await SystemSettings.findAll();
    res.json(responseFormatter(true, 'Settings retrieved', settings));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. updateSettings = async (req, res) => {
  try {
    const { key, value } = req.body;

    let setting = await SystemSettings.findOne({ where: { key } });
    if (!setting) {
      setting = await SystemSettings.create({ key, value });
    } else {
      await setting.update({ value });
    }

    res.json(responseFormatter(true, 'Setting updated', setting));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getSystemHealth = async (req, res) => {
  try {
    const { sequelize } = require('../models');
    await sequelize.authenticate();

    res.json(responseFormatter(true, 'System is healthy', {
      database: 'connected',
      timestamp: new Date(),
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, 'System error', { database: 'disconnected' }));
  }
};