const { UE, Filiere, TimetableEntry } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');
const logger = require('../utils/logger');
const { Op } = require('sequelize');

exports.getAllUEs = async (req, res) => {
  try {
    const { filiereId, search, page = 1, limit = 10 } = req.query;
    const where = {};

    if (filiereId) where.filiereId = filiereId;

    if (search) {
      where[Op.or] = [
        { code: { [Op.like]: `%${search}%` } },
        { name: { [Op.like]: `%${search}%` } },
      ];
    }

    const offset = (page - 1) * limit;

    const ues = await UE.findAndCountAll({
      where,
      include: [Filiere],
      offset,
      limit: parseInt(limit),
      order: [['code', 'ASC']],
    });

    res.json(responseFormatter(true, 'UEs retrieved', {
      data: ues.rows,
      total: ues.count,
      page: parseInt(page),
      pages: Math.ceil(ues.count / limit),
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getUEById = async (req, res) => {
  try {
    const { id } = req.params;

    const ue = await UE.findByPk(id, {
      include: [Filiere],
    });

    if (!ue) {
      return res.status(404).json(responseFormatter(false, 'UE not found'));
    }

    res.json(responseFormatter(true, 'UE retrieved', ue));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. createUE = async (req, res) => {
  try {
    const { code, name, credits, hoursDuration, description, filiereId } = req. body;

    const ue = await UE.create({
      code,
      name,
      credits,
      hoursDuration,
      description,
      filiereId,
    });

    logger.info({
      action: 'createUE',
      ueId: ue.id,
      code,
    });

    res.status(201).json(responseFormatter(true, 'UE created', ue));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.updateUE = async (req, res) => {
  try {
    const { id } = req.params;
    const { code, name, credits, hoursDuration, description } = req.body;

    const ue = await UE.findByPk(id);
    if (!ue) {
      return res.status(404).json(responseFormatter(false, 'UE not found'));
    }

    await ue.update({
      code: code || ue.code,
      name: name || ue.name,
      credits: credits !== undefined ? credits : ue.credits,
      hoursDuration: hoursDuration !== undefined ? hoursDuration : ue.hoursDuration,
      description: description || ue.description,
    });

    logger.info({
      action: 'updateUE',
      ueId: id,
    });

    res.json(responseFormatter(true, 'UE updated', ue));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports. deleteUE = async (req, res) => {
  try {
    const { id } = req.params;

    const ue = await UE.findByPk(id);
    if (!ue) {
      return res.status(404).json(responseFormatter(false, 'UE not found'));
    }

    // Check if UE has timetable entries
    const entryCount = await TimetableEntry.count({ where: { ueId: id } });
    if (entryCount > 0) {
      return res.status(400).json(responseFormatter(false, 'Cannot delete UE with existing timetable entries'));
    }

    await ue.destroy();

    logger.info({
      action: 'deleteUE',
      ueId: id,
    });

    res.json(responseFormatter(true, 'UE deleted'));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};