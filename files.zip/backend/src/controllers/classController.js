const classService = require('../services/classService');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getAllClasses = async (req, res) => {
  try {
    const { filiereId, academicYearId, isActive, page, limit } = req.query;

    const result = await classService.getAllClasses({
      filiereId,
      academicYearId,
      isActive:  isActive === 'true',
      page,
      limit,
    });

    res.json(responseFormatter(true, 'Classes retrieved', result));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. getClassById = async (req, res) => {
  try {
    const { id } = req. params;

    const classData = await classService.getClassById(id);
    res.json(responseFormatter(true, 'Class retrieved', classData));
  } catch (error) {
    res.status(404).json(responseFormatter(false, error.message));
  }
};

exports.createClass = async (req, res) => {
  try {
    const classData = await classService.createClass(req.body);
    res.status(201).json(responseFormatter(true, 'Class created', classData));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.updateClass = async (req, res) => {
  try {
    const { id } = req.params;

    const classData = await classService.updateClass(id, req. body);
    res.json(responseFormatter(true, 'Class updated', classData));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.deleteClass = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await classService.deleteClass(id);
    res.json(responseFormatter(true, result.message));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getClassTimetable = async (req, res) => {
  try {
    const { id } = req.params;
    const { semesterId, startDate, endDate } = req.query;

    const timetable = await classService.getClassTimetable(id, semesterId, {
      startDate,
      endDate,
    });

    res.json(responseFormatter(true, 'Timetable retrieved', timetable));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getClassStatistics = async (req, res) => {
  try {
    const { id } = req.params;

    const stats = await classService.getClassStatistics(id);
    res.json(responseFormatter(true, 'Statistics retrieved', stats));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.updateClassSize = async (req, res) => {
  try {
    const { id } = req.params;
    const { newSize } = req.body;

    const classData = await classService.updateClassSize(id, newSize);
    res.json(responseFormatter(true, 'Class size updated', classData));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getClassConflicts = async (req, res) => {
  try {
    const { id } = req. params;

    const conflicts = await classService. getClassConflicts(id);
    res.json(responseFormatter(true, 'Conflicts retrieved', conflicts));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getClassUEs = async (req, res) => {
  try {
    const { id } = req.params;

    const ues = await classService.getClassUEs(id);
    res.json(responseFormatter(true, 'UEs retrieved', ues));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports. getClassTeachers = async (req, res) => {
  try {
    const { id } = req. params;

    const teachers = await classService.getClassTeachers(id);
    res.json(responseFormatter(true, 'Teachers retrieved', teachers));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports. getClassScheduleOverview = async (req, res) => {
  try {
    const { id } = req.params;

    const overview = await classService. getClassScheduleOverview(id);
    res.json(responseFormatter(true, 'Overview retrieved', overview));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.checkCapacityIssues = async (req, res) => {
  try {
    const { id } = req.params;

    const issues = await classService. checkCapacityIssues(id);
    res.json(responseFormatter(true, 'Capacity check completed', { issues, hasIssues: issues.length > 0 }));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};