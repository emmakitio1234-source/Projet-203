const { Notification } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');
const notificationService = require('../services/notificationService');

exports.getUserNotifications = async (req, res) => {
  try {
    const { userId } = req. params;
    const { limit = 20 } = req.query;

    const notifications = await notificationService.getUserNotifications(userId, limit);
    res.json(responseFormatter(true, 'Notifications retrieved', notifications));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.markAsRead = async (req, res) => {
  try {
    const { id } = req. params;

    const notification = await notificationService.markAsRead(id);
    res.json(responseFormatter(true, 'Notification marked as read', notification));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.markAllAsRead = async (req, res) => {
  try {
    const { userId } = req.params;

    await notificationService.markAllAsRead(userId);
    res.json(responseFormatter(true, 'All notifications marked as read'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.deleteNotification = async (req, res) => {
  try {
    const { id } = req.params;

    const notification = await Notification.findByPk(id);
    if (!notification) {
      return res.status(404).json(responseFormatter(false, 'Notification not found'));
    }

    await notification.destroy();
    res.json(responseFormatter(true, 'Notification deleted'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};