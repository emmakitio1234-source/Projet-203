const { Semester, AcademicYear } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getAllSemesters = async (req, res) => {
  try {
    const { academicYearId } = req. query;
    const where = academicYearId ? { academicYearId } : {};

    const semesters = await Semester. findAll({
      where,
      include: [AcademicYear],
      order: [['number', 'ASC']],
    });

    res.json(responseFormatter(true, 'Semesters retrieved', semesters));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports. createSemester = async (req, res) => {
  try {
    const { number, startDate, endDate, academicYearId } = req.body;

    const semester = await Semester.create({
      number,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      academicYearId,
    });

    res.status(201).json(responseFormatter(true, 'Semester created', semester));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.updateSemester = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const semester = await Semester.findByPk(id);
    if (!semester) {
      return res.status(404).json(responseFormatter(false, 'Semester not found'));
    }

    await semester.update(updates);
    res.json(responseFormatter(true, 'Semester updated', semester));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.deleteSemester = async (req, res) => {
  try {
    const { id } = req.params;

    const semester = await Semester.findByPk(id);
    if (!semester) {
      return res.status(404).json(responseFormatter(false, 'Semester not found'));
    }

    await semester.destroy();
    res.json(responseFormatter(true, 'Semester deleted'));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};