const { TimetableEntry, Class, User, Room, Conflict } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getDashboardStats = async (req, res) => {
  try {
    const totalClasses = await Class.count();
    const totalTeachers = await User.count({ where: { role: 'teacher' } });
    const totalRooms = await Room.count();
    const totalScheduledHours = await TimetableEntry. count({ where: { status: 'scheduled' } });
    const unresolvedConflicts = await Conflict.count({ where: { isResolved: false } });

    res.json(responseFormatter(true, 'Dashboard stats retrieved', {
      totalClasses,
      totalTeachers,
      totalRooms,
      totalScheduledHours,
      unresolvedConflicts,
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getActivityFeed = async (req, res) => {
  try {
    const activities = await TimetableEntry.findAll({
      order: [['createdAt', 'DESC']],
      limit: 10,
      include: [{ model: Class }, { model: User, attributes: ['firstName', 'lastName'] }],
    });

    res.json(responseFormatter(true, 'Activity feed retrieved', activities));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};