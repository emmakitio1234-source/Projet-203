const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User } = require('../models');
const jwtConfig = require('../config/jwt');
const { responseFormatter } = require('../utils/responseFormatter');

exports.register = async (req, res) => {
  try {
    const { firstName, lastName, email, password, role } = req.body;

    const userExists = await User.findOne({ where: { email } });
    if (userExists) {
      return res.status(400).json(responseFormatter(false, 'User already exists'));
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      role:  role || 'student',
    });

    const token = jwt.sign({ id: user.id, role: user.role }, jwtConfig.secret, {
      expiresIn: jwtConfig.expiresIn,
    });

    res.status(201).json(responseFormatter(true, 'User registered successfully', {
      user:  { id: user.id, email: user.email, role: user.role },
      token,
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(401).json(responseFormatter(false, 'Invalid credentials'));
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json(responseFormatter(false, 'Invalid credentials'));
    }

    const token = jwt.sign({ id: user.id, role: user.role }, jwtConfig.secret, {
      expiresIn: jwtConfig.expiresIn,
    });

    await user.update({ lastLogin: new Date() });

    res.json(responseFormatter(true, 'Login successful', {
      user:  { id: user.id, email: user.email, role: user.role },
      token,
    }));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.logout = (req, res) => {
  res.json(responseFormatter(true, 'Logout successful'));
};