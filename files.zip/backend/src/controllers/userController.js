const userService = require('../services/userService');
const { responseFormatter } = require('../utils/responseFormatter');
const validators = require('../utils/validators');
const validateRequest = require('../middleware/validateRequest');

exports.getAllUsers = async (req, res) => {
  try {
    const { role, isActive, search, page, limit } = req.query;

    const result = await userService.getAllUsers({
      role,
      isActive:  isActive === 'true',
      search,
      page,
      limit,
    });

    res.json(responseFormatter(true, 'Users retrieved', result));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getUserById = async (req, res) => {
  try {
    const { id } = req.params;

    const user = await userService.getUserById(id);
    res.json(responseFormatter(true, 'User retrieved', user));
  } catch (error) {
    res.status(404).json(responseFormatter(false, error.message));
  }
};

exports.createUser = async (req, res) => {
  try {
    const user = await userService.createUser(req.body);
    res.status(201).json(responseFormatter(true, 'User created', user));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { id } = req.params;

    const user = await userService. updateUser(id, req.body);
    res.json(responseFormatter(true, 'User updated', user));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    await userService.deleteUser(id);
    res.json(responseFormatter(true, 'User deleted'));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.changePassword = async (req, res) => {
  try {
    const { id } = req.params;
    const { oldPassword, newPassword } = req. body;

    const result = await userService.changePassword(id, oldPassword, newPassword);
    res.json(responseFormatter(true, result.message));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getUserStatistics = async (req, res) => {
  try {
    const { id } = req.params;

    const stats = await userService.getUserStatistics(id);
    res.json(responseFormatter(true, 'User statistics', stats));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.deactivateUser = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await userService.deactivateUser(id);
    res.json(responseFormatter(true, result.message));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.activateUser = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await userService.activateUser(id);
    res.json(responseFormatter(true, result.message));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.bulkImportUsers = async (req, res) => {
  try {
    const { users } = req.body;

    if (!Array.isArray(users) || users.length === 0) {
      return res.status(400).json(responseFormatter(false, 'Users array is required'));
    }

    const result = await userService.bulkImportUsers(users);
    res.json(responseFormatter(true, 'Users imported', result));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};