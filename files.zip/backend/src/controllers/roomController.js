const roomService = require('../services/roomService');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getAllRooms = async (req, res) => {
  try {
    const { building, capacity, roomType, isAvailable, page, limit } = req.query;

    const result = await roomService.getAllRooms({
      building,
      capacity,
      roomType,
      isAvailable:  isAvailable === 'true',
      page,
      limit,
    });

    res.json(responseFormatter(true, 'Rooms retrieved', result));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getRoomById = async (req, res) => {
  try {
    const { id } = req.params;

    const room = await roomService.getRoomById(id);
    res.json(responseFormatter(true, 'Room retrieved', room));
  } catch (error) {
    res.status(404).json(responseFormatter(false, error.message));
  }
};

exports. createRoom = async (req, res) => {
  try {
    const room = await roomService. createRoom(req.body);
    res.status(201).json(responseFormatter(true, 'Room created', room));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports. updateRoom = async (req, res) => {
  try {
    const { id } = req. params;

    const room = await roomService. updateRoom(id, req.body);
    res.json(responseFormatter(true, 'Room updated', room));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.deleteRoom = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await roomService.deleteRoom(id);
    res.json(responseFormatter(true, result. message));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.checkRoomAvailability = async (req, res) => {
  try {
    const { id } = req.params;
    const { timeSlotId, date } = req.query;

    const isAvailable = await roomService.checkRoomAvailability(id, timeSlotId, date);
    res.json(responseFormatter(true, 'Availability checked', { isAvailable }));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports. getRoomSchedule = async (req, res) => {
  try {
    const { id } = req.params;
    const { startDate, endDate } = req.query;

    const schedule = await roomService.getRoomSchedule(id, startDate, endDate);
    res.json(responseFormatter(true, 'Schedule retrieved', schedule));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getRoomUtilization = async (req, res) => {
  try {
    const { id } = req.params;

    const utilization = await roomService.getRoomUtilization(id);
    res.json(responseFormatter(true, 'Utilization retrieved', utilization));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getAvailableRooms = async (req, res) => {
  try {
    const { timeSlotId, date, minCapacity } = req.query;

    const rooms = await roomService.getAvailableRooms(timeSlotId, date, minCapacity);
    res.json(responseFormatter(true, 'Available rooms retrieved', rooms));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getRoomStatistics = async (req, res) => {
  try {
    const stats = await roomService.getRoomStatistics();
    res.json(responseFormatter(true, 'Statistics retrieved', stats));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};