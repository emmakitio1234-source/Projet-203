const { TeacherPreference, User } = require('../models');
const { responseFormatter } = require('../utils/responseFormatter');

exports.submitPreference = async (req, res) => {
  try {
    const { teacherId, semesterId, preferredTimeSlots, preferredRooms } = req.body;

    const preference = await TeacherPreference.create({
      teacherId,
      semesterId,
      preferredTimeSlots,
      preferredRooms,
      status: 'pending',
      submittedAt: new Date(),
    });

    res.status(201).json(responseFormatter(true, 'Preference submitted', preference));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.getPreference = async (req, res) => {
  try {
    const { teacherId, semesterId } = req.query;

    const preference = await TeacherPreference. findOne({
      where: { teacherId, semesterId },
      include: [{ model: User, as: 'teacher' }],
    });

    if (!preference) {
      return res.status(404).json(responseFormatter(false, 'Preference not found'));
    }

    res.json(responseFormatter(true, 'Preference retrieved', preference));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.approvePreference = async (req, res) => {
  try {
    const { id } = req.params;

    const preference = await TeacherPreference.findByPk(id);
    if (!preference) {
      return res.status(404).json(responseFormatter(false, 'Preference not found'));
    }

    await preference.update({ status: 'approved' });
    res.json(responseFormatter(true, 'Preference approved', preference));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.rejectPreference = async (req, res) => {
  try {
    const { id } = req.params;

    const preference = await TeacherPreference.findByPk(id);
    if (!preference) {
      return res. status(404).json(responseFormatter(false, 'Preference not found'));
    }

    await preference.update({ status: 'rejected' });
    res.json(responseFormatter(true, 'Preference rejected', preference));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};