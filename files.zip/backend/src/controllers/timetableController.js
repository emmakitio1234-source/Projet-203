const timetableService = require('../services/timetableService');
const { responseFormatter } = require('../utils/responseFormatter');

exports.getTimetableEntries = async (req, res) => {
  try {
    const { classId, semesterId, teacherId, roomId, startDate, endDate, status, page, limit } = req. query;

    const result = await timetableService.getTimetableEntries({
      classId,
      semesterId,
      teacherId,
      roomId,
      startDate,
      endDate,
      status,
      page,
      limit,
    });

    res.json(responseFormatter(true, 'Timetable entries retrieved', result));
  } catch (error) {
    res.status(500).json(responseFormatter(false, error.message));
  }
};

exports.createTimetableEntry = async (req, res) => {
  try {
    const entry = await timetableService.createTimetableEntry(req.body);
    res.status(201).json(responseFormatter(true, 'Timetable entry created', entry));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.updateTimetableEntry = async (req, res) => {
  try {
    const { id } = req.params;

    const entry = await timetableService.updateTimetableEntry(id, req.body);
    res.json(responseFormatter(true, 'Timetable entry updated', entry));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.deleteTimetableEntry = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await timetableService. deleteTimetableEntry(id);
    res.json(responseFormatter(true, result.message));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.confirmTimetableEntry = async (req, res) => {
  try {
    const { id } = req.params;

    const entry = await timetableService.confirmTimetableEntry(id);
    res.json(responseFormatter(true, 'Entry confirmed', entry));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.cancelTimetableEntry = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    const entry = await timetableService.cancelTimetableEntry(id, reason);
    res.json(responseFormatter(true, 'Entry cancelled', entry));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.detectConflicts = async (req, res) => {
  try {
    const { classId, teacherId, roomId, timeSlotId, date } = req.body;

    const conflicts = await timetableService.detectConflicts(classId, teacherId, roomId, timeSlotId, date);
    res.json(responseFormatter(true, 'Conflict detection completed', { conflicts, hasConflicts: conflicts.length > 0 }));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};

exports.getTimetableOverview = async (req, res) => {
  try {
    const { semesterId } = req.query;

    if (! semesterId) {
      return res.status(400).json(responseFormatter(false, 'Semester ID is required'));
    }

    const overview = await timetableService.getTimetableOverview(semesterId);
    res.json(responseFormatter(true, 'Overview retrieved', overview));
  } catch (error) {
    res.status(400).json(responseFormatter(false, error.message));
  }
};