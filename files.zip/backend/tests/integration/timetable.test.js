const request = require('supertest');
const app = require('../../src/server');
const { User, Class, TimetableEntry } = require('../../src/models');

describe('Timetable API Integration Tests', () => {
  let adminToken;
  let teacherToken;
  let classId;

  beforeAll(async () => {
    // Setup test data
    const admin = await User.create({
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@test.com',
      password: 'hashedPassword',
      role: 'admin',
    });

    const teacher = await User.create({
      firstName: 'Teacher',
      lastName: 'User',
      email: 'teacher@test.com',
      password: 'hashedPassword',
      role: 'teacher',
    });

    // Generate tokens (mock JWT)
    adminToken = 'mock-admin-token';
    teacherToken = 'mock-teacher-token';
  });

  describe('POST /api/timetable', () => {
    it('should create timetable entry', async () => {
      const response = await request(app)
        .post('/api/timetable')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          classId:  'class-1',
          ueId: 'ue-1',
          teacherId: 'teacher-1',
          roomId: 'room-1',
          timeSlotId: 'slot-1',
          date: '2026-01-20',
          semesterId: 'sem-1',
        });

      expect(response.status).toBe(201);
      expect(response.body.success).toBe(true);
    });

    it('should not allow non-admin to create', async () => {
      const response = await request(app)
        .post('/api/timetable')
        .set('Authorization', `Bearer ${teacherToken}`)
        .send({});

      expect(response.status).toBe(403);
    });
  });

  describe('GET /api/timetable', () => {
    it('should retrieve timetable', async () => {
      const response = await request(app)
        .get('/api/timetable? classId=class-1&semesterId=sem-1')
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response. body.success).toBe(true);
      expect(Array.isArray(response.body. data)).toBe(true);
    });
  });

  describe('DELETE /api/timetable/: id', () => {
    it('should delete timetable entry', async () => {
      // Create entry first
      const entry = await TimetableEntry.create({
        classId: 'class-1',
        ueId: 'ue-1',
        teacherId: 'teacher-1',
        roomId: 'room-1',
        timeSlotId: 'slot-1',
        date: '2026-01-20',
        semesterId: 'sem-1',
      });

      const response = await request(app)
        .delete(`/api/timetable/${entry.id}`)
        .set('Authorization', `Bearer ${adminToken}`);

      expect(response.status).toBe(200);
      expect(response.body.success).toBe(true);
    });
  });
});