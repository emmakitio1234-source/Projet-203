const userService = require('../../src/services/userService');
const { User } = require('../../src/models');

jest.mock('../../src/models');
jest.mock('../../src/services/cacheService');

describe('UserService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('createUser', () => {
    it('should create a new user', async () => {
      const userData = {
        firstName: 'John',
        lastName: 'Doe',
        email: 'john@example.com',
        password: 'Password123!',
        role: 'student',
      };

      User.create. mockResolvedValue({
        id: '123',
        ... userData,
        password: 'hashed_password',
      });

      const result = await userService.createUser(userData);

      expect(result).toHaveProperty('id');
      expect(result. email).toBe(userData.email);
      expect(User.create).toHaveBeenCalled();
    });

    it('should throw error if user already exists', async () => {
      User.findOne.mockResolvedValue({ id: '123' });

      await expect(
        userService.createUser({
          firstName: 'John',
          lastName: 'Doe',
          email: 'john@example.com',
          password: 'Password123!',
        })
      ).rejects.toThrow('User with this email already exists');
    });
  });

  describe('getUserById', () => {
    it('should return user by id', async () => {
      const mockUser = {
        id: '123',
        firstName: 'John',
        lastName: 'Doe',
        email: 'john@example.com',
      };

      User.findByPk.mockResolvedValue(mockUser);

      const result = await userService.getUserById('123');

      expect(result).toEqual(mockUser);
      expect(User.findByPk).toHaveBeenCalledWith('123');
    });

    it('should throw error if user not found', async () => {
      User.findByPk. mockResolvedValue(null);

      await expect(userService.getUserById('invalid-id')).rejects.toThrow('User not found');
    });
  });

  describe('updateUser', () => {
    it('should update user', async () => {
      const mockUser = {
        id: '123',
        firstName: 'John',
        lastName: 'Doe',
        update: jest.fn().mockResolvedValue(true),
      };

      User. findByPk.mockResolvedValue(mockUser);

      await userService.updateUser('123', { firstName: 'Jane' });

      expect(mockUser.update).toHaveBeenCalledWith(
        expect.objectContaining({ firstName: 'Jane' })
      );
    });
  });

  describe('deleteUser', () => {
    it('should delete user', async () => {
      const mockUser = {
        id: '123',
        destroy: jest.fn().mockResolvedValue(true),
      };

      User.findByPk.mockResolvedValue(mockUser);

      const result = await userService.deleteUser('123');

      expect(result).toHaveProperty('message');
      expect(mockUser.destroy).toHaveBeenCalled();
    });
  });
});