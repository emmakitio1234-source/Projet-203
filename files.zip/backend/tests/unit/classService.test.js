const classService = require('../../src/services/classService');
const { Class, Filiere, AcademicYear } = require('../../src/models');

jest.mock('../../src/models');
jest.mock('../../src/services/cacheService');

describe('ClassService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('createClass', () => {
    it('should create a new class', async () => {
      const classData = {
        code: 'ICT-L2-A',
        name: 'ICT Level 2 - Section A',
        filiereId: 'filiere-123',
        academicYearId: 'year-123',
        studentCount: 45,
      };

      Filiere.findByPk.mockResolvedValue({ id: 'filiere-123' });
      AcademicYear.findByPk.mockResolvedValue({ id: 'year-123' });
      Class.findOne.mockResolvedValue(null);
      Class.create.mockResolvedValue({
        id: 'class-123',
        ... classData,
      });

      const result = await classService.createClass(classData);

      expect(result).toHaveProperty('id');
      expect(result.code).toBe(classData.code);
      expect(Class.create).toHaveBeenCalled();
    });

    it('should throw error if filiere not found', async () => {
      Filiere.findByPk.mockResolvedValue(null);

      await expect(
        classService.createClass({
          code: 'ICT-L2-A',
          name: 'ICT Level 2 - Section A',
          filiereId: 'invalid',
          academicYearId:  'year-123',
          studentCount: 45,
        })
      ).rejects.toThrow('Filiere not found');
    });
  });

  describe('getClassStatistics', () => {
    it('should return class statistics', async () => {
      const mockClass = {
        id: 'class-123',
        code: 'ICT-L2-A',
        name: 'ICT Level 2 - Section A',
        studentCount: 45,
      };

      Class.findByPk.mockResolvedValue(mockClass);

      const result = await classService.getClassStatistics('class-123');

      expect(result).toHaveProperty('classId');
      expect(result).toHaveProperty('studentCount', 45);
      expect(result).toHaveProperty('totalSessions');
    });
  });
});