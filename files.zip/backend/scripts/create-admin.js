const { User } = require('../src/models');
const bcrypt = require('bcryptjs');

const createAdmin = async (email, firstName, lastName, password) => {
  try {
    // Check if admin already exists
    const existingAdmin = await User.findOne({ where: { email } });
    if (existingAdmin) {
      console.log('❌ Admin user already exists');
      process.exit(1);
    }

    // Hash password
    const hashedPassword = await bcrypt. hash(password, 10);

    // Create admin
    const admin = await User. create({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      role: 'admin',
      isActive: true,
    });

    console.log('✅ Admin user created successfully! ');
    console.log(`Email: ${admin.email}`);
    console.log(`Name: ${admin.firstName} ${admin.lastName}`);
    console.log(`ID: ${admin.id}`);

    process.exit(0);
  } catch (error) {
    console.error('❌ Error creating admin:', error. message);
    process.exit(1);
  }
};

// Get arguments from command line
const args = process.argv.slice(2);
if (args.length < 4) {
  console.log('Usage: node create-admin. js <email> <firstName> <lastName> <password>');
  process.exit(1);
}

const [email, firstName, lastName, password] = args;
createAdmin(email, firstName, lastName, password);