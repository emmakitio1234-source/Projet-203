-- Insert sample academic year
INSERT INTO academic_years (id, year, startDate, endDate, isActive) VALUES
(UUID(), '2025-2026', '2025-09-01', '2026-08-31', TRUE);

-- Insert departments
INSERT INTO departments (id, code, name) VALUES
(UUID(), 'DEPT-ICT', 'Department of ICT'),
(UUID(), 'DEPT-BUSINESS', 'Department of Business');

-- Insert sample users
INSERT INTO users (id, firstName, lastName, email, password, role) VALUES
(UUID(), 'Admin', 'User', 'admin@example.com', '$2a$10$... ', 'admin'),
(UUID(), 'John', 'Smith', 'john.smith@example.com', '$2a$10$...', 'teacher'),
(UUID(), 'Jane', 'Doe', 'jane. doe@example.com', '$2a$10$...', 'teacher');

-- Insert rooms
INSERT INTO rooms (id, code, name, capacity, building, floor, roomType, isAvailable) VALUES
(UUID(), 'A101', 'Classroom A101', 30, 'Building A', 1, 'classroom', TRUE),
(UUID(), 'A102', 'Classroom A102', 40, 'Building A', 1, 'classroom', TRUE),
(UUID(), 'B201', 'Lab B201', 25, 'Building B', 2, 'lab', TRUE);

-- Insert time slots
INSERT INTO time_slots (id, startTime, endTime, dayOfWeek, isAvailable) VALUES
(UUID(), '08:00', '10:00', 'Monday', TRUE),
(UUID(), '10:00', '12:00', 'Monday', TRUE),
(UUID(), '14:00', '16:00', 'Wednesday', TRUE),
(UUID(), '16:00', '18:00', 'Friday', TRUE);