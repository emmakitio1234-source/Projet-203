-- Sample data for ICT-L2 class

-- Create admin user
INSERT INTO users (id, firstName, lastName, email, password, role)
VALUES (
  UUID(),
  'Admin',
  'User',
  'admin@ict.edu',
  '$2a$10$encrypted_password_here',
  'admin'
);

-- Create teachers
INSERT INTO users (id, firstName, lastName, email, password, role)
VALUES
  (UUID(), 'Jean', 'Dupont', 'jean.dupont@ict. edu', '$2a$10$encrypted', 'teacher'),
  (UUID(), 'Marie', 'Martin', 'marie.martin@ict.edu', '$2a$10$encrypted', 'teacher');

-- Create ICT-L2 class
INSERT INTO classes (id, code, name, filiereId, academicYearId, studentCount)
VALUES (
  UUID(),
  'ICT-L2',
  'Information and Communication Technologies - Level 2',
  (SELECT id FROM filieres WHERE code='L2'),
  (SELECT id FROM academic_years WHERE year='2025/2026'),
  45
);

-- Create UEs for ICT-L2
INSERT INTO ues (id, code, name, credits, hoursDuration, filiereId)
VALUES
  (UUID(), 'ICT-203', 'Advanced Web Development', 3, 24, (SELECT id FROM filieres WHERE code='L2')),
  (UUID(), 'ICT-204', 'Database Design', 3, 20, (SELECT id FROM filieres WHERE code='L2'));