-- Advanced Database Schema with Views and Triggers

-- View: Get class timetable with all details
CREATE VIEW class_timetable_view AS
SELECT
  te.id,
  c.code as class_code,
  c. name as class_name,
  u.code as ue_code,
  u.name as ue_name,
  CONCAT(usr.firstName, ' ', usr.lastName) as teacher_name,
  r.code as room_code,
  r.name as room_name,
  ts.dayOfWeek,
  ts. startTime,
  ts.endTime,
  te.date,
  te.status,
  te.createdAt,
  te.updatedAt
FROM timetable_entries te
JOIN classes c ON te.classId = c.id
JOIN ues u ON te. ueId = u.id
JOIN users usr ON te.teacherId = usr.id
JOIN rooms r ON te.roomId = r.id
JOIN time_slots ts ON te.timeSlotId = ts.id;

-- View: Get teacher schedule with classes
CREATE VIEW teacher_schedule_view AS
SELECT
  usr.id as teacher_id,
  CONCAT(usr.firstName, ' ', usr.lastName) as teacher_name,
  c.code as class_code,
  u.code as ue_code,
  r.code as room_code,
  ts.dayOfWeek,
  ts.startTime,
  ts.endTime,
  te. date,
  te.status
FROM timetable_entries te
JOIN users usr ON te.teacherId = usr.id
JOIN classes c ON te.classId = c.id
JOIN ues u ON te. ueId = u.id
JOIN rooms r ON te.roomId = r.id
JOIN time_slots ts ON te.timeSlotId = ts.id
WHERE usr.role = 'teacher';

-- View: Room utilization rates
CREATE VIEW room_utilization_view AS
SELECT
  r. id,
  r.code,
  r.name,
  r.capacity,
  COUNT(te.id) as booked_sessions,
  ROUND((COUNT(te.id) / (5 * 8)) * 100, 2) as utilization_rate
FROM rooms r
LEFT JOIN timetable_entries te ON r.id = te.roomId
GROUP BY r. id, r.code, r. name, r.capacity;

-- Trigger: Update timetable_entries updatedAt timestamp
DELIMITER $$
CREATE TRIGGER update_timetable_entries_timestamp
BEFORE UPDATE ON timetable_entries
FOR EACH ROW
BEGIN
  SET NEW.updatedAt = CURRENT_TIMESTAMP;
END$$
DELIMITER ;

-- Trigger:  Prevent booking room beyond capacity
DELIMITER $$
CREATE TRIGGER check_room_capacity
BEFORE INSERT ON timetable_entries
FOR EACH ROW
BEGIN
  DECLARE room_cap INT;
  DECLARE class_size INT;

  SELECT capacity INTO room_cap FROM rooms WHERE id = NEW.roomId;
  SELECT studentCount INTO class_size FROM classes WHERE id = NEW.classId;

  IF class_size > room_cap THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Class size exceeds room capacity';
  END IF;
END$$
DELIMITER ;

-- Trigger: Create notification on timetable entry creation
DELIMITER $$
CREATE TRIGGER notify_on_timetable_creation
AFTER INSERT ON timetable_entries
FOR EACH ROW
BEGIN
  INSERT INTO notifications (id, userId, type, title, message, relatedEntityId, relatedEntityType, createdAt, updatedAt)
  VALUES (UUID(), NEW.teacherId, 'info', 'New Class Assigned', 'You have been assigned a new class', NEW.id, 'TimetableEntry', NOW(), NOW());
END$$
DELIMITER ;

-- Trigger: Log conflicts when detected
DELIMITER $$
CREATE TRIGGER log_conflict_creation
AFTER INSERT ON conflicts
FOR EACH ROW
BEGIN
  INSERT INTO notifications (id, userId, type, title, message, relatedEntityId, relatedEntityType, createdAt, updatedAt)
  SELECT UUID(), u.id, 'warning', 'Schedule Conflict Detected', CONCAT('A ', NEW.type, ' conflict has been detected'), NEW.id, 'Conflict', NOW(), NOW()
  FROM users u
  WHERE u. role = 'admin';
END$$
DELIMITER ;

-- Procedure: Generate weekly report
DELIMITER $$
CREATE PROCEDURE generate_weekly_report(IN week_date DATE)
BEGIN
  SELECT
    c.code as class_code,
    COUNT(te.id) as sessions,
    SUM(u.hoursDuration) as total_hours,
    COUNT(DISTINCT r.id) as rooms_used
  FROM timetable_entries te
  JOIN classes c ON te.classId = c.id
  JOIN ues u ON te.ueId = u.id
  JOIN rooms r ON te.roomId = r. id
  WHERE YEARWEEK(te.date) = YEARWEEK(week_date)
  GROUP BY c.id, c.code;
END$$
DELIMITER ;

-- Procedure: Find scheduling conflicts
DELIMITER $$
CREATE PROCEDURE find_conflicts()
BEGIN
  INSERT INTO conflicts (id, type, timetableEntry1Id, timetableEntry2Id, description, severity, isResolved, createdAt, updatedAt)
  SELECT
    UUID(),
    'room_overlap',
    t1.id,
    t2.id,
    CONCAT('Room ', r.code, ' is double-booked'),
    'high',
    FALSE,
    NOW(),
    NOW()
  FROM timetable_entries t1
  JOIN timetable_entries t2 ON t1.roomId = t2.roomId 
    AND t1.timeSlotId = t2.timeSlotId 
    AND t1.date = t2.date
    AND t1.id < t2.id
  JOIN rooms r ON t1.roomId = r.id
  WHERE NOT EXISTS (
    SELECT 1 FROM conflicts c
    WHERE c.timetableEntry1Id = t1.id AND c.timetableEntry2Id = t2.id
  );
END$$
DELIMITER ;