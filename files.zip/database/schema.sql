CREATE DATABASE IF NOT EXISTS timetable_db;
USE timetable_db;

-- Users table
CREATE TABLE users (
  id CHAR(36) PRIMARY KEY,
  firstName VARCHAR(100) NOT NULL,
  lastName VARCHAR(100) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin', 'teacher', 'student') DEFAULT 'student',
  phone VARCHAR(20),
  avatar VARCHAR(255),
  isActive BOOLEAN DEFAULT TRUE,
  lastLogin TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Departments table
CREATE TABLE departments (
  id CHAR(36) PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  headId CHAR(36),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (headId) REFERENCES users(id)
);

-- Filieres table
CREATE TABLE filieres (
  id CHAR(36) PRIMARY KEY,
  code VARCHAR(50) NOT NULL,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  departmentId CHAR(36) NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (departmentId) REFERENCES departments(id)
);

-- Academic Years table
CREATE TABLE academic_years (
  id CHAR(36) PRIMARY KEY,
  year VARCHAR(10) UNIQUE NOT NULL,
  startDate DATE NOT NULL,
  endDate DATE NOT NULL,
  isActive BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Classes table
CREATE TABLE classes (
  id CHAR(36) PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  filiereId CHAR(36) NOT NULL,
  academicYearId CHAR(36) NOT NULL,
  studentCount INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (filiereId) REFERENCES filieres(id),
  FOREIGN KEY (academicYearId) REFERENCES academic_years(id)
);

-- Semesters table
CREATE TABLE semesters (
  id CHAR(36) PRIMARY KEY,
  number ENUM('1', '2') NOT NULL,
  startDate DATE NOT NULL,
  endDate DATE NOT NULL,
  academicYearId CHAR(36) NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (academicYearId) REFERENCES academic_years(id)
);

-- UEs (Teaching Units) table
CREATE TABLE ues (
  id CHAR(36) PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  credits INT DEFAULT 3,
  hoursDuration INT NOT NULL,
  description TEXT,
  filiereId CHAR(36) NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (filiereId) REFERENCES filieres(id)
);

-- Rooms table
CREATE TABLE rooms (
  id CHAR(36) PRIMARY KEY,
  code VARCHAR(50) UNIQUE NOT NULL,
  name VARCHAR(255) NOT NULL,
  capacity INT NOT NULL,
  building VARCHAR(100),
  floor INT,
  roomType ENUM('classroom', 'lab', 'amphitheater', 'other') DEFAULT 'classroom',
  equipments JSON,
  isAvailable BOOLEAN DEFAULT TRUE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Time Slots table
CREATE TABLE time_slots (
  id CHAR(36) PRIMARY KEY,
  startTime TIME NOT NULL,
  endTime TIME NOT NULL,
  dayOfWeek ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday') NOT NULL,
  isAvailable BOOLEAN DEFAULT TRUE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Timetable Entries table
CREATE TABLE timetable_entries (
  id CHAR(36) PRIMARY KEY,
  classId CHAR(36) NOT NULL,
  ueId CHAR(36) NOT NULL,
  teacherId CHAR(36) NOT NULL,
  roomId CHAR(36) NOT NULL,
  timeSlotId CHAR(36) NOT NULL,
  date DATE NOT NULL,
  semesterId CHAR(36) NOT NULL,
  status ENUM('scheduled', 'confirmed', 'cancelled') DEFAULT 'scheduled',
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (classId) REFERENCES classes(id),
  FOREIGN KEY (ueId) REFERENCES ues(id),
  FOREIGN KEY (teacherId) REFERENCES users(id),
  FOREIGN KEY (roomId) REFERENCES rooms(id),
  FOREIGN KEY (timeSlotId) REFERENCES time_slots(id),
  FOREIGN KEY (semesterId) REFERENCES semesters(id)
);

-- Teacher Preferences table
CREATE TABLE teacher_preferences (
  id CHAR(36) PRIMARY KEY,
  teacherId CHAR(36) NOT NULL,
  semesterId CHAR(36) NOT NULL,
  preferredTimeSlots JSON NOT NULL,
  preferredRooms JSON,
  unavailableDates JSON,
  status ENUM('pending', 'approved', 'rejected', 'modified') DEFAULT 'pending',
  submittedAt TIMESTAMP,
  modifiedAt TIMESTAMP,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (teacherId) REFERENCES users(id),
  FOREIGN KEY (semesterId) REFERENCES semesters(id)
);

-- Conflicts table
CREATE TABLE conflicts (
  id CHAR(36) PRIMARY KEY,
  type ENUM('room_overlap', 'teacher_overlap', 'student_overlap', 'room_capacity') NOT NULL,
  timetableEntry1Id CHAR(36),
  timetableEntry2Id CHAR(36),
  description TEXT,
  severity ENUM('low', 'medium', 'high') DEFAULT 'medium',
  isResolved BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (timetableEntry1Id) REFERENCES timetable_entries(id),
  FOREIGN KEY (timetableEntry2Id) REFERENCES timetable_entries(id)
);

-- Notifications table
CREATE TABLE notifications (
  id CHAR(36) PRIMARY KEY,
  userId CHAR(36) NOT NULL,
  type ENUM('alert', 'info', 'warning', 'success') DEFAULT 'info',
  title VARCHAR(255),
  message TEXT,
  isRead BOOLEAN DEFAULT FALSE,
  relatedEntityId CHAR(36),
  relatedEntityType VARCHAR(100),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id)
);

-- Indexes for performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_classes_code ON classes(code);
CREATE INDEX idx_ues_code ON ues(code);
CREATE INDEX idx_rooms_code ON rooms(code);
CREATE INDEX idx_timetable_class_semester ON timetable_entries(classId, semesterId);
CREATE INDEX idx_timetable_room_date ON timetable_entries(roomId, date);
CREATE INDEX idx_timetable_teacher_date ON timetable_entries(teacherId, date);