#!/bin/bash

# Database Restore Script
# Usage: ./restore.sh <backup_file> <database_name>

BACKUP_FILE=$1
DB_NAME=$2
DB_USER=${3:-root}
DB_PASSWORD=$4

if [ -z "$BACKUP_FILE" ] || [ -z "$DB_NAME" ]; then
  echo "Usage: ./restore.sh <backup_file> <database_name> [db_user] [db_password]"
  exit 1
fi

if [ !  -f "$BACKUP_FILE" ]; then
  echo "Error: Backup file not found:  $BACKUP_FILE"
  exit 1
fi

echo "🔄 Restoring database from $BACKUP_FILE..."

if [ -z "$DB_PASSWORD" ]; then
  mysql -u "$DB_USER" "$DB_NAME" < "$BACKUP_FILE"
else
  mysql -u "$DB_USER" -p"$DB_PASSWORD" "$DB_NAME" < "$BACKUP_FILE"
fi

if [ $? -eq 0 ]; then
  echo "✅ Database restored successfully!"
else
  echo "❌ Error restoring database"
  exit 1
fi