# Quick Reference Guide

## Common Commands

### Development
```bash
# Backend
cd backend
npm run dev          # Start dev server
npm test             # Run tests
npm run lint         # Lint code
npm run seed         # Seed database

# Frontend
cd frontend
npm run dev          # Start dev server
npm run build        # Build for production
npm test             # Run tests
npm run lint         # Lint code