#!/bin/bash

# Deployment script for Timetable Management System
# Usage: ./deploy.sh [production|staging]

ENV=${1:-production}
REPO_URL="https://github.com/emmakitio1234-source/Projet-203. git"
DEPLOY_DIR="/var/www/timetable"
APP_PORT=5000

echo "🚀 Deploying Timetable Management System to $ENV..."

# Stop existing services
echo "⏹️  Stopping services..."
sudo systemctl stop timetable-api timetable-frontend

# Clone/update repository
if [ -d "$DEPLOY_DIR" ]; then
  cd "$DEPLOY_DIR"
  git pull origin main
else
  git clone "$REPO_URL" "$DEPLOY_DIR"
  cd "$DEPLOY_DIR"
fi

# Install backend dependencies
echo "📦 Installing backend dependencies..."
cd backend
npm install --production
npm run build 2>/dev/null || true

# Build frontend
echo "🏗️  Building frontend..."
cd ../frontend
npm install --production
npm run build

# Copy frontend build to web server
echo "📁 Deploying frontend..."
sudo cp -r dist/* /var/www/html/

# Start services
echo "🚀 Starting services..."
sudo systemctl start timetable-api timetable-frontend

# Verify deployment
echo "✅ Checking deployment..."
if curl -f http://localhost:$APP_PORT/health > /dev/null; then
  echo "✅ API is healthy"
else
  echo "❌ API health check failed"
  exit 1
fi

echo "✅ Deployment completed successfully!"