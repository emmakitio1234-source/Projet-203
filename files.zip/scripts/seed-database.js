#!/usr/bin/env node

const mysql = require('mysql2/promise');
require('dotenv').config();

async function seedDatabase() {
  const connection = await mysql.createConnection({
    host: process.env. DB_HOST,
    user: process.env. DB_USER,
    password:  process.env.DB_PASSWORD,
    database: process.env. DB_NAME,
  });

  try {
    console.log('🌱 Seeding database...\n');

    // Insert academic year
    const [yearResult] = await connection.execute(
      'INSERT INTO academic_years (id, year, startDate, endDate, isActive) VALUES (UUID(), ?, ?, ?, ?)',
      ['2025/2026', '2025-09-01', '2026-06-30', true],
    );

    console.log('✅ Academic year created');

    // Insert department
    const [deptResult] = await connection.execute(
      'INSERT INTO departments (id, code, name, description) VALUES (UUID(), ?, ?, ?)',
      ['ICT', 'Information and Communication Technologies', 'ICT Department'],
    );

    console.log('✅ Department created');

    // Insert filiere
    const [filiereResult] = await connection.execute(
      'INSERT INTO filieres (id, code, name, description, departmentId) VALUES (UUID(), ?, ?, ?, (SELECT id FROM departments WHERE code=?))',
      ['L2', 'Licence 2', 'Second Year License', 'ICT'],
    );

    console.log('✅ Filiere created');

    // Insert semesters
    await connection.execute(
      'INSERT INTO semesters (id, number, startDate, endDate, academicYearId) VALUES (UUID(), ?, ?, ?, (SELECT id FROM academic_years WHERE year=?))',
      ['1', '2025-09-01', '2026-01-31', '2025/2026'],
    );

    console.log('✅ Semester 1 created');

    // Insert rooms
    const rooms = [
      { code: 'A101', name: 'Room A101', capacity: 40, building: 'A', floor: 1 },
      { code: 'A102', name: 'Room A102', capacity: 50, building: 'A', floor: 1 },
      { code: 'B201', name: 'Lab B201', capacity: 30, building: 'B', floor: 2 },
    ];

    for (const room of rooms) {
      await connection. execute(
        'INSERT INTO rooms (id, code, name, capacity, building, floor, roomType, isAvailable) VALUES (UUID(), ?, ?, ?, ?, ?, ?, ?)',
        [room.code, room.name, room.capacity, room.building, room.floor, 'classroom', true],
      );
    }

    console.log('✅ Rooms created');

    // Insert time slots
    const slots = [
      { startTime: '08:00:00', endTime: '10:00:00', day: 'Monday' },
      { startTime: '10:00:00', endTime:  '12:00:00', day: 'Monday' },
      { startTime:  '14:00:00', endTime:  '16:00:00', day: 'Wednesday' },
    ];

    for (const slot of slots) {
      await connection. execute(
        'INSERT INTO time_slots (id, startTime, endTime, dayOfWeek, isAvailable) VALUES (UUID(), ?, ?, ?, ?)',
        [slot.startTime, slot.endTime, slot.day, true],
      );
    }

    console.log('✅ Time slots created');

    // Insert UEs
    const ues = [
      { code: 'ICT-203', name: 'Advanced Web Development', credits: 3, hours: 24 },
      { code: 'ICT-204', name:  'Database Design', credits: 3, hours: 20 },
    ];

    for (const ue of ues) {
      await connection.execute(
        'INSERT INTO ues (id, code, name, credits, hoursDuration, filiereId) VALUES (UUID(), ?, ?, ?, ?, (SELECT id FROM filieres WHERE code=?))',
        [ue.code, ue.name, ue.credits, ue. hours, 'L2'],
      );
    }

    console.log('✅ UEs created');

    // Insert class
    await connection.execute(
      'INSERT INTO classes (id, code, name, filiereId, academicYearId, studentCount) VALUES (UUID(), ?, ?, (SELECT id FROM filieres WHERE code=?), (SELECT id FROM academic_years WHERE year=?), ?)',
      ['ICT-L2', 'ICT Level 2', 'L2', '2025/2026', 45],
    );

    console.log('✅ Class ICT-L2 created');

    console.log('\n✅ Database seeding completed successfully!');
  } catch (error) {
    console.error('❌ Error seeding database:', error. message);
  } finally {
    await connection.end();
  }
}

seedDatabase();