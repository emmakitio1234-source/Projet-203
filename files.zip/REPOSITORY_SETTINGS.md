# Repository Settings

## Branch Protection Rules

### Main Branch
- Require pull request reviews before merging
- Require status checks to pass before merging
- Require code review from CODEOWNERS
- Enforce up-to-date branches before merging
- Restrict who can push to matching branches

### Develop Branch
- Require pull request reviews (1 approval)
- Require status checks to pass
- Allow auto-merge

## Required Status Checks

- Unit tests
- Integration tests
- Linting
- Code coverage
- Security scan
- Build

## Code Owners
