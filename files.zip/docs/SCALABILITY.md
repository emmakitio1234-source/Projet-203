# Scalability Guide

## Horizontal Scaling

### Load Balancing

```nginx
upstream api_backend {
  server api1. example.com:5000;
  server api2.example. com:5000;
  server api3.example.com:5000;
}

server {
  listen 80;
  server_name api.example.com;

  location / {
    proxy_pass http://api_backend;
    proxy_set_header X-Real-IP $remote_addr;
  }
}