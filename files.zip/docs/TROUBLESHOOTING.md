# Troubleshooting Guide

## Common Issues & Solutions

### Backend Issues

#### 1. Database Connection Error
**Error**: `Error: connect ECONNREFUSED 127.0.0.1:3306`

**Solutions**:
- Check MySQL is running: `sudo service mysql status`
- Verify credentials in . env file
- Check database is created
- Test connection:  `mysql -u root -p`

#### 2. Port Already in Use
**Error**: `listen EADDRINUSE:  address already in use :::5000`

**Solutions**:
- Find process:  `lsof -i :5000`
- Kill process: `kill -9 <PID>`
- Use different port: `PORT=5001 npm start`

#### 3. JWT Token Invalid
**Error**: `JsonWebTokenError: invalid token`

**Solutions**:
- Check JWT_SECRET is set in .env
- Verify token format: `Bearer <token>`
- Check token expiration
- Generate new token

#### 4. CORS Error
**Error**: `Access to XMLHttpRequest blocked by CORS policy`

**Solutions**:
```javascript
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true
}));