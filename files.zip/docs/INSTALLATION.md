# Installation Guide - Timetable Management System

## Prerequisites
- Node.js (v16+)
- MySQL 8.0+
- Git

## Backend Setup

### 1. Clone Repository
\`\`\`bash
git clone <repo-url>
cd timetable-management-system/backend
\`\`\`

### 2. Install Dependencies
\`\`\`bash
npm install
\`\`\`

### 3. Configure Environment Variables
\`\`\`bash
cp .env.example .env
# Edit . env with your database credentials
\`\`\`

### 4. Create Database
\`\`\`bash
mysql -u root -p < ../database/schema.sql
\`\`\`

### 5. Start Server
\`\`\`bash
npm run dev
\`\