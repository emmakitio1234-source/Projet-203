# Workflow Guide

## Feature Development Workflow

### 1. Planning Phase
- [ ] Define feature requirements
- [ ] Design database schema if needed
- [ ] Create user stories
- [ ] Estimate effort
- [ ] Create GitHub issue

### 2. Development Phase

#### Backend Development
```bash
# Create feature branch
git checkout -b feature/feature-name

# Create service
vim src/services/featureService.js

# Create controller
vim src/controllers/featureController.js

# Create routes
vim src/routes/featureRoutes.js

# Add to main routes
vim src/routes/index.js

# Test
npm test

# Commit
git add . 
git commit -m "feat(feature-name): add new feature"