# API Documentation

## Authentication Endpoints

### Register User
\`\`\`
POST /api/auth/register
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "teacher"
}
\`\`\`

### Login
\`\`\`
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
\`\`\`

## Timetable Endpoints

### Get Timetable
\`\`\`
GET /api/timetable? classId=xxx&semesterId=yyy
Authorization: Bearer {token}
\`\`\`

### Create Timetable Entry
\`\`\`
POST /api/timetable
Authorization: Bearer {token}
Content-Type: application/json

{
  "classId": "uuid",
  "ueId": "uuid",
  "teacherId": "uuid",
  "roomId": "uuid",
  "timeSlotId": "uuid",
  "date": "2026-01-20",
  "semesterId": "uuid"
}
\`\`\`

## Preferences Endpoints

### Submit Preference
\`\`\`
POST /api/preferences
Authorization: Bearer {token}
Content-Type: application/json

{
  "teacherId": "uuid",
  "semesterId": "uuid",
  "preferredTimeSlots":  ["Monday-08:00", "Wednesday-10:00"],
  "preferredRooms": ["room1", "room2"]
}
\`\`\`

## Response Format

All responses follow this format:

\`\`\`json
{
  "success": true,
  "message": "Operation successful",
  "data": { ...  },
  "timestamp": "2026-01-20T10:30:00.000Z"
}
\`\`\`