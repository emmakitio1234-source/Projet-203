# Upgrade Guide

## Upgrading to v1.1.0

### Breaking Changes
None

### New Features
- Mobile app support
- Calendar integration
- Advanced filters

### Migration Steps

#### 1. Backup Database
```bash
mysqldump -u root -p timetable_db > backup_v1.0.0.sql