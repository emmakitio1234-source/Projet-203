# Template Guide

## Component Template

### Functional Component with TypeScript

```typescript
import React from 'react';

interface MyComponentProps {
  title: string;
  onAction?:  () => void;
  children?: React.ReactNode;
}

export const MyComponent: React. FC<MyComponentProps> = ({
  title,
  onAction,
  children,
}) => {
  return (
    <div>
      <h1>{title}</h1>
      {children}
      {onAction && <button onClick={onAction}>Action</button>}
    </div>
  );
};