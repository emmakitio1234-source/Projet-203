# User Manual

## System Overview

The Timetable Management System is designed for universities to manage class schedules, teacher preferences, and room allocations efficiently.

## Features

### For Administrators
- Create and manage departments, filières, and classes
- Define academic years and semesters
- Manage rooms and their capacities
- Resolve scheduling conflicts
- Approve/reject teacher preferences
- Generate reports and exports

### For Teachers
- Submit preferred time slots and rooms
- View assigned schedule
- Receive notifications about changes
- Download personal timetable

### For Students
- View class schedule
- Check room locations
- Access course information
- Download timetable

## Getting Started

### Login
1. Navigate to the login page
2. Enter your email and password
3. Click "Login"

### View Timetable
1. Go to the Timetable page
2. Select your class/semester
3. Choose view type (day/week/month)
4. View your schedule

### Teacher:  Submit Preferences
1. Go to Preferences page
2. Select preferred time slots
3. Choose preferred rooms
4. Submit preferences
5. Wait for admin approval

## Tips & Best Practices

- Check your notifications regularly for updates
- Submit preferences as early as possible
- Report scheduling conflicts immediately
- Download your timetable for offline access