# Contribution Guidelines

Thank you for your interest in contributing to the Timetable Management System! 

## Getting Started

1. **Fork the repository**
   ```bash
   git clone https://github.com/YOUR-USERNAME/Projet-203.git
   cd Projet-203