# Code Style Guide

## Backend (JavaScript/Node.js)

### Naming Conventions

```javascript
// Constants
const MAX_USERS = 1000;
const API_TIMEOUT = 5000;

// Variables
let userCount = 0;
const isActive = true;

// Functions - camelCase
function getUserById(id) {}
const fetchUserData = async (userId) => {};

// Classes - PascalCase
class UserService {}
class DatabaseConnection {}

// Exports
module.exports = userService;