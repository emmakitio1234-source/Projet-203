# Database Schema Documentation

## Tables Overview

### Users Table
Stores all system users (admin, teachers, students)

**Columns:**
- id: UUID (Primary Key)
- firstName: VARCHAR(100)
- lastName: VARCHAR(100)
- email: VARCHAR(255) UNIQUE
- password: VARCHAR(255)
- role: ENUM('admin', 'teacher', 'student')
- phone: VARCHAR(20)
- avatar: VARCHAR(255)
- isActive: BOOLEAN
- lastLogin: TIMESTAMP

### Classes Table
Stores class information

**Columns:**
- id: UUID (Primary Key)
- code: VARCHAR(50) UNIQUE
- name: VARCHAR(255)
- filiereId: UUID (Foreign Key)
- academicYearId: UUID (Foreign Key)
- studentCount: INT

### TimetableEntries Table
Stores individual timetable entries

**Columns:**
- id: UUID (Primary Key)
- classId: UUID (Foreign Key)
- ueId: UUID (Foreign Key)
- teacherId: UUID (Foreign Key)
- roomId: UUID (Foreign Key)
- timeSlotId: UUID (Foreign Key)
- date: DATE
- semesterId: UUID (Foreign Key)
- status: ENUM('scheduled', 'confirmed', 'cancelled')

### Rooms Table
Stores available rooms

**Columns:**
- id: UUID (Primary Key)
- code: VARCHAR(50) UNIQUE
- name: VARCHAR(255)
- capacity: INT
- building: VARCHAR(100)
- floor: INT
- roomType:  ENUM('classroom', 'lab', 'amphitheater', 'other')
- equipments: JSON
- isAvailable: BOOLEAN