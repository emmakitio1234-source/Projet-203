import React, { useEffect, useState } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '../components/ui/card';
import { LoadingState } from '../components/shared/LoadingState';

interface AnalyticsData {
  totalClasses: number;
  totalTeachers: number;
  totalStudents: number;
  totalRooms: number;
  utilizationRate: number;
  classDistribution: any[];
  teacherWorkload: any[];
  roomUsage: any[];
}

export const AnalyticsPage: React. FC = () => {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/analytics/metrics');
      const result = await response.json();
      setData(result. data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingState />;
  }

  if (!data) {
    return <div className="text-center py-8">Failed to load analytics</div>;
  }

  const COLORS = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Analytics Dashboard</h1>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md: grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <Card>
          <div className="text-center">
            <p className="text-gray-600 text-sm">Total Classes</p>
            <p className="text-3xl font-bold text-blue-600">{data.totalClasses}</p>
          </div>
        </Card>

        <Card>
          <div className="text-center">
            <p className="text-gray-600 text-sm">Total Teachers</p>
            <p className="text-3xl font-bold text-green-600">{data.totalTeachers}</p>
          </div>
        </Card>

        <Card>
          <div className="text-center">
            <p className="text-gray-600 text-sm">Total Students</p>
            <p className="text-3xl font-bold text-yellow-600">{data.totalStudents}</p>
          </div>
        </Card>

        <Card>
          <div className="text-center">
            <p className="text-gray-600 text-sm">Total Rooms</p>
            <p className="text-3xl font-bold text-purple-600">{data.totalRooms}</p>
          </div>
        </Card>

        <Card>
          <div className="text-center">
            <p className="text-gray-600 text-sm">Utilization Rate</p>
            <p className="text-3xl font-bold text-red-600">{data.utilizationRate}%</p>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Class Distribution */}
        <Card title="Class Distribution">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data.classDistribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#2563eb" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Teacher Workload */}
        <Card title="Teacher Workload">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data.teacherWorkload}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="hours" stroke="#10b981" />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        {/* Room Usage */}
        <Card title="Room Usage Distribution">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={data.roomUsage}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {data.roomUsage.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
};