import React, { useState, useEffect } from 'react';
import { RoomGrid } from '../components/features/rooms/RoomGrid';

interface Room {
  id: string;
  code: string;
  name: string;
  capacity:  number;
  building: string;
  floor: number;
  roomType: string;
  isAvailable: boolean;
}

export const RoomsPage: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRooms = async () => {
      try {
        const response = await fetch('/api/rooms');
        const result = await response.json();
        setRooms(result.data || []);
      } catch (error) {
        console.error('Error fetching rooms:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchRooms();
  }, []);

  const handleSelectRoom = (room: Room) => {
    console.log('Selected room:', room);
    // Handle room selection
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Rooms Management</h1>

      {loading && <p>Loading rooms...</p>}
      {!loading && rooms.length > 0 && (
        <RoomGrid rooms={rooms} onSelectRoom={handleSelectRoom} />
      )}
    </div>
  );
};