import React, { useEffect, useState } from 'react';
import { DataTable } from '../components/shared/DataTable';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Select } from '../components/ui/select';
import { Dialog } from '../components/ui/dialog';

interface UE {
  id: string;
  code: string;
  name: string;
  credits: number;
  hoursDuration: number;
  filiere: { name: string };
}

export const UEPage: React.FC = () => {
  const [ues, setUEs] = useState<UE[]>([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [search, setSearch] = useState('');
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    credits: '',
    hoursDuration: '',
    filiereId: '',
  });

  useEffect(() => {
    fetchUEs();
  }, [search]);

  const fetchUEs = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (search) params.append('search', search);

      const response = await fetch(`/api/ues?${params}`);
      const result = await response.json();
      setUEs(result.data. data || []);
    } catch (error) {
      console.error('Error fetching UEs:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateUE = async () => {
    try {
      const response = await fetch('/api/ues', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setShowDialog(false);
        setFormData({
          code: '',
          name: '',
          credits: '',
          hoursDuration: '',
          filiereId: '',
        });
        fetchUEs();
      }
    } catch (error) {
      console.error('Error creating UE:', error);
    }
  };

  const columns = [
    { key: 'code' as const, label: 'Code', sortable: true },
    { key: 'name' as const, label: 'Name', sortable: true },
    { key:  'credits' as const, label: 'Credits', sortable:  true },
    { key: 'hoursDuration' as const, label: 'Hours', sortable: true },
    {
      key: 'filiere' as const,
      label:  'Filiere',
      render: (filiere: any) => filiere?. name || 'N/A',
    },
  ];

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Teaching Units (UEs)</h1>
        <Button variant="primary" onClick={() => setShowDialog(true)}>
          Add New UE
        </Button>
      </div>

      <div className="mb-6">
        <Input
          placeholder="Search UEs by code or name..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {loading ? (
        <div>Loading... </div>
      ) : (
        <DataTable data={ues} columns={columns} pagination />
      )}

      <Dialog
        open={showDialog}
        onOpenChange={setShowDialog}
        title="Create New UE"
      >
        <div className="space-y-4">
          <Input
            label="Code"
            value={formData.code}
            onChange={(e) => setFormData({ ...formData, code: e. target.value })}
            placeholder="e.g., ICT-203"
          />
          <Input
            label="Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="e.g., Web Development"
          />
          <Input
            label="Credits"
            type="number"
            value={formData.credits}
            onChange={(e) => setFormData({ ...formData, credits: e. target.value })}
          />
          <Input
            label="Hours"
            type="number"
            value={formData.hoursDuration}
            onChange={(e) => setFormData({ ...formData, hoursDuration: e.target. value })}
          />

          <div className="flex gap-2">
            <Button variant="primary" onClick={handleCreateUE}>
              Create
            </Button>
            <Button variant="secondary" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
          </div>
        </div>
      </Dialog>
    </div>
  );
};