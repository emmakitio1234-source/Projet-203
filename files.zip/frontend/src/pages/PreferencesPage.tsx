import React, { useState } from 'react';
import { PreferenceCalendar } from '../components/features/preferences/PreferenceCalendar';
import { Button } from '../components/ui/button';

export const PreferencesPage: React.FC = () => {
  const [selectedSlots, setSelectedSlots] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (slots: string[]) => {
    setLoading(true);
    try {
      const response = await fetch('/api/preferences', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body:  JSON.stringify({
          teacherId: localStorage.getItem('userId'),
          semesterId: localStorage.getItem('semesterId'),
          preferredTimeSlots: slots,
        }),
      });

      if (response.ok) {
        alert('Preferences submitted successfully!');
        setSelectedSlots([]);
      } else {
        alert('Failed to submit preferences');
      }
    } catch (error) {
      console.error('Error submitting preferences:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Teacher Preferences</h1>
      <PreferenceCalendar onSelect={handleSubmit} />
    </div>
  );
};