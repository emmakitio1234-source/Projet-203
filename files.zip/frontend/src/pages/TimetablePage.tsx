import React, { useState } from 'react';
import { TimetableView } from '../components/features/timetable/TimetableView';
import { useTimetable } from '../features/timetable/hooks/useTimetable';

export const TimetablePage: React.FC = () => {
  const [classId, setClassId] = useState('');
  const [semesterId, setsemesterId] = useState('');
  const { data: timetable, isLoading, error } = useTimetable(classId, semesterId);

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Timetable Management</h1>

      <div className="bg-white p-6 rounded-lg shadow-sm mb-6 grid grid-cols-2 gap-4">
        <input
          type="text"
          placeholder="Enter Class ID"
          value={classId}
          onChange={(e) => setClassId(e.target. value)}
          className="px-4 py-2 border rounded-lg"
        />
        <input
          type="text"
          placeholder="Enter Semester ID"
          value={semesterId}
          onChange={(e) => setSemesterId(e.target. value)}
          className="px-4 py-2 border rounded-lg"
        />
      </div>

      {isLoading && <p>Loading timetable...</p>}
      {error && <p className="text-red-600">Error loading timetable</p>}
      {timetable && <TimetableView classId={classId} semesterId={semesterId} />}
    </div>
  );
};