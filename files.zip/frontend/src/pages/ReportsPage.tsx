import React, { useState } from 'react';
import { Button } from '../components/ui/button';
import { Select } from '../components/ui/select';
import { Input } from '../components/ui/input';

type ReportType = 'timetable' | 'conflicts' | 'workload' | 'utilization' | 'analytics';
type ExportFormat = 'pdf' | 'excel';

export const ReportsPage: React.FC = () => {
  const [reportType, setReportType] = useState<ReportType>('timetable');
  const [format, setFormat] = useState<ExportFormat>('pdf');
  const [classId, setClassId] = useState('');
  const [loading, setLoading] = useState(false);

  const reportOptions = [
    { value: 'timetable', label: 'Timetable Report' },
    { value: 'conflicts', label: 'Conflict Report' },
    { value: 'workload', label: 'Teacher Workload' },
    { value: 'utilization', label: 'Room Utilization' },
    { value: 'analytics', label:  'Analytics Dashboard' },
  ];

  const handleGenerateReport = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        format,
        .. .(classId && { classId }),
      });

      const response = await fetch(`/api/reports/${reportType}?${params}`, {
        method: 'POST',
      });

      if (response.  ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document. createElement('a');
        a.href = url;
        a. download = `report_${reportType}_${Date.now()}.  ${format === 'pdf' ? 'pdf' : 'xlsx'}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Generate Reports</h1>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 max-w-2xl">
        <div className="space-y-6">
          <Select
            label="Report Type"
            value={reportType}
            onChange={(e) => setReportType(e.target.value as ReportType)}
            options={reportOptions}
          />

          {reportType === 'timetable' && (
            <Input
              label="Class ID (Optional)"
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
              placeholder="Leave empty for all classes"
            />
          )}

          <Select
            label="Export Format"
            value={format}
            onChange={(e) => setFormat(e.target.value as ExportFormat)}
            options={[
              { value: 'pdf', label: 'PDF' },
              { value: 'excel', label: 'Excel' },
            ]}
          />

          <Button
            variant="primary"
            onClick={handleGenerateReport}
            isLoading={loading}
            className="w-full"
          >
            Generate & Download
          </Button>
        </div>
      </div>

      <div className="mt-12 grid grid-cols-1 md: grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg">
          <h3 className="font-semibold text-lg mb-2">📊 Timetable Report</h3>
          <p className="text-sm text-gray-600">
            Get detailed view of class schedules with all sessions, teachers, and rooms.
          </p>
        </div>

        <div className="bg-gradient-to-br from-red-50 to-red-100 p-6 rounded-lg">
          <h3 className="font-semibold text-lg mb-2">⚠️ Conflict Report</h3>
          <p className="text-sm text-gray-600">
            Identify and track scheduling conflicts with resolution status.
          </p>
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-6 rounded-lg">
          <h3 className="font-semibold text-lg mb-2">👨‍🏫 Teacher Workload</h3>
          <p className="text-sm text-gray-600">
            Analyze teaching hours, classes, and workload distribution per teacher.
          </p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg">
          <h3 className="font-semibold text-lg mb-2">🏢 Room Utilization</h3>
          <p className="text-sm text-gray-600">
            Monitor room usage patterns and identify optimization opportunities.
          </p>
        </div>
      </div>
    </div>
  );
};