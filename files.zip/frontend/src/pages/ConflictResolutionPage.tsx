import React, { useEffect, useState } from 'react';
import { ConflictIndicator } from '../components/features/timetable/ConflictIndicator';
import { Button } from '../components/ui/button';

interface Conflict {
  id: string;
  type: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  isResolved: boolean;
  entry1: any;
  entry2: any;
}

export const ConflictResolutionPage:  React.FC = () => {
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchConflicts();
  }, []);

  const fetchConflicts = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/conflicts');
      const data = await response. json();
      setConflicts(data. data || []);
    } catch (error) {
      console.error('Error fetching conflicts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleResolve = async (conflictId: string) => {
    try {
      const response = await fetch(`/api/conflicts/${conflictId}/resolve`, {
        method: 'PATCH',
      });

      if (response.ok) {
        setConflicts(conflicts.map(c => 
          c.id === conflictId ? { ...c, isResolved: true } : c
        ));
      }
    } catch (error) {
      console.error('Error resolving conflict:', error);
    }
  };

  const filteredConflicts = conflicts.filter(c => {
    if (filter === 'all') return true;
    if (filter === 'pending') return !c.isResolved;
    if (filter === 'resolved') return c.isResolved;
    return c.severity === filter;
  });

  const severityColor = (severity: string) => {
    switch (severity) {
      case 'high': 
        return 'bg-red-100 text-red-800';
      case 'medium': 
        return 'bg-yellow-100 text-yellow-800';
      case 'low': 
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Conflict Resolution</h1>

      <ConflictIndicator 
        conflicts={conflicts. filter(c => ! c.isResolved)} 
        onResolve={handleResolve}
      />

      <div className="mt-8 space-y-4">
        <div className="flex gap-2">
          {['all', 'pending', 'resolved', 'high', 'medium', 'low'].map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg transition ${
                filter === f
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
              }`}
            >
              {f. charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {loading ? (
          <p className="text-center text-gray-500">Loading conflicts...</p>
        ) : filteredConflicts.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            No conflicts found
          </div>
        ) : (
          <div className="space-y-3">
            {filteredConflicts.map(conflict => (
              <div
                key={conflict.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-lg">{conflict.type}</h3>
                      <span className={`px-2 py-1 rounded text-xs font-medium ${severityColor(conflict.severity)}`}>
                        {conflict.severity}
                      </span>
                      {conflict.isResolved && (
                        <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-medium">
                          ✓ Resolved
                        </span>
                      )}
                    </div>
                    <p className="text-gray-600">{conflict.description}</p>
                  </div>

                  {! conflict.isResolved && (
                    <Button
                      variant="primary"
                      onClick={() => handleResolve(conflict.id)}
                      className="ml-4"
                    >
                      Resolve
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};