import React, { useState, useEffect } from 'react';

interface Class {
  id: string;
  code: string;
  name: string;
  filiere: string;
  studentCount: number;
}

export const ClassesPage: React.FC = () => {
  const [classes, setClasses] = useState<Class[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchClasses = async () => {
      try {
        const response = await fetch('/api/classes');
        const result = await response.json();
        setClasses(result.data || []);
      } catch (error) {
        console.error('Error fetching classes:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchClasses();
  }, []);

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Classes Management</h1>

      {loading && <p>Loading classes...</p>}
      {!loading && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-6 py-3 text-left font-semibold">Code</th>
                <th className="px-6 py-3 text-left font-semibold">Name</th>
                <th className="px-6 py-3 text-left font-semibold">Filière</th>
                <th className="px-6 py-3 text-left font-semibold">Students</th>
              </tr>
            </thead>
            <tbody>
              {classes.map((cls) => (
                <tr key={cls.id} className="border-t border-gray-200 hover:bg-gray-50">
                  <td className="px-6 py-4 font-semibold">{cls.code}</td>
                  <td className="px-6 py-4">{cls.name}</td>
                  <td className="px-6 py-4">{cls.filiere}</td>
                  <td className="px-6 py-4">{cls.studentCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};