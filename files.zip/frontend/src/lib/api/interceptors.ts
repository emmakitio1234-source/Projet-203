import apiClient from './client';

// Response interceptor for handling common errors
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      // Handle unauthorized
      window.location.href = '/login';
    }

    if (error.response?.status === 403) {
      // Handle forbidden
      console.error('Access denied');
    }

    if (error.response?.status === 404) {
      // Handle not found
      console.error('Resource not found');
    }

    if (error.response?.status >= 500) {
      // Handle server errors
      console.error('Server error');
    }

    return Promise.reject(error);
  },
);