export const PERMISSIONS = {
  // Timetable permissions
  VIEW_TIMETABLE: 'view: timetable',
  CREATE_TIMETABLE: 'create:timetable',
  EDIT_TIMETABLE: 'edit:timetable',
  DELETE_TIMETABLE:  'delete:timetable',

  // User permissions
  VIEW_USERS: 'view:users',
  CREATE_USERS: 'create:users',
  EDIT_USERS: 'edit: users',
  DELETE_USERS: 'delete:users',

  // Room permissions
  VIEW_ROOMS:  'view:rooms',
  CREATE_ROOMS: 'create:rooms',
  EDIT_ROOMS: 'edit:rooms',
  DELETE_ROOMS:  'delete:rooms',

  // Class permissions
  VIEW_CLASSES: 'view:classes',
  CREATE_CLASSES: 'create:classes',
  EDIT_CLASSES: 'edit:classes',
  DELETE_CLASSES: 'delete:classes',

  // Report permissions
  VIEW_REPORTS:  'view:reports',
  EXPORT_REPORTS: 'export:reports',

  // Settings permissions
  VIEW_SETTINGS:  'view:settings',
  EDIT_SETTINGS: 'edit:settings',
};

// Role-based permissions
export const ROLE_PERMISSIONS = {
  admin: [
    // All permissions
    ... Object.values(PERMISSIONS),
  ],
  teacher: [
    PERMISSIONS.VIEW_TIMETABLE,
    PERMISSIONS.VIEW_USERS,
    PERMISSIONS.VIEW_ROOMS,
  ],
  student: [
    PERMISSIONS.VIEW_TIMETABLE,
  ],
};