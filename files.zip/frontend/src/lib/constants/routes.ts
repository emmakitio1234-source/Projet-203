export const ROUTES = {
  // Public routes
  LOGIN: '/login',
  REGISTER: '/register',
  FORGOT_PASSWORD: '/forgot-password',

  // Protected routes
  DASHBOARD: '/dashboard',
  TIMETABLE: '/timetable',
  PREFERENCES: '/preferences',
  ROOMS: '/rooms',
  CLASSES: '/classes',
  SETTINGS: '/settings',
  PROFILE: '/profile',
  NOTIFICATIONS: '/notifications',

  // Admin routes
  USERS: '/users',
  DEPARTMENTS: '/departments',
  ANALYTICS: '/analytics',
  REPORTS: '/reports',
  CONFLICTS: '/conflicts',

  // Error routes
  NOT_FOUND: '/404',
  UNAUTHORIZED: '/401',
  FORBIDDEN: '/403',
};