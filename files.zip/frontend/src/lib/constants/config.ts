export const API_CONFIG = {
  // Base URL
  BASE_URL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',

  // Timeouts
  REQUEST_TIMEOUT: 10000,
  CONNECTION_TIMEOUT: 5000,

  // Retry config
  MAX_RETRIES: 3,
  RETRY_DELAY:  1000,

  // Cache config
  CACHE_TIME: 1000 * 60 * 5, // 5 minutes
  STALE_TIME: 1000 * 60, // 1 minute

  // Pagination
  DEFAULT_PAGE_SIZE: 10,
  MAX_PAGE_SIZE:  100,

  // File upload
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  ALLOWED_FILE_TYPES: ['application/pdf', 'application/vnd. ms-excel'],
};

export const FEATURES = {
  REAL_TIME_UPDATES: true,
  NOTIFICATIONS: true,
  EMAIL_NOTIFICATIONS: false,
  OFFLINE_MODE: false,
  DARK_MODE: true,
  MULTI_LANGUAGE: true,
};

export const THEME = {
  PRIMARY_COLOR: '#2563eb',
  SECONDARY_COLOR: '#64748b',
  SUCCESS_COLOR: '#10b981',
  DANGER_COLOR: '#ef4444',
  WARNING_COLOR: '#f59e0b',
  BORDER_RADIUS: '0.5rem',
  SHADOW: '0 1px 3px 0 rgba(0, 0, 0, 0.1)',
};