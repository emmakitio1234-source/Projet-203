import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import frCommon from './fr/common. json';
import frAuth from './fr/auth.json';
import frTimetable from './fr/timetable.json';
import enCommon from './en/common. json';
import enAuth from './en/auth.json';
import enTimetable from './en/timetable.json';

const resources = {
  fr: {
    common: frCommon,
    auth: frAuth,
    timetable: frTimetable,
  },
  en: {
    common: enCommon,
    auth: enAuth,
    timetable: enTimetable,
  },
};

i18n
  . use(initReactI18next)
  .init({
    resources,
    lng: localStorage.getItem('language') || 'fr',
    fallbackLng: 'en',
    ns: ['common'],
    defaultNS: 'common',
  });

export default i18n;