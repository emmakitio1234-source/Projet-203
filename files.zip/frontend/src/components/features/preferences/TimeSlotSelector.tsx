import React from 'react';

interface TimeSlot {
  id: string;
  time: string;
  day: string;
}

interface TimeSlo tSelectorProps {
  selectedSlots: string[];
  onSlotsChange: (slots: string[]) => void;
}

export const TimeSlotSelector:  React.FC<TimeSlotSelectorProps> = ({
  selectedSlots,
  onSlotsChange,
}) => {
  const timeSlots: TimeSlot[] = [
    { id: '1', time: '08:00-10:00', day: 'Monday' },
    { id: '2', time: '10:00-12:00', day: 'Monday' },
    { id: '3', time: '14:00-16:00', day: 'Monday' },
    { id: '4', time:  '08:00-10:00', day: 'Tuesday' },
    { id: '5', time:  '10:00-12:00', day: 'Tuesday' },
    { id: '6', time: '14:00-16:00', day: 'Tuesday' },
    { id: '7', time: '08:00-10:00', day: 'Wednesday' },
    { id: '8', time: '10:00-12:00', day: 'Wednesday' },
    { id: '9', time:  '14:00-16:00', day: 'Wednesday' },
    { id: '10', time: '08:00-10:00', day: 'Thursday' },
    { id: '11', time: '10:00-12:00', day: 'Thursday' },
    { id: '12', time: '14:00-16:00', day: 'Thursday' },
    { id: '13', time:  '08:00-10:00', day: 'Friday' },
    { id: '14', time: '10:00-12:00', day: 'Friday' },
    { id: '15', time: '14:00-16:00', day: 'Friday' },
  ];

  const handleToggle = (slotId: string) => {
    const updated = selectedSlots.includes(slotId)
      ? selectedSlots.filter((id) => id !== slotId)
      : [...selectedSlots, slotId];
    onSlotsChange(updated);
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const times = ['08:00-10:00', '10:00-12:00', '14:00-16:00'];

  return (
    <div className="space-y-4">
      {days.map((day) => (
        <div key={day} className="border rounded-lg p-4">
          <h4 className="font-semibold mb-3">{day}</h4>
          <div className="grid grid-cols-3 gap-2">
            {times.map((time) => {
              const slot = timeSlots.find((s) => s.day === day && s.time === time);
              if (!slot) return null;

              const isSelected = selectedSlots.includes(slot.id);

              return (
                <button
                  key={slot.id}
                  onClick={() => handleToggle(slot.id)}
                  className={`p-3 rounded-lg border-2 transition ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <p className="font-medium text-sm">{time}</p>
                  {isSelected && <p className="text-xs text-blue-600">Selected</p>}
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
};