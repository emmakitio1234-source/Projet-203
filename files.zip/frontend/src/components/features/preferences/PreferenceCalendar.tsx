import React, { useState } from 'react';
import { Button } from '../../ui/button';

interface TimeSlot {
  time: string;
  available: boolean;
}

interface PreferenceCalendarProps {
  onSelect: (slots: string[]) => void;
}

export const PreferenceCalendar: React.FC<PreferenceCalendarProps> = ({ onSelect }) => {
  const [selectedSlots, setSelectedSlots] = useState<string[]>([]);
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const times = ['08:00', '10:00', '12:00', '14:00', '16:00', '18:00'];

  const toggleSlot = (day: string, time: string) => {
    const slot = `${day}-${time}`;
    setSelectedSlots((prev) =>
      prev.includes(slot) ? prev.filter((s) => s !== slot) : [...prev, slot]
    );
  };

  const handleSubmit = () => {
    onSelect(selectedSlots);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
      <h2 className="text-2xl font-bold mb-4">Select Your Preferred Time Slots</h2>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-2">Time</th>
              {days.map((day) => (
                <th key={day} className="border p-2 text-center">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {times.map((time) => (
              <tr key={time}>
                <td className="border p-2 font-semibold">{time}</td>
                {days.map((day) => (
                  <td key={`${day}-${time}`} className="border p-2 text-center">
                    <input
                      type="checkbox"
                      checked={selectedSlots. includes(`${day}-${time}`)}
                      onChange={() => toggleSlot(day, time)}
                      className="w-4 h-4 cursor-pointer"
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 flex gap-2">
        <Button variant="primary" onClick={handleSubmit}>
          Submit Preferences
        </Button>
        <Button
          variant="secondary"
          onClick={() => setSelectedSlots([])}
        >
          Clear
        </Button>
      </div>
    </div>
  );
};