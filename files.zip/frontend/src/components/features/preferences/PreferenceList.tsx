import React, { useEffect, useState } from 'react';

interface Preference {
  id: string;
  teacherName: string;
  semester: string;
  status: 'pending' | 'approved' | 'rejected' | 'modified';
  submittedAt: Date;
  slots: string[];
}

export const PreferenceList: React.FC = () => {
  const [preferences, setPreferences] = useState<Preference[]>([]);

  useEffect(() => {
    const fetchPreferences = async () => {
      try {
        const response = await fetch('/api/preferences');
        const data = await response. json();
        setPreferences(data.data || []);
      } catch (error) {
        console.error('Error fetching preferences:', error);
      }
    };

    fetchPreferences();
  }, []);

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      modified: 'bg-blue-100 text-blue-800',
    };
    return colors[status] || '';
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Teacher Preferences</h3>

      {preferences.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No preferences submitted</p>
      ) : (
        <div className="overflow-x-auto border rounded-lg">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">Teacher</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Semester</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Preferred Slots</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Submitted</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {preferences.map((pref) => (
                <tr key={pref.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm">{pref.teacherName}</td>
                  <td className="px-6 py-4 text-sm">{pref.semester}</td>
                  <td className="px-6 py-4 text-sm">{pref.slots.length} slots</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(pref.status)}`}>
                      {pref.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {new Date(pref.submittedAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};