import React, { useEffect, useState } from 'react';

interface Availability {
  day: string;
  slots: Array<{ time: string; available: boolean }>;
}

interface RoomAvailabilityProps {
  roomId: string;
}

export const RoomAvailability: React.FC<RoomAvailabilityProps> = ({ roomId }) => {
  const [availability, setAvailability] = useState<Availability[]>([]);

  useEffect(() => {
    const fetchAvailability = async () => {
      try {
        const response = await fetch(`/api/rooms/${roomId}/availability`);
        const data = await response.json();
        setAvailability(data.data || []);
      } catch (error) {
        console.error('Error fetching availability:', error);
      }
    };

    fetchAvailability();
  }, [roomId]);

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Room Availability</h3>

      {availability.length === 0 ? (
        <p className="text-gray-500">Loading availability...</p>
      ) : (
        <div className="grid grid-cols-1 md: grid-cols-5 gap-4">
          {availability.map((day) => (
            <div key={day.day} className="border rounded-lg p-4">
              <h4 className="font-semibold mb-3">{day.day}</h4>
              <div className="space-y-2">
                {day.slots.map((slot, idx) => (
                  <div
                    key={idx}
                    className={`p-2 rounded text-xs text-center font-medium ${
                      slot. available
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {slot.time}
                    <br />
                    {slot.available ? '✓ Available' : '✗ Booked'}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};