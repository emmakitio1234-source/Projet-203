import React from 'react';

interface Room {
  id: string;
  code: string;
  name: string;
  capacity: number;
  building: string;
  floor: number;
  roomType: string;
  isAvailable: boolean;
}

interface RoomCardProps {
  room: Room;
  onClick: () => void;
}

export const RoomCard: React.FC<RoomCardProps> = ({ room, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
    >
      <div className="flex justify-between items-start mb-2">
        <div>
          <h3 className="font-semibold text-lg">{room.name}</h3>
          <p className="text-sm text-gray-600">{room.code}</p>
        </div>
        <span
          className={`px-2 py-1 rounded text-xs font-semibold ${
            room.isAvailable
              ? 'bg-green-100 text-green-800'
              : 'bg-red-100 text-red-800'
          }`}
        >
          {room.isAvailable ? 'Available' : 'Unavailable'}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2 text-sm">
        <div>
          <p className="text-gray-600">Capacity</p>
          <p className="font-semibold">{room.capacity}</p>
        </div>
        <div>
          <p className="text-gray-600">Type</p>
          <p className="font-semibold capitalize">{room.roomType}</p>
        </div>
        <div>
          <p className="text-gray-600">Building</p>
          <p className="font-semibold">{room.building}</p>
        </div>
        <div>
          <p className="text-gray-600">Floor</p>
          <p className="font-semibold">{room.floor}</p>
        </div>
      </div>
    </div>
  );
};