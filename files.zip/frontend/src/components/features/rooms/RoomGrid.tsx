import React from 'react';
import { RoomCard } from './RoomCard';

interface Room {
  id: string;
  code: string;
  name: string;
  capacity: number;
  building: string;
  floor: number;
  roomType: string;
  isAvailable: boolean;
}

interface RoomGridProps {
  rooms: Room[];
  onSelectRoom: (room: Room) => void;
}

export const RoomGrid: React.FC<RoomGridProps> = ({ rooms, onSelectRoom }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {rooms. map((room) => (
        <RoomCard
          key={room.id}
          room={room}
          onClick={() => onSelectRoom(room)}
        />
      ))}
    </div>
  );
};