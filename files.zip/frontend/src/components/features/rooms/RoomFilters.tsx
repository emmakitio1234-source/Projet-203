import React, { useState } from 'react';
import { Input } from '../../ui/input';
import { Select } from '../../ui/select';
import { Button } from '../../ui/button';

interface RoomFiltersProps {
  onFilter: (filters: any) => void;
}

export const RoomFilters: React. FC<RoomFiltersProps> = ({ onFilter }) => {
  const [filters, setFilters] = useState({
    capacity: '',
    building: '',
    type: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e. target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  const handleApply = () => {
    onFilter(filters);
  };

  const handleReset = () => {
    setFilters({ capacity: '', building: '', type:  '' });
    onFilter({ capacity: '', building: '', type:  '' });
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 space-y-4">
      <h3 className="font-semibold">Filter Rooms</h3>

      <Input
        label="Minimum Capacity"
        type="number"
        name="capacity"
        value={filters.capacity}
        onChange={handleChange}
        placeholder="e.g., 40"
      />

      <Input
        label="Building"
        name="building"
        value={filters.building}
        onChange={handleChange}
        placeholder="e.g., A or B"
      />

      <Select
        label="Room Type"
        name="type"
        value={filters.type}
        onChange={handleChange}
        options={[
          { value:  '', label: 'All Types' },
          { value: 'classroom', label: 'Classroom' },
          { value: 'lab', label: 'Lab' },
          { value: 'amphitheater', label: 'Amphitheater' },
        ]}
      />

      <div className="flex gap-2">
        <Button variant="primary" onClick={handleApply} className="flex-1">
          Apply Filters
        </Button>
        <Button variant="secondary" onClick={handleReset} className="flex-1">
          Reset
        </Button>
      </div>
    </div>
  );
};