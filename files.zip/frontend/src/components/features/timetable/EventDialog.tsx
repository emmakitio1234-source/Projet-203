import React, { useState } from 'react';
import { Dialog } from '../../ui/dialog';
import { Input } from '../../ui/input';
import { Select } from '../../ui/select';
import { Button } from '../../ui/button';

interface EventDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit:  (data: any) => void;
  initialData?: any;
}

export const EventDialog: React. FC<EventDialogProps> = ({
  open,
  onOpenChange,
  onSubmit,
  initialData,
}) => {
  const [formData, setFormData] = useState(
    initialData || {
      ueId: '',
      teacherId: '',
      roomId:  '',
      timeSlotId: '',
      date: '',
    }
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e. target;
    setFormData((prev:  any) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    onSubmit(formData);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange} title="Schedule Event">
      <div className="space-y-4">
        <Select
          label="Teaching Unit"
          name="ueId"
          value={formData.ueId}
          onChange={handleChange}
          options={[
            { value: '1', label: 'ICT-203:  Advanced Web Development' },
            { value:  '2', label: 'ICT-204: Database Design' },
          ]}
        />

        <Select
          label="Teacher"
          name="teacherId"
          value={formData.teacherId}
          onChange={handleChange}
          options={[
            { value: '1', label:  'Jean Dupont' },
            { value: '2', label: 'Marie Martin' },
          ]}
        />

        <Select
          label="Room"
          name="roomId"
          value={formData.roomId}
          onChange={handleChange}
          options={[
            { value: '1', label: 'A101' },
            { value:  '2', label: 'A102' },
            { value: '3', label:  'B201' },
          ]}
        />

        <Select
          label="Time Slot"
          name="timeSlotId"
          value={formData.timeSlotId}
          onChange={handleChange}
          options={[
            { value: '1', label: '08:00 - 10:00' },
            { value: '2', label: '10:00 - 12:00' },
            { value: '3', label: '14:00 - 16:00' },
          ]}
        />

        <Input
          label="Date"
          type="date"
          name="date"
          value={formData. date}
          onChange={handleChange}
        />
      </div>

      <div className="flex gap-2 mt-6">
        <Button variant="primary" onClick={handleSubmit}>
          Save Event
        </Button>
        <Button variant="secondary" onClick={() => onOpenChange(false)}>
          Cancel
        </Button>
      </div>
    </Dialog>
  );
};