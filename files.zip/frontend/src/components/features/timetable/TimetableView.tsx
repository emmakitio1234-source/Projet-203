import React, { useState, useEffect } from 'react';
import { TimetableGrid } from './TimetableGrid';
import { TimetableFilters } from './TimetableFilters';

interface TimetableViewProps {
  classId: string;
  semesterId: string;
}

export const TimetableView: React. FC<TimetableViewProps> = ({ classId, semesterId }) => {
  const [viewType, setViewType] = useState<'week' | 'day' | 'month'>('week');
  const [timetableData, setTimetableData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTimetable = async () => {
      try {
        const response = await fetch(
          `/api/timetable? classId=${classId}&semesterId=${semesterId}`,
        );
        const result = await response.json();
        setTimetableData(result. data);
      } catch (error) {
        console.error('Error fetching timetable:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchTimetable();
  }, [classId, semesterId]);

  return (
    <div className="space-y-6">
      <TimetableFilters viewType={viewType} onViewChange={setViewType} />
      {loading ?  (
        <div>Loading timetable...</div>
      ) : (
        <TimetableGrid data={timetableData} viewType={viewType} />
      )}
    </div>
  );
};