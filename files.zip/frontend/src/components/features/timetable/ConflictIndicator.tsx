import React from 'react';

interface ConflictIndicatorProps {
  conflicts: any[];
  onResolve: (conflictId: string) => void;
}

export const ConflictIndicator: React.FC<ConflictIndicatorProps> = ({
  conflicts,
  onResolve,
}) => {
  if (conflicts.length === 0) {
    return (
      <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-green-800">
        ✅ No conflicts detected
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <h3 className="font-semibold text-red-900 mb-3">
          ⚠️ {conflicts.length} Conflict(s) Found
        </h3>

        <div className="space-y-2">
          {conflicts. map((conflict) => (
            <div
              key={conflict.id}
              className="flex items-center justify-between p-3 bg-white border border-red-200 rounded"
            >
              <div>
                <p className="font-medium text-sm">{conflict.type}</p>
                <p className="text-xs text-gray-600">{conflict.description}</p>
              </div>
              <button
                onClick={() => onResolve(conflict. id)}
                className="px-3 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600"
              >
                Resolve
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};