import { render, screen } from '@testing-library/react';
import { TimetableGrid } from '../TimetableGrid';

describe('TimetableGrid', () => {
  it('renders timetable table', () => {
    const mockData = [
      {
        id: '1',
        ue: { code: 'ICT-203', name: 'Advanced Web' },
        teacher: { firstName: 'John', lastName: 'Doe' },
        room: { code: 'A101', name: 'Room A101' },
        timeSlot: { startTime: '08:00', dayOfWeek: 'Monday' },
        date: '2026-01-20',
      },
    ];

    render(<TimetableGrid data={mockData} viewType="week" />);
    expect(screen.getByText('ICT-203')).toBeInTheDocument();
  });

  it('displays correct headers', () => {
    render(<TimetableGrid data={[]} viewType="week" />);
    expect(screen.getByText('Time')).toBeInTheDocument();
    expect(screen.getByText('Monday')).toBeInTheDocument();
  });
});