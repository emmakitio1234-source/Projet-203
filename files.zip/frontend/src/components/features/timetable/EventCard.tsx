import React from 'react';
import { Badge } from '../../ui/badge';

interface EventCardProps {
  ueCode: string;
  ueName: string;
  teacher: string;
  room: string;
  time: string;
  status: 'scheduled' | 'confirmed' | 'cancelled';
  onEdit?:  () => void;
  onDelete?:  () => void;
}

export const EventCard: React.FC<EventCardProps> = ({
  ueCode,
  ueName,
  teacher,
  room,
  time,
  status,
  onEdit,
  onDelete,
}) => {
  const statusColors = {
    scheduled: 'bg-blue-50 border-blue-200',
    confirmed: 'bg-green-50 border-green-200',
    cancelled: 'bg-red-50 border-red-200',
  };

  const statusBadgeVariant = {
    scheduled: 'secondary',
    confirmed: 'success',
    cancelled: 'danger',
  } as const;

  return (
    <div className={`p-3 border rounded-lg ${statusColors[status]}`}>
      <div className="flex justify-between items-start mb-2">
        <div>
          <h4 className="font-semibold text-sm">{ueCode}</h4>
          <p className="text-xs text-gray-600">{ueName}</p>
        </div>
        <Badge variant={statusBadgeVariant[status]}>
          {status. charAt(0).toUpperCase() + status.slice(1)}
        </Badge>
      </div>

      <div className="space-y-1 text-xs mb-3">
        <p>
          <strong>Teacher:</strong> {teacher}
        </p>
        <p>
          <strong>Room:</strong> {room}
        </p>
        <p>
          <strong>Time:</strong> {time}
        </p>
      </div>

      {(onEdit || onDelete) && (
        <div className="flex gap-2">
          {onEdit && (
            <button
              onClick={onEdit}
              className="flex-1 px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Edit
            </button>
          )}
          {onDelete && (
            <button
              onClick={onDelete}
              className="flex-1 px-2 py-1 text-xs bg-red-500 text-white rounded hover:bg-red-600"
            >
              Delete
            </button>
          )}
        </div>
      )}
    </div>
  );
};