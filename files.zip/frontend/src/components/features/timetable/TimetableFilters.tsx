import React from 'react';
import { Button } from '../../ui/button';

interface TimetableFiltersProps {
  viewType: 'week' | 'day' | 'month';
  onViewChange: (view: 'week' | 'day' | 'month') => void;
}

export const TimetableFilters: React.FC<TimetableFiltersProps> = ({
  viewType,
  onViewChange,
}) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
      <div className="flex gap-2 items-center">
        <label className="font-semibold">View:</label>
        <div className="flex gap-2">
          {(['day', 'week', 'month'] as const).map((view) => (
            <Button
              key={view}
              variant={viewType === view ? 'primary' : 'secondary'}
              size="sm"
              onClick={() => onViewChange(view)}
            >
              {view. charAt(0).toUpperCase() + view.slice(1)}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};