import React from 'react';

interface TimetableEntry {
  id: string;
  ue: { code: string; name: string };
  teacher: { firstName: string; lastName: string };
  room: { code: string; name: string };
  timeSlot: { startTime: string; endTime: string; dayOfWeek: string };
  date: string;
}

interface TimetableGridProps {
  data: TimetableEntry[];
  viewType: 'week' | 'day' | 'month';
}

export const TimetableGrid: React. FC<TimetableGridProps> = ({ data, viewType }) => {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const timeSlots = ['08:00', '10:00', '12:00', '14:00', '16:00', '18:00'];

  return (
    <div className="overflow-x-auto border rounded-lg">
      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-gray-100">
            <th className="border p-2 text-left">Time</th>
            {days.map((day) => (
              <th key={day} className="border p-2 text-center font-semibold">
                {day}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {timeSlots.map((time) => (
            <tr key={time}>
              <td className="border p-2 font-semibold">{time}</td>
              {days.map((day) => {
                const entry = data.find(
                  (e) => e.timeSlot.dayOfWeek === day && e.timeSlot.startTime === time,
                );
                return (
                  <td key={`${day}-${time}`} className="border p-2">
                    {entry && (
                      <div className="bg-blue-100 p-2 rounded text-sm">
                        <p className="font-semibold">{entry.ue.code}</p>
                        <p className="text-xs">{entry.teacher.lastName}</p>
                        <p className="text-xs">{entry. room.code}</p>
                      </div>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};