import React, { useState } from 'react';

interface DragDropProps {
  items: any[];
  onReorder: (reorderedItems: any[]) => void;
  renderItem: (item: any) => React.ReactNode;
}

export const DragDrop: React.FC<DragDropProps> = ({ items, onReorder, renderItem }) => {
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDrop = (dropIndex: number) => {
    if (draggedIndex === null) return;

    const newItems = [...items];
    const [draggedItem] = newItems.splice(draggedIndex, 1);
    newItems.splice(dropIndex, 0, draggedItem);

    onReorder(newItems);
    setDraggedIndex(null);
  };

  return (
    <div className="space-y-2">
      {items.map((item, index) => (
        <div
          key={index}
          draggable
          onDragStart={() => handleDragStart(index)}
          onDragOver={handleDragOver}
          onDrop={() => handleDrop(index)}
          className={`p-4 border-2 rounded cursor-move transition ${
            draggedIndex === index
              ? 'border-blue-500 bg-blue-50 opacity-50'
              : 'border-gray-200 hover:border-gray-300'
          }`}
        >
          {renderItem(item)}
        </div>
      ))}
    </div>
  );
};