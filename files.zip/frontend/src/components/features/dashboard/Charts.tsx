import React from 'react';

export const Charts: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold mb-4">Class Distribution</h3>
        <div className="flex items-center justify-center h-64 bg-gray-50 rounded">
          <p className="text-gray-500">Chart placeholder - Implement with Chart.js or Recharts</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-semibold mb-4">Room Utilization</h3>
        <div className="flex items-center justify-center h-64 bg-gray-50 rounded">
          <p className="text-gray-500">Chart placeholder - Implement with Chart.js or Recharts</p>
        </div>
      </div>
    </div>
  );
};