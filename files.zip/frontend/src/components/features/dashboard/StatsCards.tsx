import React from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: { direction: 'up' | 'down'; percentage: number };
}

const StatsCard: React.FC<StatsCardProps> = ({ title, value, icon, trend }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-gray-600 text-sm font-medium">{title}</p>
        <p className="text-3xl font-bold mt-2">{value}</p>
        {trend && (
          <p className={`text-sm mt-2 ${trend.direction === 'up' ? 'text-green-600' : 'text-red-600'}`}>
            {trend.direction === 'up' ? '↑' : '↓'}
            {trend.percentage}%
          </p>
        )}
      </div>
      <div className="text-4xl opacity-20">{icon}</div>
    </div>
  </div>
);

export const StatsCards:  React.FC = () => {
  const stats = [
    { title: 'Total Classes', value: '12', icon: '📚', trend: { direction: 'up', percentage: 5 } },
    { title:  'Total Teachers', value: '45', icon: '👨‍🏫', trend: { direction: 'up', percentage: 3 } },
    { title:  'Available Rooms', value: '28', icon: '🏫', trend: { direction: 'down', percentage: 2 } },
    { title:  'Scheduled Hours', value: '156', icon: '⏰', trend: { direction: 'up', percentage: 8 } },
  ];

  return (
    <div className="grid grid-cols-1 md: grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => (
        <StatsCard key={stat.title} {...stat} />
      ))}
    </div>
  );
};