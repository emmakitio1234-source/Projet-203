import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../../ui/button';

export const QuickActions: React.FC = () => {
  const navigate = useNavigate();

  const actions = [
    {
      label: 'Add New Class',
      icon: '🏫',
      action: () => navigate('/classes'),
    },
    {
      label: 'Schedule Session',
      icon: '📅',
      action: () => navigate('/timetable'),
    },
    {
      label: 'View Conflicts',
      icon: '⚠️',
      action:  () => navigate('/conflicts'),
    },
    {
      label: 'Generate Report',
      icon: '📊',
      action: () => navigate('/reports'),
    },
    {
      label: 'Manage Rooms',
      icon:  '🏢',
      action: () => navigate('/rooms'),
    },
    {
      label: 'Settings',
      icon: '⚙️',
      action: () => navigate('/settings'),
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
      {actions.map((action, index) => (
        <button
          key={index}
          onClick={action.action}
          className="flex flex-col items-center gap-2 p-4 bg-white border border-gray-200 rounded-lg hover:shadow-md transition"
        >
          <span className="text-3xl">{action.icon}</span>
          <span className="text-sm font-medium text-center">{action.label}</span>
        </button>
      ))}
    </div>
  );
};