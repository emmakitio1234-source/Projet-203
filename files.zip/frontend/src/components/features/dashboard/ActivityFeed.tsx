import React, { useEffect, useState } from 'react';

interface Activity {
  id: string;
  type: 'create' | 'update' | 'delete' | 'schedule';
  entity: string;
  description: string;
  user: string;
  timestamp: Date;
}

export const ActivityFeed: React.FC = () => {
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    // Fetch activities from API
    const fetchActivities = async () => {
      try {
        const response = await fetch('/api/dashboard/activity');
        const data = await response.json();
        setActivities(data. data || []);
      } catch (error) {
        console.error('Error fetching activities:', error);
      }
    };

    fetchActivities();
  }, []);

  const getActivityIcon = (type: string) => {
    const icons:  Record<string, string> = {
      create: '✨',
      update: '🔄',
      delete: '🗑️',
      schedule: '📅',
    };
    return icons[type] || '📝';
  };

  const getActivityColor = (type: string) => {
    const colors:  Record<string, string> = {
      create: 'border-green-200 bg-green-50',
      update: 'border-blue-200 bg-blue-50',
      delete: 'border-red-200 bg-red-50',
      schedule: 'border-purple-200 bg-purple-50',
    };
    return colors[type] || 'border-gray-200 bg-gray-50';
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Recent Activity</h3>

      {activities.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No activity yet</p>
      ) : (
        <div className="space-y-3">
          {activities. map((activity) => (
            <div
              key={activity. id}
              className={`p-4 border rounded-lg ${getActivityColor(activity.type)}`}
            >
              <div className="flex items-start gap-3">
                <span className="text-2xl">{getActivityIcon(activity.type)}</span>
                <div className="flex-1">
                  <p className="font-medium text-sm">{activity.description}</p>
                  <p className="text-xs text-gray-600 mt-1">
                    by {activity.user} • {new Date(activity.timestamp).toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};