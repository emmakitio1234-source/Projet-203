import React, { useEffect, useState } from 'react';

interface Event {
  id: string;
  title: string;
  date: Date;
  time: string;
  room: string;
  teacher: string;
}

export const UpcomingEvents: React.FC = () => {
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    // Fetch upcoming events
    const fetchEvents = async () => {
      try {
        const response = await fetch('/api/timetable? upcoming=true&limit=5');
        const data = await response.json();
        setEvents(data.data || []);
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };

    fetchEvents();
  }, []);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold mb-4">Upcoming Events</h3>

      {events.length === 0 ? (
        <p className="text-gray-500 text-center py-8">No upcoming events</p>
      ) : (
        <div className="space-y-3">
          {events.map((event) => (
            <div
              key={event.id}
              className="flex items-start justify-between p-3 border border-gray-200 rounded"
            >
              <div>
                <p className="font-medium text-sm">{event. title}</p>
                <p className="text-xs text-gray-600 mt-1">
                  {new Date(event.date).toLocaleDateString()} at {event.time}
                </p>
              </div>
              <div className="text-right text-xs">
                <p className="font-medium">{event.room}</p>
                <p className="text-gray-600">{event.teacher}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};