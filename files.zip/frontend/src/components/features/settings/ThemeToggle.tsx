import React, { useState, useEffect } from 'react';

export const ThemeToggle: React. FC = () => {
  const [theme, setTheme] = useState<'light' | 'dark' | 'auto'>('light');

  useEffect(() => {
    const savedTheme = (localStorage.getItem('theme') as 'light' | 'dark' | 'auto') || 'light';
    setTheme(savedTheme);
    applyTheme(savedTheme);
  }, []);

  const applyTheme = (newTheme: 'light' | 'dark' | 'auto') => {
    const html = document.documentElement;

    if (newTheme === 'dark') {
      html.classList. add('dark');
    } else if (newTheme === 'light') {
      html.classList. remove('dark');
    } else if (newTheme === 'auto') {
      const prefersDark = window.matchMedia('(prefers-color-scheme:  dark)').matches;
      prefersDark ? html.classList.add('dark') : html.classList.remove('dark');
    }

    localStorage.setItem('theme', newTheme);
  };

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'auto') => {
    setTheme(newTheme);
    applyTheme(newTheme);
  };

  return (
    <div className="space-y-4">
      <h3 className="font-semibold">Theme</h3>

      <div className="space-y-2">
        {(['light', 'dark', 'auto'] as const).map((option) => (
          <label key={option} className="flex items-center gap-3 cursor-pointer">
            <input
              type="radio"
              name="theme"
              value={option}
              checked={theme === option}
              onChange={() => handleThemeChange(option)}
              className="w-4 h-4"
            />
            <span className="text-sm capitalize">
              {option === 'auto' ? 'System' : option}
            </span>
          </label>
        ))}
      </div>
    </div>
  );
};