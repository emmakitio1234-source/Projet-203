import React, { useState, useEffect } from 'react';
import { Button } from '../../ui/button';

interface NotificationPreferences {
  emailNotifications: boolean;
  pushNotifications: boolean;
  scheduleChanges: boolean;
  conflictAlerts: boolean;
  weeklyDigest: boolean;
  instantUpdates: boolean;
}

export const NotificationPreferences: React. FC = () => {
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    emailNotifications: true,
    pushNotifications: true,
    scheduleChanges:  true,
    conflictAlerts: true,
    weeklyDigest: false,
    instantUpdates: true,
  });

  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleToggle = (key: keyof NotificationPreferences) => {
    setPreferences((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleSave = async () => {
    setLoading(true);

    try {
      const response = await fetch('/api/settings/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body:  JSON.stringify(preferences),
      });

      if (response.ok) {
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
      }
    } catch (error) {
      console.error('Error saving preferences:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-4">Notification Preferences</h3>

        {success && (
          <div className="bg-green-100 text-green-700 p-4 rounded-lg mb-4">
            Preferences saved successfully!
          </div>
        )}

        <div className="space-y-4">
          {Object.entries(preferences).map(([key, value]) => (
            <label key={key} className="flex items-center gap-3 cursor-pointer p-3 border rounded-lg hover:bg-gray-50">
              <input
                type="checkbox"
                checked={value}
                onChange={() => handleToggle(key as keyof NotificationPreferences)}
                className="w-4 h-4"
              />
              <div>
                <p className="font-medium text-sm capitalize">
                  {key. replace(/([A-Z])/g, ' $1').trim()}
                </p>
                <p className="text-xs text-gray-600">
                  {key === 'emailNotifications' && 'Receive notifications via email'}
                  {key === 'pushNotifications' && 'Receive push notifications'}
                  {key === 'scheduleChanges' && 'Notify when schedule changes'}
                  {key === 'conflictAlerts' && 'Alert for scheduling conflicts'}
                  {key === 'weeklyDigest' && 'Weekly summary of events'}
                  {key === 'instantUpdates' && 'Instant notifications for updates'}
                </p>
              </div>
            </label>
          ))}
        </div>

        <Button
          variant="primary"
          onClick={handleSave}
          isLoading={loading}
          className="mt-6"
        >
          Save Preferences
        </Button>
      </div>
    </div>
  );
};