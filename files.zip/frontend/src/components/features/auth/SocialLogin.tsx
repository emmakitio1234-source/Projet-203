import React from 'react';

export const SocialLogin: React.FC = () => {
  const handleGoogleLogin = () => {
    // Implement Google OAuth
    console.log('Google login clicked');
  };

  const handleGitHubLogin = () => {
    // Implement GitHub OAuth
    console.log('GitHub login clicked');
  };

  return (
    <div className="mt-6">
      <div className="relative mb-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-300"></div>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 bg-white text-gray-500">Or continue with</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={handleGoogleLogin}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition flex items-center justify-center gap-2"
        >
          <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
          Google
        </button>

        <button
          onClick={handleGitHubLogin}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition flex items-center justify-center gap-2"
        >
          <img src="https://github.com/favicon.ico" alt="GitHub" className="w-5 h-5" />
          GitHub
        </button>
      </div>
    </div>
  );
};