import React from 'react';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'alert' | 'info' | 'warning' | 'success';
  isRead: boolean;
  createdAt: string;
}

interface NotificationItemProps {
  notification:  Notification;
}

export const NotificationItem: React.FC<NotificationItemProps> = ({ notification }) => {
  const typeIcons = {
    alert: '⚠️',
    info:  'ℹ️',
    warning: '⚡',
    success: '✅',
  };

  const typeBgColors = {
    alert: 'bg-red-100',
    info: 'bg-blue-100',
    warning: 'bg-yellow-100',
    success: 'bg-green-100',
  };

  return (
    <div className={`p-4 border-b border-gray-200 ${! notification.isRead ? 'bg-gray-50' : ''}`}>
      <div className="flex gap-3">
        <span className="text-2xl">{typeIcons[notification.type]}</span>
        <div className="flex-1">
          <h4 className="font-semibold text-sm">{notification.title}</h4>
          <p className="text-sm text-gray-600 mt-1">{notification.message}</p>
          <p className="text-xs text-gray-500 mt-1">
            {new Date(notification.createdAt).toLocaleString()}
          </p>
        </div>
      </div>
    </div>
  );
};