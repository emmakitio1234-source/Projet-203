import React from 'react';

interface AvatarProps extends React.HTMLAttributes<HTMLDivElement> {
  src?:  string;
  alt:  string;
  size?: 'sm' | 'md' | 'lg';
  initials?: string;
}

export const Avatar = React.forwardRef<HTMLDivElement, AvatarProps>(
  ({ src, alt, size = 'md', initials, className, ...props }, ref) => {
    const sizes = {
      sm: 'w-8 h-8 text-xs',
      md: 'w-10 h-10 text-sm',
      lg: 'w-12 h-12 text-base',
    };

    return (
      <div
        ref={ref}
        className={`
          flex items-center justify-center rounded-full
          bg-blue-500 text-white font-semibold
          ${sizes[size]}
          ${className || ''}
        `}
        {...props}
      >
        {src ? (
          <img
            src={src}
            alt={alt}
            className="w-full h-full rounded-full object-cover"
          />
        ) : (
          initials
        )}
      </div>
    );
  },
);

Avatar.displayName = 'Avatar';