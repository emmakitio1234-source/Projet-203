import React, { useState, useRef } from 'react';
import { useClickOutside } from '../../hooks/useClickOutside';

interface MenuItem {
  label: string;
  onClick: () => void;
  icon?: React.ReactNode;
  danger?: boolean;
}

interface DropdownMenuProps {
  items: MenuItem[];
  trigger: React.ReactNode;
}

export const DropdownMenu:  React.FC<DropdownMenuProps> = ({ items, trigger }) => {
  const [open, setOpen] = useState(false);
  const ref = useClickOutside(() => setOpen(false));

  return (
    <div ref={ref} className="relative inline-block">
      <button
        onClick={() => setOpen(!open)}
        className="inline-flex items-center"
      >
        {trigger}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
          {items.map((item, index) => (
            <button
              key={index}
              onClick={() => {
                item.onClick();
                setOpen(false);
              }}
              className={`w-full text-left px-4 py-2 hover:bg-gray-100 transition ${
                item.danger ?  'text-red-600' : 'text-gray-800'
              } ${index !== items.length - 1 ? 'border-b border-gray-100' : ''}`}
            >
              {item.icon && <span className="mr-2">{item.icon}</span>}
              {item.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};