import React, { useState } from 'react';

interface TooltipProps {
  content: string;
  children: React.ReactNode;
  position?:  'top' | 'bottom' | 'left' | 'right';
}

export const Tooltip:  React.FC<TooltipProps> = ({
  content,
  children,
  position = 'top',
}) => {
  const [visible, setVisible] = useState(false);

  const positionClasses = {
    top: 'bottom-full mb-2',
    bottom: 'top-full mt-2',
    left: 'right-full mr-2',
    right: 'left-full ml-2',
  };

  return (
    <div className="relative inline-block">
      <div
        onMouseEnter={() => setVisible(true)}
        onMouseLeave={() => setVisible(false)}
      >
        {children}
      </div>

      {visible && (
        <div
          className={`absolute ${positionClasses[position]} px-2 py-1 bg-gray-800 text-white text-sm rounded whitespace-nowrap z-10`}
        >
          {content}
          <div className="absolute w-2 h-2 bg-gray-800 transform -rotate-45" />
        </div>
      )}
    </div>
  );
};