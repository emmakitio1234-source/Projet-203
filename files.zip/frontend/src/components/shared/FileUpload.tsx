import React, { useRef } from 'react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  acceptedTypes?: string[];
  maxSize?: number;
  multiple?: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onFileSelect,
  acceptedTypes = ['*/*'],
  maxSize = 10 * 1024 * 1024, // 10MB
  multiple = false,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const validateFile = (file: File) => {
    if (maxSize && file.size > maxSize) {
      setError(`File size exceeds ${maxSize / 1024 / 1024}MB limit`);
      return false;
    }

    if (acceptedTypes.length > 0 && acceptedTypes[0] !== '*/*') {
      const isAccepted = acceptedTypes.some((type) => {
        if (type.endsWith('/*')) {
          const [category] = type.split('/');
          return file.type.startsWith(category);
        }
        return file.type === type;
      });

      if (!isAccepted) {
        setError(`File type not accepted`);
        return false;
      }
    }

    setError(null);
    return true;
  };

  const handleFile = (file: File) => {
    if (validateFile(file)) {
      onFileSelect(file);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="space-y-2">
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition ${
          dragActive
            ? 'border-blue-500 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400'
        }`}
        onClick={() => inputRef.current?.click()}
      >
        <p className="text-gray-700 font-medium">Drag file here or click to select</p>
        <p className="text-sm text-gray-600 mt-1">Max {maxSize / 1024 / 1024}MB</p>

        <input
          ref={inputRef}
          type="file"
          onChange={(e) => e.target.files && handleFile(e.target.files[0])}
          multiple={multiple}
          accept={acceptedTypes.join(',')}
          className="hidden"
        />
      </div>

      {error && <div className="text-red-600 text-sm">{error}</div>}
    </div>
  );
};