import React, { useState } from 'react';

interface ColorPickerProps {
  value: string;
  onChange:  (color: string) => void;
  presets?: string[];
}

export const ColorPicker: React.FC<ColorPickerProps> = ({
  value,
  onChange,
  presets = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
}) => {
  const [customColor, setCustomColor] = useState(value);

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        {presets.map((color) => (
          <button
            key={color}
            onClick={() => onChange(color)}
            className={`w-10 h-10 rounded-lg border-2 transition ${
              value === color ?  'border-gray-800' : 'border-gray-200'
            }`}
            style={{ backgroundColor: color }}
            title={color}
          />
        ))}
      </div>

      <div>
        <input
          type="color"
          value={customColor}
          onChange={(e) => {
            setCustomColor(e. target.value);
            onChange(e.target.value);
          }}
          className="w-full h-10 cursor-pointer"
        />
      </div>

      <div className="text-sm text-gray-600">
        Selected: <code className="bg-gray-100 px-2 py-1 rounded">{value}</code>
      </div>
    </div>
  );
};