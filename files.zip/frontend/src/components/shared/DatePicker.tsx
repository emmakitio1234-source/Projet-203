import React, { useState } from 'react';

interface DatePickerProps {
  value?: Date;
  onChange:  (date: Date) => void;
  minDate?: Date;
  maxDate?: Date;
}

export const DatePicker: React.FC<DatePickerProps> = ({
  value,
  onChange,
  minDate,
  maxDate,
}) => {
  const [showCalendar, setShowCalendar] = useState(false);

  const handleDateClick = (date: Date) => {
    onChange(date);
    setShowCalendar(false);
  };

  const daysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const firstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const currentDate = value || new Date();
  const days = [];

  for (let i = 0; i < firstDayOfMonth(currentDate); i++) {
    days.push(null);
  }

  for (let i = 1; i <= daysInMonth(currentDate); i++) {
    days.push(new Date(currentDate.getFullYear(), currentDate.getMonth(), i));
  }

  return (
    <div className="relative">
      <input
        type="text"
        value={value?.toISOString().split('T')[0] || ''}
        readOnly
        placeholder="Select date"
        onClick={() => setShowCalendar(! showCalendar)}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg cursor-pointer"
      />

      {showCalendar && (
        <div className="absolute top-full left-0 mt-2 bg-white border border-gray-300 rounded-lg shadow-lg p-4 z-10">
          <div className="flex justify-between items-center mb-4">
            <button
              onClick={() => {
                const prev = new Date(currentDate);
                prev.setMonth(prev.getMonth() - 1);
                onChange(prev);
              }}
            >
              ◀
            </button>
            <span className="font-semibold">
              {currentDate.toLocaleDateString('en-US', {
                month: 'long',
                year: 'numeric',
              })}
            </span>
            <button
              onClick={() => {
                const next = new Date(currentDate);
                next.setMonth(next.getMonth() + 1);
                onChange(next);
              }}
            >
              ▶
            </button>
          </div>

          <div className="grid grid-cols-7 gap-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-xs font-semibold w-8 h-8">
                {day}
              </div>
            ))}

            {days.map((day, index) => (
              <button
                key={index}
                onClick={() => day && handleDateClick(day)}
                disabled={!day}
                className={`w-8 h-8 text-sm rounded ${
                  ! day
                    ? 'text-gray-300'
                    : 'hover:bg-blue-500 hover:text-white'
                }`}
              >
                {day?.getDate()}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};