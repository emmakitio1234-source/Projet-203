import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../features/auth/hooks/useAuth';

export const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const menuItems = [
    { href:  '/dashboard', label: 'Dashboard', roles: ['admin', 'teacher', 'student'] },
    { href: '/timetable', label: 'Timetable', roles: ['admin', 'teacher', 'student'] },
    { href: '/preferences', label: 'Preferences', roles: ['teacher'] },
    { href: '/rooms', label: 'Rooms', roles: ['admin'] },
    { href: '/classes', label: 'Classes', roles: ['admin'] },
    { href: '/settings', label: 'Settings', roles: ['admin', 'teacher', 'student'] },
  ];

  return (
    <aside className="w-64 bg-blue-900 text-white p-6">
      <h2 className="text-2xl font-bold mb-8">Timetable Pro</h2>
      <nav className="space-y-2">
        {menuItems
          .filter(item => user && item.roles.includes(user. role))
          .map(item => (
            <Link
              key={item.href}
              to={item.href}
              className="block px-4 py-2 rounded hover:bg-blue-800 transition"
            >
              {item.label}
            </Link>
          ))}
      </nav>
    </aside>
  );
};