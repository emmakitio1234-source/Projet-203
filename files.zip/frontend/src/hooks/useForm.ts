import { useState } from 'react';

interface UseFormResult<T> {
  values:  T;
  errors: Record<keyof T, string>;
  touched: Record<keyof T, boolean>;
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  handleBlur: (e:  React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => void;
  handleSubmit:  (callback: (values: T) => Promise<void>) => (e: React.FormEvent) => Promise<void>;
  resetForm: () => void;
  setFieldValue: (name: keyof T, value: any) => void;
}

export const useForm = <T extends Record<string, any>>(
  initialValues: T,
  onSubmit?:  (values: T) => Promise<void>
): UseFormResult<T> => {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<Record<keyof T, string>>({} as Record<keyof T, string>);
  const [touched, setTouched] = useState<Record<keyof T, boolean>>({} as Record<keyof T, boolean>);

  const handleChange = (e: React. ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e. target;
    setValues((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleBlur = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name } = e.target;
    setTouched((prev) => ({
      ...prev,
      [name]: true,
    }));
  };

  const handleSubmit = (callback: (values: T) => Promise<void>) => async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await callback(values);
    } catch (error) {
      console.error('Form submission error:', error);
    }
  };

  const resetForm = () => {
    setValues(initialValues);
    setErrors({} as Record<keyof T, string>);
    setTouched({} as Record<keyof T, boolean>);
  };

  const setFieldValue = (name: keyof T, value: any) => {
    setValues((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return {
    values,
    errors,
    touched,
    handleChange,
    handleBlur,
    handleSubmit,
    resetForm,
    setFieldValue,
  };
};