export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: 'admin' | 'teacher' | 'student';
  avatar?: string;
  phone?: string;
  isActive: boolean;
}

export interface Department {
  id: string;
  code: string;
  name: string;
  description?:  string;
  headId?: string;
}

export interface Filiere {
  id: string;
  code: string;
  name: string;
  description?: string;
  departmentId:  string;
}

export interface Class {
  id: string;
  code: string;
  name: string;
  filiereId: string;
  academicYearId: string;
  studentCount: number;
}

export interface AcademicYear {
  id: string;
  year: string;
  startDate:  Date;
  endDate: Date;
  isActive: boolean;
}

export interface Semester {
  id: string;
  number: '1' | '2';
  startDate: Date;
  endDate: Date;
  academicYearId: string;
}

export interface UE {
  id: string;
  code: string;
  name: string;
  credits: number;
  hoursDuration: number;
  description?: string;
  filiereId:  string;
}

export interface Room {
  id: string;
  code: string;
  name: string;
  capacity: number;
  building?:  string;
  floor?: number;
  roomType:  'classroom' | 'lab' | 'amphitheater' | 'other';
  equipments?:  string[];
  isAvailable:  boolean;
}

export interface TimeSlot {
  id: string;
  startTime: string;
  endTime: string;
  dayOfWeek: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
  isAvailable: boolean;
}

export interface TimetableEntry {
  id: string;
  classId: string;
  ueId: string;
  teacherId: string;
  roomId: string;
  timeSlotId: string;
  date:  Date;
  semesterId: string;
  status: 'scheduled' | 'confirmed' | 'cancelled';
  ue?:  UE;
  teacher?: User;
  room?: Room;
  class?: Class;
  timeSlot?: TimeSlot;
}

export interface TeacherPreference {
  id: string;
  teacherId: string;
  semesterId: string;
  preferredTimeSlots: string[];
  preferredRooms?:  string[];
  unavailableDates?: Date[];
  status: 'pending' | 'approved' | 'rejected' | 'modified';
  submittedAt?: Date;
  modifiedAt?: Date;
}

export interface Conflict {
  id: string;
  type: 'room_overlap' | 'teacher_overlap' | 'student_overlap' | 'room_capacity';
  timetableEntry1Id?:  string;
  timetableEntry2Id?: string;
  description?:  string;
  severity: 'low' | 'medium' | 'high';
  isResolved: boolean;
}

export interface Notification {
  id: string;
  userId: string;
  type: 'alert' | 'info' | 'warning' | 'success';
  title: string;
  message: string;
  isRead: boolean;
  relatedEntityId?: string;
  relatedEntityType?: string;
  createdAt: Date;
}

export interface APIResponse<T> {
  success: boolean;
  message:  string;
  data?: T;
  timestamp: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pages: number;
}