import { useQuery, useMutation } from '@tanstack/react-query';
import apiClient from '../../../lib/api/client';

export const useConflicts = () => {
  const { data:  conflicts, isLoading } = useQuery({
    queryKey: ['conflicts'],
    queryFn: () => apiClient.get('/conflicts').then((res) => res.data),
  });

  const resolveMutation = useMutation({
    mutationFn: (conflictId: string) =>
      apiClient.patch(`/conflicts/${conflictId}/resolve`),
  });

  return {
    conflicts:  conflicts?. data || [],
    isLoading,
    resolveConflict: resolveMutation.mutate,
    isResolving: resolveMutation. isPending,
  };
};