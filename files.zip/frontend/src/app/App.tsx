import React, { Suspense } from 'react';
import { Routes } from './routes';
import { AppShell } from '../components/layout/AppShell';
import { ErrorBoundary } from '../components/shared/ErrorBoundary';
import { useAuthStore } from '../features/auth/store/authStore';
import { LoadingState } from '../components/shared/LoadingState';

export const App: React.FC = () => {
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated());

  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingState />}>
        {isAuthenticated ? (
          <AppShell>
            <Routes />
          </AppShell>
        ) : (
          <Routes />
        )}
      </Suspense>
    </ErrorBoundary>
  );
};