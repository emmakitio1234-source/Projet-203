# Timetable Management System

[![License:  MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js](https://img.shields.io/badge/Node.js-v16+-green.svg)](https://nodejs.org/)
[![React](https://img.shields.io/badge/React-18+-blue.svg)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5+-blue.svg)](https://www.typescriptlang.org/)

> A comprehensive, enterprise-grade web application for managing university course scheduling, room allocation, and teacher preferences.

## 🌟 Features

### Core Features
- ✅ **Timetable Management** - Create, edit, and manage class schedules
- ✅ **Room Allocation** - Smart room assignment and utilization tracking
- ✅ **Teacher Preferences** - Collect and process teacher scheduling preferences
- ✅ **Conflict Detection** - Automatic detection and resolution of scheduling conflicts
- ✅ **User Management** - Role-based access control (Admin, Teacher, Student)
- ✅ **Real-time Updates** - WebSocket integration for instant notifications
- ✅ **Reports & Analytics** - PDF/Excel exports and analytics dashboard
- ✅ **Multi-language Support** - English and French translations

### Advanced Features
- 🔐 **Security** - JWT authentication, bcryptjs password hashing, rate limiting
- ⚡ **Performance** - Redis caching, database indexing, query optimization
- 📊 **Analytics** - Teacher workload analysis, room utilization reports
- 🔔 **Notifications** - Email notifications, in-app alerts, real-time updates
- 📱 **Responsive Design** - Mobile, tablet, and desktop optimized
- 🌙 **Dark Mode** - Theme switching support

## 🚀 Quick Start

### Prerequisites
- Node.js v16+
- MySQL 8.0+
- Redis (optional)
- Git

### Installation

```bash
# Clone repository
git clone https://github.com/emmakitio1234-source/Projet-203.git
cd Projet-203

# Backend setup
cd backend
npm install
cp .env.example .env
# Edit .env with your configuration

# Database setup
mysql -u root -p < database/schema.sql
npm run db:seed
npm run create:admin admin@example.com John Doe Password123

# Start backend
npm run dev

# Frontend setup (in new terminal)
cd frontend
npm install
cp . env.example .env
npm run dev